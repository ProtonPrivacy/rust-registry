# muon‑rest

[![pipeline status](https://gitlab.protontech.ch/aboulmier/muon-rest/badges/master/pipeline.svg)](https://gitlab.protontech.ch/aboulmier/muon-rest/-/commits/master)

[![coverage report](https://gitlab.protontech.ch/aboulmier/muon-rest/badges/master/coverage.svg)](https://gitlab.protontech.ch/aboulmier/muon-rest/-/commits/master)

[![Latest Release](https://gitlab.protontech.ch/aboulmier/muon-rest/-/badges/release.svg)](https://gitlab.protontech.ch/aboulmier/muon-rest/-/releases)

[![Rustdoc](https://img.shields.io/badge/docs-online-blue.svg)](https://aboulmier.gitlab-pages.protontech.ch/muon-rest/proton_os_interface/index.html)


**muon‑rest** provides Rust data structures that map the request and response payloads of the Proton API.
These types are re‑exported from the main **muon** crate, allowing developers to work with Proton’s HTTP endpoints in a type‑safe way while keeping the core logic of the Muon client separate from the networking layer.

## Overview

Proton’s public API (used by Proton Mail, Drive, VPN, etc.) communicates via JSON over HTTPS.
Manually constructing request bodies and parsing responses is error‑prone and requires constant upkeep as the API evolves.

## Getting Started

Add the crate to your `Cargo.toml`:

```toml
[dependencies]
muon-rest = "0.1"
```
