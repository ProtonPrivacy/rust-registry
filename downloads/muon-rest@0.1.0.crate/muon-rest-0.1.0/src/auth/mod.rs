/// `/auth/v4`
pub mod v4;

/// API session scopes
mod scopes;
pub use scopes::Scopes;
