use std::collections::BTreeSet;
use std::fmt::Debug;

use serde::{Deserialize, Serialize};

/// A container for unique, case-sensitive authorization scopes.
///
/// # Invariants
/// 1. **Uniqueness**: Duplicate scopes are automatically deduplicated on
///    construction.
/// 2. **Sorted Order**: Iteration, serialization, and debug outputs are
///    **always sorted alphabetically** (via `BTreeSet`).
/// 3. **Case Sensitivity**: Scopes are case-sensitive ("Read" != "read").
#[derive(Deserialize, Serialize, Clone, PartialEq, Eq, Default)]
#[serde(transparent)]
pub struct Scopes {
    /// Internal storage using `BTreeSet` for deterministic ordering.
    scopes: BTreeSet<String>,
}

impl Scopes {
    /// Creates a new `Scopes` instance from any iterable of strings.
    ///
    /// # Edge Cases
    /// * **Duplicates**: If the input contains duplicates, they are removed.
    /// * **Empty Input**: Returns an empty set.
    /// * **Case Sensitivity**: "admin" and "Admin" are treated as distinct
    ///   scopes.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use muon_rest::auth::Scopes;
    ///
    /// // Duplicates are removed, order is standardized
    /// let s = Scopes::new(vec!["b".to_string(), "a".to_string(), "b".to_string()]);
    /// assert_eq!(s.len(), 2);
    /// ```
    pub fn new(items: impl IntoIterator<Item = String>) -> Self {
        Self {
            scopes: items.into_iter().collect(),
        }
    }

    /// Returns the number of unique scopes.
    pub fn len(&self) -> usize {
        self.scopes.len()
    }

    /// Returns `true` if there are no scopes.
    pub fn is_empty(&self) -> bool {
        self.scopes.is_empty()
    }

    /// Returns an iterator over the scopes in **alphabetical order**.
    pub fn iter(&self) -> impl Iterator<Item = &String> {
        self.scopes.iter()
    }

    /// Checks if a specific scope exists within the set.
    pub fn has(&self, scope: impl AsRef<str>) -> bool {
        self.scopes.contains(scope.as_ref())
    }

    /// Checks if **all** provided scopes exist within this set (Subset check).
    ///
    /// Returns `true` if `scopes` is a subset of `self`.
    ///
    /// # Edge Cases
    /// * **Empty Input**: If the input `scopes` is empty, this returns `true`
    ///   (the empty set is a subset of every set).
    /// * **Partial Match**: Returns `false` if even one item is missing.
    ///
    /// # Examples
    /// ```rust
    /// use muon_rest::auth::Scopes;
    /// let s = Scopes::new(vec!["read".to_string(), "write".to_string()]);
    ///
    /// assert!(s.has_multiple(vec!["read"]));
    /// assert!(!s.has_multiple(vec!["read", "delete"])); // "delete" is missing
    /// assert!(s.has_multiple(Vec::<String>::new())); // Empty is always true
    /// ```
    pub fn has_multiple<T: AsRef<str>>(&self, scopes: impl IntoIterator<Item = T>) -> bool {
        scopes.into_iter().all(|x| self.has(x))
    }

    /// Returns a new `Scopes` instance containing values present in **both**
    /// sets.
    ///
    /// # Edge Cases
    /// * **Disjoint Sets**: Returns an empty `Scopes` instance.
    /// * **Empty Operand**: If either `self` or `other` is empty, returns
    ///   empty.
    pub fn intersection(&self, other: &Scopes) -> Self {
        Self {
            scopes: self.scopes.intersection(&other.scopes).cloned().collect(),
        }
    }

    /// Returns a new `Scopes` instance containing values present in **either**
    /// set.
    ///
    /// # Edge Cases
    /// * **Superset**: If `other` is a subset of `self`, the result is
    ///   equivalent to `self`.
    /// * **Empty Operands**: If both are empty, returns empty.
    pub fn union(&self, other: &Scopes) -> Self {
        Self {
            scopes: self.scopes.union(&other.scopes).cloned().collect(),
        }
    }

    /// Returns a new `Scopes` instance containing values present in `self` but
    /// **not** in `other`.
    ///
    /// # Edge Cases
    /// * **Identical Sets**: Returns an empty set.
    /// * **Disjoint Sets**: Returns a clone of `self`.
    pub fn difference(&self, other: &Scopes) -> Self {
        Self {
            scopes: self.scopes.difference(&other.scopes).cloned().collect(),
        }
    }

    /// Returns a new `Scopes` instance containing values present in `self` or
    /// `other`, but **not** in both.
    ///
    /// # Edge Cases
    /// * **Identical Sets**: Returns an empty set.
    pub fn symmetric_difference(&self, other: &Scopes) -> Self {
        Self {
            scopes: self
                .scopes
                .symmetric_difference(&other.scopes)
                .cloned()
                .collect(),
        }
    }
}

impl FromIterator<String> for Scopes {
    fn from_iter<T: IntoIterator<Item = String>>(iter: T) -> Self {
        Self::new(iter)
    }
}

impl<T: IntoIterator<Item = String>> From<T> for Scopes {
    fn from(value: T) -> Self {
        Self::new(value)
    }
}

impl Debug for Scopes {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_set().entries(&self.scopes).finish()
    }
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;

    // Helper: string conversion
    fn s(input: &str) -> String {
        input.to_string()
    }

    // Helper: factory
    fn make_scopes(inputs: &[&str]) -> Scopes {
        Scopes::new(inputs.iter().map(|&x| x.to_string()))
    }

    // --- Invariant Tests ---

    #[test]
    fn test_invariant_uniqueness_and_sorting() {
        let scopes = make_scopes(&["b", "a", "b", "a"]);
        assert_eq!(scopes.len(), 2);

        let vec: Vec<_> = scopes.iter().collect();
        assert_eq!(vec, vec![&s("a"), &s("b")], "Must be sorted alphabetically");
    }

    #[test]
    fn test_invariant_case_sensitivity() {
        let scopes = make_scopes(&["read", "Read"]);
        assert_eq!(scopes.len(), 2, "Scopes should be case sensitive");
        assert!(scopes.has("read"));
        assert!(scopes.has("Read"));
    }

    #[test]
    fn test_serialization_format() {
        let scopes = make_scopes(&["write", "read"]);
        let serialized = serde_json::to_value(&scopes).unwrap();
        // Invariant: JSON output must be a sorted array
        assert_eq!(serialized, json!(["read", "write"]));
    }

    #[test]
    fn test_deserialization_deduplication() {
        let json_data = json!(["read", "read", "write"]);
        let scopes: Scopes = serde_json::from_value(json_data).unwrap();
        assert_eq!(scopes.len(), 2);
        assert!(scopes.has("read"));
        assert!(scopes.has("write"));
    }

    // --- Method Tests ---

    #[test]
    fn test_has_multiple_edge_cases() {
        let vault = make_scopes(&["a", "b", "c"]);

        // 1. Happy path
        assert!(vault.has_multiple(vec!["a", "b"]));

        // 2. Partial failure
        assert!(!vault.has_multiple(vec!["a", "z"]));

        // 3. Empty check (Empty set is subset of all sets)
        assert!(vault.has_multiple(Vec::<String>::new()));
    }

    #[test]
    fn test_intersection_edge_cases() {
        let a = make_scopes(&["1", "2"]);
        let b = make_scopes(&["3", "4"]);
        let empty = Scopes::default();

        // Disjoint sets
        assert!(a.intersection(&b).is_empty());

        // Intersection with empty
        assert!(a.intersection(&empty).is_empty());

        // Self intersection
        assert_eq!(a.intersection(&a), a);
    }

    #[test]
    fn test_union_edge_cases() {
        let a = make_scopes(&["1"]);
        let b = make_scopes(&["2"]);
        let empty = Scopes::default();

        // Standard
        let u = a.union(&b);
        assert_eq!(u.len(), 2);

        // Union with empty
        assert_eq!(a.union(&empty), a);

        // Self union
        assert_eq!(a.union(&a), a);
    }

    #[test]
    fn test_difference_edge_cases() {
        let full = make_scopes(&["read", "write"]);
        let partial = make_scopes(&["read"]);
        let empty = Scopes::default();

        // Full - Partial
        let diff = full.difference(&partial);
        assert_eq!(diff.len(), 1);
        assert!(diff.has("write"));

        // Partial - Full (should be empty, as partial has nothing full doesn't)
        assert!(partial.difference(&full).is_empty());

        // Anything - Empty = Anything
        assert_eq!(full.difference(&empty), full);

        // Anything - Self = Empty
        assert!(full.difference(&full).is_empty());
    }

    #[test]
    fn test_symmetric_difference_edge_cases() {
        let a = make_scopes(&["a", "b"]);
        let b = make_scopes(&["b", "c"]);

        // (a - b) U (b - a) -> {a, c}
        let sym = a.symmetric_difference(&b);
        assert_eq!(sym.len(), 2);
        assert!(sym.has("a"));
        assert!(sym.has("c"));
        assert!(!sym.has("b")); // Common term removed

        // Self sym_diff should be empty
        assert!(a.symmetric_difference(&a).is_empty());
    }
}
