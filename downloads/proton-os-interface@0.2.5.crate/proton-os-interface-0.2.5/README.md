[![pipeline status](https://gitlab.protontech.ch/aboulmier/proton-os-interface/badges/master/pipeline.svg)](https://gitlab.protontech.ch/aboulmier/proton-os-interface/-/commits/master)

[![coverage report](https://gitlab.protontech.ch/aboulmier/proton-os-interface/badges/master/coverage.svg)](https://gitlab.protontech.ch/aboulmier/proton-os-interface/-/commits/master)

[![Latest Release](https://gitlab.protontech.ch/aboulmier/proton-os-interface/-/badges/release.svg)](https://gitlab.protontech.ch/aboulmier/proton-os-interface/-/releases)

[![Rustdoc](https://img.shields.io/badge/docs-online-blue.svg)](https://aboulmier.gitlab-pages.protontech.ch/proton-os-interface/proton_os_interface/index.html)


# Proton OS interface

**`proton-os-interface`** is a Rust library that provides a unified abstraction layer over core operating system concepts, allowing you to write cross-platform code without scattering platform-specific conditionals throughout your project.

It defines traits for common OS capabilities—such as file systems, processes, memory, networking, and more—while letting you implement them for different platforms or mock them in tests.

## Features

- ✅ **Cross-platform OS abstraction**
- ✅ **almost no_std** — only uses "alloc" (future works: allow to use heapless structures)

### Abstracted interfaces
- Randomness
- Time
- IO
- Mutual exclusion
- Operating system errors
- Resource configuration

## Example

```rust

use proton_os_interface::time::*;

struct MySystemTime;
impl TimeFactory for MySystemTime {
    fn now(&self) -> Instant {
        (std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("bug: can not get time?")
            .as_nanos() as u64)
            .into()
    }
}

fn time_since_epoch(time_factory: impl TimeFactory) -> core::time::Duration {
    time_factory.now().duration_since(Instant::EPOCH)
}

struct MyCrossPlatformService<T>(T);

impl<T: TimeFactory> MyCrossPlatformService<T> {

    pub fn run(self) {
        println!("start at {:?}", time_since_epoch(self.0))
        /* ... */
    }
}

fn main() -> std::io::Result<()> {
    MyCrossPlatformService(MySystemTime).run();
}
```