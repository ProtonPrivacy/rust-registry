use core::marker::PhantomData;
use core::sync;
use core::time::Duration;
use std::ops::{Add, Sub};
use std::pin::Pin;
use std::sync::Arc;
use std::sync::atomic::AtomicI64;

use crate::Notify;

pub trait HasDeadline {
    /// Tell the duration in which we expect the next wake up from the native
    /// code to happen. The native code _MUST_ wakes us up _BEFORE_ within this
    /// time frame.
    fn expect_wakeup_before(&self) -> Deadline;
}

pub trait SetTimer {
    /// Set a timer that expires after `elapsed` [Duration].
    ///
    /// The timer may loop with `interval` [`Duration`]
    ///
    /// The timer is identified using a unique `identifier` w.r.t to self
    fn set(&self, elapsed: Option<Duration>, interval: Option<Duration>, identifier: usize);
}

/// Abstraction of sleep behavior
pub trait Sleep: Clone {
    type Sleep<'a>: Future<Output = ()> + Unpin + 'a
    where
        Self: 'a;

    /// Sleep for a given duration. Upon expiration return the current
    /// [`Instant`] or a `None`
    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'_>;
}

impl<T: ?Sized + Sleep> Sleep for &T {
    type Sleep<'a>
        = T::Sleep<'a>
    where
        Self: 'a;

    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'_> {
        <T as Sleep>::sleep(*self, duration)
    }
}

/// If `Some(duration)`: The caller _MUST_ set the time during
/// this time frame. The time can be set _earlier_ BUT NOT _later_ than
/// this value. Setting the time _after_ the deadline may alter the QoS.
///
/// If `None`: there are no expectation and the next wake up can be
/// in an arbitrary long time until a further call amend
/// this value.
pub type Deadline = Option<core::time::Duration>;

/// A trait for providing access to a **monotonic clock**.
///
/// # Safety
///
/// This trait is `unsafe` to implement because it requires a strict contract:
///
/// - The returned time values **must be monotonic**: they must never move
///   backwards, even if the system time is adjusted (e.g. via NTP or manual
///   clock changes).
/// - The underlying source **must not be a realtime clock** (e.g.
///   `SystemTime`), since realtime clocks can jump forward or backward. Only
///   monotonic sources like `std::time::Instant` are acceptable.
///
/// Failure to uphold these invariants can cause unsoundness in consumers that
/// rely on time never going backwards (e.g. scheduling, timeout handling,
/// progress measurement, lock-free algorithms).
pub unsafe trait Monotonic {}

unsafe impl<T: Monotonic> Monotonic for &T {}

/// Allow time duration since another point in time
pub trait Since: Copy {
    /// Get the [Duration] that elapsed since `earlier`
    ///
    /// # Return
    /// if `earlier` is later in time than `self`, this function returns a
    /// zeroed [Duration].
    fn duration_since(self, earlier: Self) -> core::time::Duration;
}

/// Allow time duration since the epoch
pub trait SinceEpoch: Since {
    /// The epoch to which `self` is relative to.
    ///
    /// see: [`Since::duration_since_epoch`]
    const EPOCH: Self;

    /// Get the [Duration] since its [Since::EPOCH]
    fn duration_since_epoch(self) -> core::time::Duration {
        self.duration_since(Self::EPOCH)
    }
}

/// Convertion from and to a Unix epoch
///
/// [SinceUnixEpoch::since_unix_epoch] creates an instant relative to Unix epoch
/// from a duration relative to a custom epoch
///
/// [SinceUnixEpoch::to_unix_epoch] creates an instant relative to the Unix
/// epoch from an instant relative to a custom epoch
pub trait SinceUnixEpoch {
    /// Convert a [`Duration`] since the start of 1970 to [`self`]
    ///
    /// The `duration` must be relative to the Unix epoch.
    fn since_unix_epoch(duration: core::time::Duration) -> Self;

    /// Transform [`self`] to be relative to the Unix epoch.
    ///
    /// If [`self`] is already relative to the Unix epoch, this is a no-op.
    fn to_unix_epoch(self) -> Self;
}

/// Create an time from a duration since its referential time.
pub trait FromDuration {
    fn from_duration(duration_since: Duration) -> Self;
}

/// A timestamp expressed in nanoseconds since [`Instant::EPOCH`]
type NanosecTimestamp = i64;

/// A timestamp expressed in nanoseconds since [`Instant::EPOCH`] with atomic
/// guarantees
type AtomicNanosecTimestamp = AtomicI64;

/// A point in time expressed in nanoseconds
///
/// Alone this structure does not mean anything. It is to be used along
/// [`net::Duration`](`core::time::Duration`).
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Eq, Ord)]
pub struct Instant(NanosecTimestamp);

impl Instant {
    /// Construct a [`Instant`] from a timestamp in nanosecond
    pub fn from_duration(duration_since: Duration) -> Self {
        Instant(duration_since.as_nanos().to_nanosec_timestamp())
    }

    pub fn saturating_add_duration(&self, dur: Duration) -> Self {
        let added = self
            .0
            .checked_add(dur.as_nanos().to_nanosec_timestamp())
            .unwrap();
        Instant(added)
    }
}

impl FromDuration for Instant {
    fn from_duration(duration_since: Duration) -> Self {
        Self::from_duration(duration_since)
    }
}

impl core::fmt::Display for Instant {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}[ns]", self.0)
    }
}

impl Add<core::time::Duration> for Instant {
    type Output = Self;

    fn add(self, duration: core::time::Duration) -> Self::Output {
        Self(
            self.0
                .saturating_add(duration.as_nanos().to_nanosec_timestamp()),
        )
    }
}

impl Sub<core::time::Duration> for Instant {
    type Output = Self;

    fn sub(self, rhs: core::time::Duration) -> Self::Output {
        Self(self.0.saturating_sub(rhs.as_nanos().to_nanosec_timestamp()))
    }
}

impl Sub<Instant> for Instant {
    type Output = Duration;

    fn sub(self, rhs: Instant) -> Self::Output {
        Duration::from_nanos(self.0.saturating_sub(rhs.0) as u64)
    }
}

impl Since for Instant {
    fn duration_since(self, earlier: Self) -> core::time::Duration {
        core::time::Duration::from_nanos(self.0.saturating_sub(earlier.0) as u64)
    }
}

/// A system time expressed as a timestamp in nanoseconds since Unix epoch.
///
/// This time is affected by NTP and manual changes on the system
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Eq, Ord)]
pub struct SystemTime(NanosecTimestamp);

impl FromDuration for SystemTime {
    fn from_duration(duration_since: Duration) -> Self {
        Self(duration_since.as_nanos().to_nanosec_timestamp())
    }
}

impl core::fmt::Display for SystemTime {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}[ns]", self.0)
    }
}

impl Add<Duration> for SystemTime {
    type Output = SystemTime;

    fn add(self, rhs: Duration) -> Self::Output {
        Self(self.0.saturating_add(rhs.as_nanos().to_nanosec_timestamp()))
    }
}

impl Sub<Duration> for SystemTime {
    type Output = SystemTime;

    fn sub(self, rhs: Duration) -> Self::Output {
        Self(self.0.saturating_sub(rhs.as_nanos().to_nanosec_timestamp()))
    }
}

impl Sub<SystemTime> for SystemTime {
    type Output = Duration;

    fn sub(self, rhs: Self) -> Self::Output {
        self.duration_since(rhs)
    }
}

impl Since for SystemTime {
    fn duration_since(self, earlier: Self) -> core::time::Duration {
        core::time::Duration::from_nanos(self.0.saturating_sub(earlier.0) as u64)
    }
}

impl SinceEpoch for SystemTime {
    const EPOCH: Self = SystemTime(0);
}

impl SinceUnixEpoch for SystemTime {
    fn since_unix_epoch(duration: core::time::Duration) -> Self {
        Self(duration.as_nanos().to_nanosec_timestamp())
    }

    fn to_unix_epoch(self) -> Self {
        self
    }
}

/// A factory of time
pub trait InstantFactory: Monotonic {
    /// The instant yield by this factory
    type Instant: Since + Add<Duration> + Sub<Duration>;

    /// Return the current time
    fn now(&self) -> Self::Instant;
}

impl<T: InstantFactory + Monotonic> InstantFactory for &T {
    type Instant = T::Instant;

    fn now(&self) -> Self::Instant {
        <T as InstantFactory>::now(*self)
    }
}

/// A factory of time
pub trait SystemTimeFactory {
    /// The instant yield by this factory
    type SystemTime: Since + SinceEpoch + Sub<Duration> + Add<Duration>;

    /// Return the current time
    fn now(&self) -> Self::SystemTime;
}

impl<T: ?Sized + SystemTimeFactory> SystemTimeFactory for &T {
    type SystemTime = T::SystemTime;

    fn now(&self) -> Self::SystemTime {
        <T as SystemTimeFactory>::now(*self)
    }
}

#[derive(Debug)]
/// Implementation of a time provider that delegates the computation of time to
/// the caller.
pub struct NativeTimeProvider<Publisher, InstantType = ()>(
    Arc<NativeTimeProviderInner<Publisher>>,
    PhantomData<InstantType>,
);

impl<Publisher: Clone, InstantType> Clone for NativeTimeProvider<Publisher, InstantType> {
    fn clone(&self) -> Self {
        Self(self.0.clone(), self.1.clone())
    }
}

#[derive(Debug)]
struct NativeTimeProviderInner<Publisher> {
    now: AtomicNanosecTimestamp,
    publisher: Publisher,
}

impl<Publisher: Default> Default for NativeTimeProviderInner<Publisher> {
    fn default() -> Self {
        Self {
            now: Default::default(),
            publisher: Default::default(),
        }
    }
}

impl<Publisher: Clone, InstantType> NativeTimeProvider<Publisher, InstantType> {
    pub fn publisher(&self) -> Publisher {
        self.0.publisher.clone()
    }
}

impl<Publisher, InstantType> AsRef<Publisher> for NativeTimeProvider<Publisher, InstantType> {
    fn as_ref(&self) -> &Publisher {
        &self.0.publisher
    }
}

impl<P: Default, I> Default for NativeTimeProvider<P, I> {
    fn default() -> Self {
        Self(Default::default(), Default::default())
    }
}

impl<P> NativeTimeProvider<P> {
    /// Create a new time provider.
    ///
    /// Initialize with a duration since the `Timepoint`'s EPOCH.
    pub fn new_since<Timepoint>(duration: core::time::Duration) -> NativeTimeProvider<P, Timepoint>
    where
        P: Default + Notify<Duration, Option<Duration>>,
        Timepoint: Since,
    {
        let this = NativeTimeProvider::<P, Timepoint>::default();
        this.set(duration);
        this
    }
}

impl<Publisher, InstantType> NativeTimeProvider<Publisher, InstantType> {
    /// Set the current time from a [Duration] since Unix epoch.
    ///
    /// Return the time frame during which the time
    pub fn set(&self, time: core::time::Duration) -> Deadline
    where
        Publisher: Notify<Duration, Deadline>,
    {
        self.0.now.store(
            time.as_nanos().to_nanosec_timestamp(),
            sync::atomic::Ordering::SeqCst,
        );

        self.0.publisher.notify(time)
    }

    pub fn expect_wakeup_before(&self) -> Deadline
    where
        Publisher: HasDeadline,
    {
        self.0.publisher.expect_wakeup_before()
    }
}

impl<Publisher: Sleep, InstantType: 'static> Sleep for NativeTimeProvider<Publisher, InstantType>
where
    for<'s> Publisher::Sleep<'s>: Send + Sync,
{
    type Sleep<'a>
        = Pin<Box<dyn Future<Output = ()> + Send + Sync + 'a>>
    where
        Self: 'a;

    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'_> {
        Box::pin(self.0.publisher.sleep(duration))
    }
}

impl<P> InstantFactory for NativeTimeProvider<P, Instant> {
    type Instant = Instant;

    fn now(&self) -> Instant {
        Instant(self.0.now.load(sync::atomic::Ordering::SeqCst))
    }
}

unsafe impl<P> Monotonic for NativeTimeProvider<P, Instant> {}

impl<P> SystemTimeFactory for NativeTimeProvider<P, SystemTime> {
    type SystemTime = SystemTime;

    fn now(&self) -> SystemTime {
        SystemTime(self.0.now.load(sync::atomic::Ordering::SeqCst))
    }
}

trait ToNanosecTimestamp: Copy {
    fn to_nanosec_timestamp(self) -> NanosecTimestamp;
}

impl ToNanosecTimestamp for u128 {
    fn to_nanosec_timestamp(self) -> NanosecTimestamp {
        self.min(i64::MAX as u128) as i64
    }
}

impl ToNanosecTimestamp for u64 {
    fn to_nanosec_timestamp(self) -> NanosecTimestamp {
        self.min(i64::MAX as u64) as i64
    }
}

#[cfg(test)]
mod tests {
    use core::time::Duration;
    use std::ops::Add as _;

    use super::*;
    use crate::time::{Instant, ToNanosecTimestamp};

    #[test]
    fn retrieve_inner_timestamp() {
        const EXPECTED_TS: i64 = 123456789;
        struct MySystemTime;

        impl SystemTimeFactory for MySystemTime {
            type SystemTime = super::SystemTime;

            fn now(&self) -> Self::SystemTime {
                SystemTime(EXPECTED_TS)
            }
        }

        assert_eq!(
            MySystemTime
                .now()
                .duration_since_epoch()
                .as_nanos()
                .to_nanosec_timestamp(),
            EXPECTED_TS
        );
    }

    #[test]
    fn add_duration_to_instant() {
        const EXPECTED_TS_NS: u64 = 123456789;
        struct MyInstant;
        unsafe impl Monotonic for MyInstant {}
        impl InstantFactory for MyInstant {
            type Instant = Instant;

            fn now(&self) -> Self::Instant {
                Instant(0)
            }
        }

        assert_eq!(
            MyInstant.now().add(Duration::from_nanos(EXPECTED_TS_NS),),
            Instant(EXPECTED_TS_NS.to_nanosec_timestamp())
        );
    }

    #[test]
    fn duration_since_epoch() {
        const EXPECTED_TS_NS: u64 = 123456789;

        struct MySystemTime;

        impl SystemTimeFactory for MySystemTime {
            type SystemTime = super::SystemTime;

            fn now(&self) -> Self::SystemTime {
                SystemTime(EXPECTED_TS_NS.to_nanosec_timestamp())
            }
        }
        assert_eq!(
            MySystemTime.now().duration_since_epoch(),
            Duration::from_nanos(EXPECTED_TS_NS)
        );
    }

    #[test]
    fn from_ns() {
        const EXPECTED_TS_NS: i64 = 123456789;
        const EXPECTED_TS: SystemTime = SystemTime(EXPECTED_TS_NS);
        assert_eq!(
            EXPECTED_TS
                .duration_since_epoch()
                .as_nanos()
                .to_nanosec_timestamp(),
            EXPECTED_TS_NS
        );
    }
}
