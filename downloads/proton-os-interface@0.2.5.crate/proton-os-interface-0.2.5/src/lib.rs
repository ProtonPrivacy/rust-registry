//! This library exposes interfaces to deal with platform specific operations,
//! such as time, networking, randomness, lock, and others.
//!
//! Using the present library allows you to be platform independent _and_
//! working in constrained environment where system calls are prohibited.

use crate::error::IntoSystemError;

pub mod error;

pub mod lock;

pub mod io;

pub mod rand;

pub mod time;

pub mod config;

pub mod resolve;

/// Allow to be notified by a given value and respond a given return value
pub trait Notify<T, Ret> {
    fn notify(&self, value: T) -> Ret;
}

/// An abstraction for a factory of something
///
/// # Note
/// This can be an abstraction of the socket() syscall
pub trait Create<Handle> {
    type Err: IntoSystemError;
    fn create(&self) -> Result<Handle, Self::Err>;
}
