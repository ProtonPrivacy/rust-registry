use core::borrow::BorrowMut;
use core::mem::MaybeUninit;

pub use rand_core::*;

/// Derive a pRNG from another crypto-safe pRNG.
///
/// A blanket implementation is provided is the pRNG to derive implements
/// [`SeedableRng`] with a [`Default`] [`SeedableRng::Seed`]
pub trait DeriveRng: CryptoRng {
    fn derive<T: SeedableRng>(self) -> T
    where
        T::Seed: Default + BorrowMut<[u8]>;
}

impl<This: CryptoRng> DeriveRng for &mut This {
    fn derive<T: SeedableRng>(self) -> T
    where
        T::Seed: Default + BorrowMut<[u8]>,
    {
        let mut seed = T::Seed::default();
        self.fill_bytes(seed.borrow_mut());
        T::from_seed(seed)
    }
}

/// A compatibility layer between `rand_core=0.9.x` and `rand_core=0.6.x`
#[derive(Debug)]
pub struct RngCompat<T>(T);

impl<T: rand_core::RngCore> RngCompat<T> {
    pub fn new(value: T) -> Self {
        Self(value)
    }
}

/// Implement the `rand_core 0.6` RNG trait.
///
/// Since the newer trait is infallible, this simply creates a
/// `try_fill_bytes` function that never returns an error.
impl<T: rand_core::RngCore> rand_core_0_6::RngCore for RngCompat<T> {
    fn next_u32(&mut self) -> u32 {
        self.0.next_u32()
    }

    fn next_u64(&mut self) -> u64 {
        self.0.next_u64()
    }

    fn fill_bytes(&mut self, dst: &mut [u8]) {
        self.0.fill_bytes(dst)
    }

    fn try_fill_bytes(&mut self, dst: &mut [u8]) -> Result<(), rand_core_0_6::Error> {
        self.0.fill_bytes(dst);
        Ok(())
    }
}

impl<T: rand_core::CryptoRng> rand_core_0_6::CryptoRng for RngCompat<T> {}

/// A crypto secure seed generator
///
/// Use this when you want to ensure that the seed you provide is unpredictable
///
/// ```
/// # fn ensure_safely_seeded(seed: Seed256) -> impl RngCore {
/// #    rand::rngs::SmallRng::from_seed(seed.into())
/// # }
/// use proton_os_interface::rand::{CryptoSeedProvider, RngCore, Seed256, SeedableRng};
/// # use rand_latest as rand;
///
/// let sp = CryptoSeedProvider::new(rand::rng());
/// let seed: Seed256 = sp.into();
/// let mut rng = ensure_safely_seeded(seed);
/// rng.next_u32();
/// ```
pub struct CryptoSeedProvider<T>(T);

impl<T: rand_core::CryptoRng> CryptoSeedProvider<T> {
    pub fn new(crypto_rng: T) -> Self {
        Self(crypto_rng)
    }
}

/// Seed that is being populated from a [`CryptoRng`].
///
/// Use this when you want to ensure that a seed provider generate a seed
/// correctly
pub struct Seed512([u8; 64]);
impl From<Seed512> for [u8; 64] {
    fn from(val: Seed512) -> Self {
        val.0
    }
}

/// Seed that is being populated from a [`CryptoRng`].
///
/// Use this when you want to ensure that a seed provider generate a seed
/// correctly
pub struct Seed256([u8; 32]);
impl From<Seed256> for [u8; 32] {
    fn from(val: Seed256) -> Self {
        val.0
    }
}

/// Seed that is being populated from a [`CryptoRng`].
///
/// Use this when you want to ensure that a seed provider generate a seed
/// correctly
pub struct Seed128([u8; 16]);
impl From<Seed128> for [u8; 16] {
    fn from(val: Seed128) -> Self {
        val.0
    }
}

impl<T: rand_core::CryptoRng> From<CryptoSeedProvider<T>> for Seed512 {
    fn from(val: CryptoSeedProvider<T>) -> Self {
        Seed512(fill_bytes(val.0))
    }
}

impl<T: rand_core::CryptoRng> From<CryptoSeedProvider<T>> for Seed256 {
    fn from(val: CryptoSeedProvider<T>) -> Self {
        Seed256(fill_bytes(val.0))
    }
}

impl<T: rand_core::CryptoRng> From<CryptoSeedProvider<T>> for Seed128 {
    fn from(val: CryptoSeedProvider<T>) -> Self {
        Seed128(fill_bytes(val.0))
    }
}

fn fill_bytes<const BYTES: usize>(mut crypto_prng: impl CryptoRng) -> [u8; BYTES] {
    let mut uninit_array: MaybeUninit<[u8; BYTES]> = MaybeUninit::uninit();
    let buf: &mut [u8] = unsafe { &mut *uninit_array.as_mut_ptr() }; // nosemgrep
    crypto_prng.fill_bytes(buf);
    unsafe { uninit_array.assume_init() } // nosemgrep
}

#[cfg(test)]
mod tests {
    use rand_latest as rand;

    use crate::rand::*;

    #[test]
    fn derive_rng() {
        let mut origin = rand::rng();
        let mut derived: rand::rngs::SmallRng = origin.derive();
        assert_ne!(derived.next_u32(), origin.next_u32());
    }

    #[test]
    fn fill_random_bytes() {
        let buf = fill_bytes::<512>(rand::rng());
        println!("{buf:?}");
        let _ = fill_bytes::<256>(rand::rng());
        println!("{buf:?}");
        let _ = fill_bytes::<128>(rand::rng());
        println!("{buf:?}");
    }

    #[test]
    fn into_seeds() {
        let expected_buf_128: [u8; 16] = [12u8; 16];
        let seed = Seed128(expected_buf_128);
        let buf: [u8; 16] = seed.into();
        assert_eq!(buf, expected_buf_128);
        let expected_buf_256: [u8; 32] = [12u8; 32];
        let seed = Seed256(expected_buf_256);
        let buf: [u8; 32] = seed.into();
        assert_eq!(buf, expected_buf_256);
        let expected_buf_512: [u8; 64] = [12u8; 64];
        let seed = Seed512(expected_buf_512);
        let buf: [u8; 64] = seed.into();
        assert_eq!(buf, expected_buf_512);
    }

    #[test]
    fn from_crypto_provider() {
        struct TestProvider;
        impl super::CryptoRng for TestProvider {}
        impl super::RngCore for TestProvider {
            fn next_u32(&mut self) -> u32 {
                0
            }

            fn next_u64(&mut self) -> u64 {
                0
            }

            fn fill_bytes(&mut self, dst: &mut [u8]) {
                dst.fill(0xAE);
            }
        }

        fn check<Seed, Provider: CryptoRng>(provider: Provider, check: impl FnOnce(Seed))
        where
            Seed: From<CryptoSeedProvider<Provider>>,
        {
            let sp = CryptoSeedProvider::new(provider);
            let seed: Seed = sp.into();
            check(seed)
        }
        check::<Seed128, TestProvider>(TestProvider, |seed| assert_eq!(seed.0, [0xAE; 16]));
        check::<Seed256, TestProvider>(TestProvider, |seed| assert_eq!(seed.0, [0xAE; 32]));
        check::<Seed512, TestProvider>(TestProvider, |seed| assert_eq!(seed.0, [0xAE; 64]));
    }
}
