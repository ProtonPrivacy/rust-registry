use core::marker::PhantomData;
use core::pin::Pin;
use core::task::Poll;

use crate::Create;
use crate::error::IntoSystemError;

/// A socket trait alias
///
/// This uses futures async read/write because it is a bit messy to forces
/// everyone to use those in the current crate
pub trait Socket: futures::AsyncRead + futures::AsyncWrite + Unpin + Send + 'static {}
impl<This: futures::AsyncRead + futures::AsyncWrite + Unpin + Send + 'static> Socket for This {}

/// An abstraction for types that can attach to a local resource.
///
/// The typical implementation is an implementation of the bind syscall (see
/// below).
///
/// # Example
/// ```
/// # use core::net::SocketAddr;
/// # use proton_os_interface::error::*;
/// # use proton_os_interface::io::*;
/// struct ClosedSocket {
///     local_addr: Option<core::net::SocketAddr>,
/// }
///
/// impl Bind<core::net::SocketAddr> for ClosedSocket {
///     type Err = std::io::Error;
///
///     fn bind(mut self, resource: core::net::SocketAddr) -> Result<Self, Self::Err>
///     where
///         Self: Sized,
///     {
///         self.local_addr = Some(resource);
///         Ok(self)
///     }
/// }
/// ```
pub trait Bind<Resource> {
    type Err: IntoSystemError;
    fn bind(self, resource: Resource) -> Result<Self, Self::Err>
    where
        Self: Sized;
}

/// An abstraction for types that can become a listener of incoming clients
///
/// This trait yields a new type that can accept clients
///
/// # Note
/// the backlog defines how many client can be in the accept wait queue. This
/// may not be supported on many platform and it is free to ignore.
///
/// # Example
/// ```
/// # use proton_os_interface::error::*;
/// # use proton_os_interface::io::*;
/// # pub struct MyTcpListener(pub std::net::TcpListener);
/// # #[derive(Debug, thiserror::Error)]
/// # #[error("{0}")]
/// # struct MyIoError(std::io::Error);
/// # impl IntoSystemError for MyIoError {
/// #     fn into_system_error(self) -> SystemError {
/// #         SystemError::Unknown(None)
/// #     }
/// # }
///
/// struct ClosedSocket {
///     local_addr: Option<core::net::SocketAddr>,
/// }
///
/// impl Listen<'_, MyTcpListener> for ClosedSocket {
///     type Err = std::io::Error;
///
///     fn listen(self, _: Option<u32>) -> Result<MyTcpListener, Self::Err> {
///         Ok(MyTcpListener(std::net::TcpListener::bind(
///             self.local_addr
///                 .unwrap_or((std::net::Ipv4Addr::UNSPECIFIED, 0).into()),
///         )?))
///     }
/// }
/// ```
pub trait Listen<'a, Handle: 'a> {
    type Err: IntoSystemError;
    /// Create a listener and set the backlog size, if any
    fn listen(self, backlog: Option<u32>) -> Result<Handle, Self::Err>;
}

/// An abstraction for types that can become a listener of incoming clients
///
/// This trait yields a new type that can accept clients
///
/// # Note
/// the backlog defines how many client can be in the accept wait queue. This
/// may not be supported on many platform and it is free to ignore.
///
/// # Example
/// ```
/// # use proton_os_interface::error::*;
/// # use proton_os_interface::io::*;
/// # use std::marker::PhantomData;
/// # pub struct MyTcpListener<'a>(pub std::net::TcpListener, pub PhantomData<&'a ()>);
///
/// # impl MyTcpListener<'_> {
/// #     pub fn new(listener: std::net::TcpListener) -> Self {
/// #         Self(listener, PhantomData)
/// #     }
/// # }
/// # pub struct MyTcpStream<'a>(std::net::TcpStream, PhantomData<&'a()>);
///
/// impl<'a> Accept<'a> for MyTcpListener<'a> {
///     type ClientStream = MyTcpStream<'a>;
///     type Err = std::io::Error;
///
///     fn accept(&self) -> Result<Self::ClientStream, Self::Err> {
///         Ok(MyTcpStream(self.0.accept()?.0, PhantomData))
///     }
/// }
/// ```
pub trait Accept<'a> {
    /// The client stream that has been accepted
    type ClientStream: 'a;

    type Err: IntoSystemError;

    /// Accept a new client if some are in the queue
    fn accept(&self) -> Result<Self::ClientStream, Self::Err>;
}

/// Abstraction for types that can connect to a remote resource and become
/// "connected"
///
/// # Note
/// This can be an abstraction over the connect() syscall or open() syscall
///
/// # Example `connect(2)`
/// ```
/// # use proton_os_interface::error::*;
/// # use proton_os_interface::io::*;
/// # use proton_os_interface::io::*;
/// # #[derive(Debug, thiserror::Error)]
/// # #[error("{0}")]
/// # struct MyIoError(std::io::Error);
/// # impl IntoSystemError for MyIoError {
/// #     fn into_system_error(self) -> SystemError {
/// #         SystemError::Unknown(None)
/// #     }
/// # }
/// # struct ClosedSocket;
///
/// struct MyTcpStream(std::net::TcpStream);
///
/// impl Connect<'_, core::net::SocketAddr, MyTcpStream> for ClosedSocket {
///     type Err = std::io::Error;
///
///     fn connect(self, resource: core::net::SocketAddr) -> Result<MyTcpStream, Self::Err> {
///         Ok(MyTcpStream(std::net::TcpStream::connect(resource)?))
///     }
/// }
/// ```
///
/// /// # Example `open(2)`
/// ```
/// # use proton_os_interface::error::*;
/// # use proton_os_interface::io::*;
/// # use proton_os_interface::io::*;
/// # #[derive(Debug, thiserror::Error)]
/// # #[error("{0}")]
/// # struct MyIoError(std::io::Error);
/// # impl IntoSystemError for MyIoError {
/// #     fn into_system_error(self) -> SystemError {
/// #         SystemError::Unknown(None)
/// #     }
/// # }
/// # struct ClosedFile;
///
/// struct OpenedFile(std::fs::File);
///
/// impl<'a, P: AsRef<std::path::Path>> Connect<'a, P, OpenedFile> for ClosedFile {
///     type Err = std::io::Error;
///
///     fn connect(self, resource: P) -> Result<OpenedFile, Self::Err> {
///         Ok(OpenedFile(std::fs::File::open(resource)?))
///     }
/// }
/// ```
pub trait Connect<'a, Resource, Handle: 'a> {
    type Err: IntoSystemError;
    fn connect(self, resource: Resource) -> Result<Handle, Self::Err>;
}

/// The async counterpart of [`Connect`].
pub trait AsyncConnect<'a, Resource, Handle: 'a> {
    type Err: IntoSystemError;
    fn connect(self, resource: Resource) -> impl Future<Output = Result<Handle, Self::Err>>;
}

/// A type capable of dialing remote hosts.
pub trait TcpConnect: Clone {
    type Err: IntoSystemError;
    type Socket: Socket;

    /// Open a connection to the given socket address.
    fn tcp_connect(
        &self,
        addr: core::net::SocketAddr,
    ) -> impl std::future::Future<Output = Result<Self::Socket, Self::Err>>;

    /// Open a connection to the given ip and port.
    fn tcp_connect_split(
        &self,
        ip: core::net::IpAddr,
        port: u16,
    ) -> impl std::future::Future<Output = Result<Self::Socket, Self::Err>> {
        self.tcp_connect((ip, port).into())
    }
}

/// A compatibility layer between [`Create`] => [`AsyncConnect`] and
/// [`TcpConnect`].
///
/// They are basically the same, just that the former design decouples creation
/// and connection
#[derive(Debug)]
pub struct Connector<
    'a,
    Factory: Create<AsyncConnector> + Clone,
    AsyncConnector: AsyncConnect<'a, std::net::SocketAddr, IO>,
    IO: Socket,
>(Factory, PhantomData<&'a AsyncConnector>, PhantomData<IO>);

impl<
    'a,
    Factory: Create<AsyncConnector> + Clone,
    AsyncConnector: AsyncConnect<'a, std::net::SocketAddr, IO>,
    IO: Socket,
> Clone for Connector<'a, Factory, AsyncConnector, IO>
{
    fn clone(&self) -> Self {
        Self(self.0.clone(), self.1.clone(), self.2.clone())
    }
}

impl<
    Factory: Create<AsyncConnector> + Clone,
    AsyncConnector: AsyncConnect<'static, std::net::SocketAddr, IO, Err = Factory::Err>,
    IO: Socket,
> TcpConnect for Connector<'static, Factory, AsyncConnector, IO>
where
    Factory::Err: Send + Sync,
    AsyncConnector::Err: Send + Sync,
{
    type Err = AsyncConnector::Err;
    type Socket = IO;

    async fn tcp_connect(&self, addr: core::net::SocketAddr) -> Result<Self::Socket, Self::Err> {
        self.0.create()?.connect(addr).await
    }
}

/// See [`std::io::Read`]
pub trait Read {
    type Err: IntoSystemError;
    fn read(&mut self, buf: &mut [u8]) -> Result<usize, Self::Err>;
}

/// See [`std::io::Write`]
pub trait Write {
    type Err: IntoSystemError;
    fn write(&mut self, buf: &[u8]) -> Result<usize, Self::Err>;
}

/// The peek operation allows to [`Read::read`] an IO resource without pulling
/// out the data that has been read.
///
/// Two peek operations yield the same data if no [`Read::read`] has been done
/// in between
pub trait Peek {
    type Err: IntoSystemError;

    fn peek(&self, buf: &mut [u8]) -> Result<usize, Self::Err>;
}

/// Async counter part of [`Peek`]
pub trait AsyncPeek {
    type Err: IntoSystemError;

    fn poll_peek(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
        buf: &mut [u8],
    ) -> Poll<Result<usize, Self::Err>>;
}

/// Async counter part of [`Read`]
pub trait AsyncRead {
    type Err: IntoSystemError;
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
        buf: &mut [u8],
    ) -> Poll<Result<usize, Self::Err>>;
}

#[cfg(feature = "futures-io-compat")]
impl<This: futures::AsyncRead> AsyncRead for This {
    type Err = std::io::Error;

    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
        buf: &mut [u8],
    ) -> Poll<Result<usize, Self::Err>> {
        self.poll_read(cx, buf)
    }
}

/// Async counter part of [`Write`]
pub trait AsyncWrite {
    type Err: IntoSystemError;

    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
        buf: &[u8],
    ) -> Poll<Result<usize, Self::Err>>;

    fn poll_flush(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
    ) -> Poll<Result<(), Self::Err>>;

    fn poll_close(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
    ) -> Poll<Result<(), Self::Err>>;
}

#[cfg(feature = "futures-io-compat")]
impl<This: futures::AsyncWrite> AsyncWrite for This {
    type Err = std::io::Error;

    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
        buf: &[u8],
    ) -> Poll<Result<usize, Self::Err>> {
        self.poll_write(cx, buf)
    }

    fn poll_flush(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
    ) -> Poll<Result<(), Self::Err>> {
        self.poll_flush(cx)
    }

    fn poll_close(
        self: Pin<&mut Self>,
        cx: &mut core::task::Context<'_>,
    ) -> Poll<Result<(), Self::Err>> {
        self.poll_close(cx)
    }
}
