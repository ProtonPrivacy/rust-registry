/// An error that can happen on the system
///
/// For details please see [`std::io::ErrorKind`]
#[derive(Debug, Clone, Copy, PartialEq, Eq, thiserror::Error)]
#[non_exhaustive]
pub enum SystemError {
    #[error("unknown error errno={0:?}")]
    Unknown(Option<i32>),

    #[error("timed out")]
    Timeout,

    #[error("connection reset by peer")]
    ConnectionReset,

    #[error("application error")]
    ApplicationError,

    #[error("host unreachable")]
    HostUnreachable,

    #[error("network is unreachable")]
    NetworkUnreachable,

    #[error("address already in use")]
    AddressInUse,

    #[error("connection aborted")]
    ConnectionAborted,

    #[error("entity already exists")]
    AlreadyExists,

    #[error("address not available")]
    AddrNotAvailable,

    #[error("not connected")]
    NotConnected,

    #[error("connection has been refused")]
    ConnectionRefused,

    #[error("broken pipe")]
    BrokenPipe,

    #[error("entity not found")]
    NotFound,

    #[error("system's network is down")]
    NetworkDown,

    #[error("permission denied")]
    PermissionDenied,

    #[error("would have blocked")]
    WouldBlock,

    #[error("in progress")]
    InProgress,

    #[error("interrupted")]
    Interrupted,

    #[error("a parameter was incorrect")]
    InvalidInput,

    #[error("data is not valid")]
    InvalidData,

    #[error("unallowed partial write")]
    WriteZero,

    #[error("quota exceeded")]
    QuotaExceeded,

    #[error("resource is busy")]
    ResourceBusy,

    #[error("unexpected end of file")]
    UnexpectedEof,
}

/// A result type that returns [`SystemError`] on error
pub type SystemResult<T> = Result<T, SystemError>;

/// Allow conversion between platform specific errors into [`SystemError`]
///
/// # Example
/// ```
/// # use proton_os_interface::error::*;
/// #[derive(Debug, thiserror::Error)]
/// #[error("{0}")]
/// struct MyIoError(std::io::Error);
///
/// impl IntoSystemError for MyIoError {
///     fn into_system_error(self) -> SystemError {
///         match self.0.kind() {
///             std::io::ErrorKind::HostUnreachable => SystemError::HostUnreachable,
///             std::io::ErrorKind::ConnectionReset => SystemError::ConnectionReset,
///             // ... match the other ones ...
///             _ => SystemError::Unknown(None),
///         }
///     }
/// }
/// ```
pub trait IntoSystemError: core::error::Error {
    fn into_system_error(self) -> SystemError;
}

impl IntoSystemError for SystemError {
    fn into_system_error(self) -> SystemError {
        self
    }
}

#[cfg(feature = "std")]
impl IntoSystemError for std::io::Error {
    fn into_system_error(self) -> SystemError {
        match self.kind() {
            std::io::ErrorKind::ConnectionRefused => SystemError::ConnectionRefused,
            std::io::ErrorKind::ConnectionReset => SystemError::ConnectionReset,
            std::io::ErrorKind::TimedOut => SystemError::Timeout,
            std::io::ErrorKind::AddrInUse => SystemError::AddressInUse,
            std::io::ErrorKind::BrokenPipe => SystemError::BrokenPipe,
            std::io::ErrorKind::HostUnreachable => SystemError::HostUnreachable,
            std::io::ErrorKind::NetworkUnreachable => SystemError::NetworkUnreachable,
            std::io::ErrorKind::ConnectionAborted => SystemError::ConnectionAborted,
            std::io::ErrorKind::NotConnected => SystemError::NotConnected,
            std::io::ErrorKind::NotFound => SystemError::NotFound,
            std::io::ErrorKind::PermissionDenied => SystemError::PermissionDenied,
            std::io::ErrorKind::AddrNotAvailable => SystemError::AddrNotAvailable,
            std::io::ErrorKind::NetworkDown => SystemError::NetworkDown,
            std::io::ErrorKind::AlreadyExists => SystemError::AlreadyExists,
            std::io::ErrorKind::WouldBlock => SystemError::WouldBlock,
            std::io::ErrorKind::InvalidInput => SystemError::InvalidInput,
            std::io::ErrorKind::InvalidData => SystemError::InvalidData,
            std::io::ErrorKind::WriteZero => SystemError::WriteZero,
            std::io::ErrorKind::QuotaExceeded => SystemError::QuotaExceeded,
            std::io::ErrorKind::ResourceBusy => SystemError::ResourceBusy,
            std::io::ErrorKind::Interrupted => SystemError::Interrupted,
            std::io::ErrorKind::UnexpectedEof => SystemError::UnexpectedEof,
            _ => SystemError::Unknown(self.raw_os_error()),
        }
    }
}

#[cfg(test)]
mod tests {
    use std::io::ErrorKind;

    use crate::error::*;

    #[test]
    fn from_custom_error() {
        #[derive(Debug, thiserror::Error)]
        #[error("{0}")]
        struct MyIoError(std::io::Error);

        impl IntoSystemError for MyIoError {
            fn into_system_error(self) -> SystemError {
                match self.0.kind() {
                    ErrorKind::AddrInUse => SystemError::AddressInUse,
                    _ => panic!(),
                }
            }
        }

        let expected_err = std::io::ErrorKind::AddrInUse.into();
        let my_error = MyIoError(expected_err);

        assert!(matches!(
            my_error.into_system_error(),
            SystemError::AddressInUse
        ))
    }
}
