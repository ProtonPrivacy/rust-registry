use crate::lock::private::Sealed;
use crate::lock::{Mutex, MutexFactory};

/// A locking mode that is strict and block when already locked.
///
/// When used, a call to `lock()` may blocking
#[derive(Debug)]
pub struct Strict;
impl Sealed for Strict {}
impl MutexFactory for Strict {
    fn new<T>(value: T) -> Mutex<T> {
        Mutex::Strict(std::sync::Mutex::new(value))
    }
}
