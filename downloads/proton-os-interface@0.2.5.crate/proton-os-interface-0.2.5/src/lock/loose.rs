use core::cell::UnsafeCell;
use core::ops::{Deref, DerefMut};
use core::sync::atomic::AtomicBool;
use std::sync::Arc;

use super::private::Sealed;
use crate::lock::{Lock, LockFactory, Mutex, MutexFactory};

/// A locking mode that is uncheacked and panic when already locked.
///
/// When used, a call to `lock()` never block but may panic
#[derive(Debug)]
pub struct Loose;
impl Sealed for Loose {}
impl MutexFactory for Loose {
    fn new<T>(value: T) -> Mutex<T> {
        Mutex::Loose(LooseMutex::new(value))
    }
}
impl LockFactory for Loose {
    type Lock<T> = Mutex<T>;

    fn new<'a, T>(value: T) -> Self::Lock<T>
    where
        Self: Sized,
    {
        Mutex::new::<Self>(value)
    }
}

#[derive(Debug)]
pub struct LooseMutex<T: ?Sized> {
    lock: Arc<core::sync::atomic::AtomicBool>,
    inner: core::cell::UnsafeCell<T>,
}

impl<T> LooseMutex<T> {
    pub fn new(inner: T) -> Self {
        Self {
            lock: Arc::new(AtomicBool::new(false)),
            inner: UnsafeCell::new(inner),
        }
    }
}

impl<'a, T> Lock<'a, T> for LooseMutex<T> {
    type Guard
        = LooseGuard<'a, T>
    where
        Self: 'a;

    fn lock(&'a self) -> Self::Guard {
        if self.lock.swap(true, std::sync::atomic::Ordering::SeqCst) {
            panic!("lock already acquired")
        } else {
            LooseGuard(self)
        }
    }
}
// Arc<AtomicBool> is Send/Sync hence it is Send/Sync if T is
// nosemgrep
unsafe impl<T: ?Sized + Send> Send for LooseMutex<T> {}
// Arc<AtomicBool> is Send/Sync hence it is Send/Sync if T is
// nosemgrep
unsafe impl<T: ?Sized + Send> Sync for LooseMutex<T> {}

/// When a [LooseMutex] is locked, this guard allows to manipulate
/// the inner object
pub struct LooseGuard<'a, T: ?Sized + 'a>(&'a LooseMutex<T>);

impl<T: ?Sized> Drop for LooseGuard<'_, T> {
    fn drop(&mut self) {
        assert!(
            self.0.lock.swap(false, std::sync::atomic::Ordering::SeqCst),
            "BUG: lock has never been acquired"
        );
    }
}

impl<'a, T> Deref for LooseGuard<'a, T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        // SAFETY: because we already have a &self, it is safe to get case the
        // inner to a &T.

        // nosemgrep
        unsafe { &*self.0.inner.get() }
    }
}

impl<'a, T> DerefMut for LooseGuard<'a, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        // SAFETY: because we already have a &mut self, it is safe to get case the
        // inner to a &mut T.

        // nosemgrep
        unsafe { &mut *self.0.inner.get() }
    }
}

// Arc<AtomicBool> is Send/Sync hence it is Send/Sync if T is
// nosemgrep
unsafe impl<T: ?Sized + Sync> Sync for LooseGuard<'_, T> {}

#[cfg(test)]
mod tests {

    use super::*;

    #[should_panic]
    #[test]
    fn unchecked_lock_panic() {
        let lock = Mutex::new::<Loose>("abc");
        let _g1 = lock.lock();
        let _g2 = lock.lock();
    }
}
