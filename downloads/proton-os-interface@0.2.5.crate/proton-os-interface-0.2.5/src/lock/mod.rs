mod loose;
use core::ops::{Deref, DerefMut};

use derive_more::From;
pub use loose::*;

use crate::lock::private::Sealed;

/// A factory to create instances of [`Lock`] implementors.
pub trait LockFactory {
    type Lock<T>: for<'a> Lock<'a, T>;

    fn new<T>(value: T) -> Self::Lock<T>
    where
        Self: Sized;
}

/// An implementation of a mutual exclusion lock that uses RAII.
pub trait Lock<'a, T: ?Sized> {
    type Guard: Deref<Target = T> + DerefMut + 'a
    where
        Self: 'a;

    fn lock(&'a self) -> Self::Guard;
}

#[cfg(feature = "std")]
pub mod strict;

#[cfg(feature = "std")]
pub use strict::*;

/// A guard that ensure the mutex is locked and can not be acquired a second
/// time.
///
/// This guard is usable in std and no_std contexts.
///
/// Upon destruction, it releases the mutex
pub enum Guard<'a, T> {
    #[cfg(feature = "std")]
    Strict(std::sync::MutexGuard<'a, T>),
    Loose(LooseGuard<'a, T>),
}

impl<'a, T> Deref for Guard<'a, T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        match self {
            #[cfg(feature = "std")]
            Guard::Strict(mutex_guard) => mutex_guard.deref(),
            Guard::Loose(unchecked_guard) => unchecked_guard.deref(),
        }
    }
}

impl<'a, T> DerefMut for Guard<'a, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        match self {
            #[cfg(feature = "std")]
            Guard::Strict(mutex_guard) => mutex_guard.deref_mut(),
            Guard::Loose(unchecked_guard) => unchecked_guard.deref_mut(),
        }
    }
}

#[derive(Debug, From)]
/// A [`Strict`](std::sync::Mutex) or [`Loose`](`LooseMutex`) lock
pub enum Mutex<T> {
    #[cfg(feature = "std")]
    Strict(std::sync::Mutex<T>),
    Loose(LooseMutex<T>),
}

impl<T> Mutex<T> {
    pub fn new<MutexType: MutexFactory>(value: T) -> Self {
        MutexType::new::<T>(value)
    }

    /// Try to lock the mutex.
    ///
    /// - See [`Strict`] for the strict behavior
    /// - See [`Loose`] for the unchecked behavior
    pub fn lock(&'_ self) -> Guard<'_, T> {
        match self {
            #[cfg(feature = "std")]
            Mutex::Strict(lock_inner) => {
                Guard::Strict(lock_inner.lock().expect("BUG: poisoned lock"))
            }
            Mutex::Loose(lock_inner) => Guard::Loose(lock_inner.lock()),
        }
    }
}

impl<'a, T> Lock<'a, T> for Mutex<T> {
    type Guard
        = Guard<'a, T>
    where
        Self: 'a;

    fn lock(&'a self) -> Self::Guard {
        self.lock()
    }
}

/// A factory to create [Mutex<Loose>] or [Mutex<Strict>]
///
/// # Details see
/// [Loose] and [Strict]
///
/// # Note
/// You need feature `std` to enable [`Strict`] locking
pub trait MutexFactory: Sealed {
    #[allow(clippy::new_ret_no_self)]
    fn new<T>(value: T) -> Mutex<T>;
}

pub(crate) mod private {

    pub trait Sealed {}
}
