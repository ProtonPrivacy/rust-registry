use crate::error::IntoSystemError;

/// A type capable of resolving routes.
pub trait Resolve: Clone {
    type Err: IntoSystemError;
    /// Resolve the given host to a set of addresses.
    fn resolve(
        &self,
        host: &str,
    ) -> impl std::future::Future<Output = Result<Vec<core::net::IpAddr>, Self::Err>>;
}

#[cfg(test)]
mod tests {
    use std::net::ToSocketAddrs as _;

    use crate::resolve::Resolve;

    #[derive(Debug, Clone)]
    struct OsResolver;

    impl Resolve for OsResolver {
        type Err = std::io::Error;

        fn resolve(
            &self,
            host: &str,
        ) -> impl std::future::Future<Output = Result<Vec<core::net::IpAddr>, Self::Err>> {
            async { Ok(host.to_socket_addrs()?.map(|addr| addr.ip()).collect()) }
        }
    }

    #[tokio::test]
    async fn test_resolve_using_os() {
        let ips = OsResolver.resolve("ip.me:0").await.unwrap();

        assert!(ips.contains(&"212.102.35.236".parse().unwrap()));
    }
}
