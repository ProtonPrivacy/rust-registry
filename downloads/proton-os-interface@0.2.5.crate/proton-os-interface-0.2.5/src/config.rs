use crate::error::*;

/// An abstraction for types that can be configured
///
/// - Config elements that are MANDATORY MUST return an error.
///
/// - Config elements that are OPTIONAL MUST return the structure and emit a
///   warning log
///
/// # Example
/// ```
/// # use proton_os_interface::error::*;
/// # use proton_os_interface::config::*;
/// # struct MyTcpSocket;
///
/// # fn setsockopt<T>(value: T) -> SystemResult<()> {
/// #     Ok(())
/// # }
///
/// impl Configure for MyTcpSocket {
///     type Config = TcpSocketConfig;
///
///     fn configure(&self, config: &Self::Config) -> SystemResult<()> {
///         if let Some(keep_alive) = config.keep_alive {
///             setsockopt(keep_alive)?; // this is advised to be fatal
///         }
///
///         if let Some(disable_nable) = config.disable_nagle {
///             // soft error handling
///             let _ = setsockopt(disable_nable);
///         }
///         // ...
///         Ok(())
///     }
/// }
/// ```
pub trait Configure {
    type Config;
    fn configure(&self, config: &Self::Config) -> SystemResult<()>;
}

/// Configuration options for a TCP Socket
#[derive(Debug, Default, Clone, PartialEq, Eq, serde::Deserialize)]
pub struct TcpSocketConfig {
    /// Disable the Nagle's Algorithm
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    #[serde(alias = "disable-nagle")]
    pub disable_nagle: Option<bool>,
    /// Enable the TCP keep-alive feature.
    ///
    /// # Error
    /// Must return a [`SystemError`] if this option fails to be set
    #[serde(alias = "keep-alive")]
    pub keep_alive: Option<bool>,
    /// Allows binding to an already used address (only if this option is also
    ///  set on the bound socket)
    ///
    /// # Error
    /// Must return a [`SystemError`] if this option fails to be set
    ///
    /// # Note(multicast): this is identical to [`TcpSocketConfig::reuse_addr`],
    #[serde(alias = "reuse-port")]
    pub reuse_port: Option<bool>,
    /// - Allows binding to an address used by an half-dead socket (TIME_WAIT)
    /// - Allows binding to an address already used by a wildcard
    ///
    /// # Error
    /// Must return a [`SystemError`] if this option fails to be set
    ///
    /// # Note(multicast): this is identical to [`TcpSocketConfig::reuse_port`],
    #[serde(alias = "reuse-addr")]
    pub reuse_addr: Option<bool>,
    /// Allows binding to addresses that are not considered local
    ///
    /// # Error
    /// Must return a [`SystemError`] if this option fails to be set
    pub transparent: Option<bool>,
    /// Apply a mark on the socket:
    ///
    /// # Error
    /// Must return a [`SystemError`] if this option fails to be set
    pub mark: Option<i8>,
    /// Send ACKs immediately rather than delayed (quickack mode)
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    #[serde(alias = "quick-ack")]
    pub quick_ack: Option<bool>,
    /// Set the congestion algorithm
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    pub congestion_algorithm: Option<String>,
    /// Enable TCP Fast Open (RFC 7413)
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    pub fastopen: Option<bool>,
    /// Set the send buffer size in bytes
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    pub sndbuf: Option<u32>,
    /// Set the receive buffer size in bytes
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    pub rcvbuf: Option<u32>,
    /// Allow overriding the maximum allowed memory for receive and send
    /// buffers.
    ///
    /// # Error
    /// Generate a warn log if this option fails to be set
    #[serde(default)]
    pub use_bufforce: bool,
}

#[derive(Debug, Copy, Clone, Default, PartialEq, serde::Deserialize)]
pub struct UdpSocketConfig {
    // TODO: Add more configuration options
    pub transparent: Option<bool>,

    pub mark: Option<i8>,

    #[serde(alias = "reuse-port")]
    pub reuse_port: Option<bool>,
}
