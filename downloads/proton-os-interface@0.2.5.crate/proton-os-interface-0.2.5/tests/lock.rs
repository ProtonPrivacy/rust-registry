use std::sync::{Mutex, MutexGuard};

use proton_os_interface::lock::*;

struct MutexFactory;

impl LockFactory for MutexFactory {
    type Lock<X> = MyMutex<X>;

    fn new<'a, T>(value: T) -> Self::Lock<T>
    where
        Self: Sized,
    {
        MyMutex(Mutex::new(value))
    }
}

struct MyMutex<T: ?Sized>(Mutex<T>);

impl<'a, T> Lock<'a, T> for MyMutex<T> {
    type Guard
        = MutexGuard<'a, T>
    where
        T: 'a;

    fn lock(&'a self) -> Self::Guard {
        self.0.lock().unwrap()
    }
}

#[test]
fn new_lock() {
    let mutex = MutexFactory::new(1);
    assert_eq!(*mutex.lock(), 1);
}

#[test]
fn lock_interface() {
    fn lock_agnostic<'a, T: Copy>(mutex: &'a dyn Lock<'a, T, Guard = MutexGuard<'_, T>>) -> T {
        *mutex.lock()
    }
    let mutex = MutexFactory::new(1);
    assert_eq!(lock_agnostic(&mutex), 1);
}
