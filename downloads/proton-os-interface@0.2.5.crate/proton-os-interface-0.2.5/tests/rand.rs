use proton_os_interface::rand::{CryptoSeedProvider, RngCompat, Seed256, SeedableRng};

#[test]
fn new_seed() {
    use rand_latest as rand;
    let sp = CryptoSeedProvider::new(rand::rng());
    let seed: Seed256 = sp.into();
    rand::rngs::StdRng::from_seed(seed.into());
}

#[test]
fn compat() {
    fn rand_core_0_6_only(mut csrng: impl rand_core_0_6::CryptoRngCore) -> u32 {
        1
    }
    use rand_latest as rand;
    let csrng = rand::rng();
    let csrng = RngCompat::new(csrng);
    assert_eq!(rand_core_0_6_only(csrng), 1);
}
