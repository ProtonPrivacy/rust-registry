//! Index processors.

use crate::index::text::processor::tokenizer::Tokenizer;

mod tokenizer;

#[cfg(test)]
mod tests {}
