//! ## Common DNS traits and types

export! {
    mod resolver (as pub);
    mod dns (as pub);
    mod doh (as pub);
}
