Proton binary status is a library for scoring Proton VPN logicals.
