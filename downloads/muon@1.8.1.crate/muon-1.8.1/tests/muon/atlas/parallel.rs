use std::future::pending;
use std::sync::Arc;

use crate::atlas::{new_builder, new_client, PASS, USER};
use anyhow::{bail, Ok, Result};
use async_trait::async_trait;
use futures::future;
use muon::client::flow::LoginFlow;
use muon::common::Host;
use muon::dns::{DohService, GoogleDoh, Quad9Doh};
use muon::rt::{DynResolver, ResolveRes, Resolver, TokioResolver};
use muon::{Session, GET};
use serde_json::Value;

struct SlowFastResolver {
    inner: DynResolver,
    slow: Host,
}

#[async_trait]
impl Resolver for SlowFastResolver {
    async fn resolve(&self, host: &Host) -> muon::Result<ResolveRes> {
        if host == &self.slow {
            pending().await // never resolve
        } else {
            self.inner.resolve(host).await
        }
    }
}

#[tokio::test]
async fn test_parallel_slow_fast() -> Result<()> {
    let google_host = GoogleDoh.server().host().clone();

    let resolver = SlowFastResolver {
        inner: Arc::new(TokioResolver),
        slow: google_host,
    };

    let client = new_builder()
        .await
        .doh([GoogleDoh])
        .doh([Quad9Doh])
        .resolver(resolver)
        .build()
        .unwrap();

    let s = match client
        .new_session_without_credentials(())
        .await?
        .auth()
        .login(USER, PASS)
        .await
    {
        LoginFlow::Ok(s, _) => s,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let req = GET!("/tests/ping").allowed_time(std::time::Duration::from_secs(60));
    let res = s.send(req).await?;
    let _: Value = res.ok()?.into_body_json()?;

    Ok(())
}

#[tokio::test]
async fn test_parallel_ping() -> Result<()> {
    let s = match new_client()
        .await
        .new_session_without_credentials(())
        .await?
        .auth()
        .login(USER, PASS)
        .await
    {
        LoginFlow::Ok(s, _) => s,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let t = (0..10)
        .map(|_| s.clone())
        .map(|s| send_loop(s, 10))
        .map(|f| tokio::spawn(f))
        .collect::<Vec<_>>();

    for res in future::join_all(t).await {
        res??;
    }

    Ok(())
}

async fn send_loop(s: Session<()>, n: usize) -> Result<()> {
    for _ in 0..n {
        let req = GET!("/tests/ping").allowed_time(std::time::Duration::from_secs(60));
        let res = s.send(req).await?;
        let _: Value = res.ok()?.into_body_json()?;
    }

    Ok(())
}
