use crate::local::{
    session_json, session_two_json, unauth_session_json, SESSION, SESSION_TWO, UNAUTH_SESSION,
};
use anyhow::{bail, Ok, Result};
use muon::test::server::Server;
use muon::SessionCredentials;
use muon::POST;
use std::result::Result::Ok as StdOk;
use std::sync::Arc;

#[muon::test(session(SESSION.uid, SESSION.user_id, SESSION.access_token, SESSION.refresh_token))]
async fn test_auth_session(s: Arc<Server>) -> Result<()> {
    let c = s.client::<String>().await;
    let r = s.new_recorder();

    let session_credentials: SessionCredentials =
        serde_json::from_value(session_json()).expect("session credentials json should be valid");

    let session_key = "session_one".to_string();
    let session = c
        .new_session_with_credentials(session_key.clone(), session_credentials)
        .await
        .expect("Session should be created");

    session
        .send(POST!("/core/v4/validate/email").body(r#"{"Email":"einstein@pm.me"}"#))
        .await?;

    let req = r.read().pop_back().unwrap();
    let uid_hdr = req.headers().get("x-pm-uid").unwrap();
    let acc_hdr = req.headers().get("authorization").unwrap();

    assert_eq!(uid_hdr.to_str()?, SESSION.uid.to_string());
    assert_eq!(
        acc_hdr.to_str()?,
        format!("Bearer {}", SESSION.access_token.to_string())
    );

    Ok(())
}

#[muon::test(session(UNAUTH_SESSION.uid, UNAUTH_SESSION.user_id, UNAUTH_SESSION.access_token, UNAUTH_SESSION.refresh_token))]
async fn test_unauth_session_with_credentials(s: Arc<Server>) -> Result<()> {
    let c = s.client::<String>().await;
    let r = s.new_recorder();

    let session_credentials: SessionCredentials = serde_json::from_value(unauth_session_json())
        .expect("session credentials json should be valid");

    let session_key = "session_one".to_string();
    let session = c
        .new_session_with_credentials(session_key.clone(), session_credentials)
        .await
        .expect("Session should be created");

    session
        .send(POST!("/core/v4/validate/email").body(r#"{"Email":"einstein@pm.me"}"#))
        .await?;

    let req = r.read().pop_back().unwrap();
    let uid_hdr = req.headers().get("x-pm-uid").unwrap();
    let acc_hdr = req.headers().get("authorization").unwrap();

    assert_eq!(uid_hdr.to_str()?, UNAUTH_SESSION.uid.to_string());
    assert_eq!(
        acc_hdr.to_str()?,
        format!("Bearer {}", UNAUTH_SESSION.access_token.to_string())
    );

    Ok(())
}

#[muon::test]
async fn test_unauth_session_without_credentials(s: Arc<Server>) -> Result<()> {
    let c = s.client::<String>().await;
    let r = s.new_recorder();

    let session_key = "session_one".to_string();
    let session = c
        .new_session_without_credentials(session_key.clone())
        .await
        .expect("Session should be created");

    session
        .send(POST!("/core/v4/validate/email").body(r#"{"Email":"einstein@pm.me"}"#))
        .await?;

    let req = r.read().pop_back().unwrap();
    let uid_hdr = req.headers().get("x-pm-uid").unwrap();
    let acc_hdr = req.headers().get("authorization").unwrap();

    assert!(uid_hdr.to_str()? != "");
    assert!(acc_hdr.to_str()?.contains("Bearer"));

    Ok(())
}

#[muon::test]
async fn test_session_switching(s: Arc<Server>) -> Result<()> {
    let c = s.client::<String>().await;
    let r = s.new_recorder();

    s.new_session(
        SESSION.uid,
        SESSION.user_id,
        SESSION.access_token,
        SESSION.refresh_token,
    )
    .await?;
    s.new_session(
        SESSION_TWO.uid,
        SESSION_TWO.user_id,
        SESSION_TWO.access_token,
        SESSION_TWO.refresh_token,
    )
    .await?;
    s.new_session(
        UNAUTH_SESSION.uid,
        UNAUTH_SESSION.user_id,
        UNAUTH_SESSION.access_token,
        UNAUTH_SESSION.refresh_token,
    )
    .await?;

    let session_one_credentials: SessionCredentials =
        serde_json::from_value(session_json()).expect("session credentials json should be valid");

    let session_two_credentials: SessionCredentials = serde_json::from_value(session_two_json())
        .expect("session credentials json should be valid");

    let unauth_session_credentials: SessionCredentials =
        serde_json::from_value(unauth_session_json())
            .expect("session credentials json should be valid");

    let session_one_key = "session_one".to_string();
    let session_one = c
        .new_session_with_credentials(session_one_key.clone(), session_one_credentials)
        .await
        .expect("Session should be created");

    let session_two_key = "session_two".to_string();
    let session_two = c
        .new_session_with_credentials(session_two_key.clone(), session_two_credentials)
        .await
        .expect("Session should be created");

    let unauth_session_key = "unauth_session_with_credentials".to_string();
    let unauth_session = c
        .new_session_with_credentials(unauth_session_key.clone(), unauth_session_credentials)
        .await
        .expect("Session should be created");

    let unauth_session_without_cred_key = "unauth_session_without_credentials".to_string();
    let unauth_session_without_credentials = c
        .new_session_without_credentials(unauth_session_without_cred_key.clone())
        .await
        .expect("Session should be created");

    for (session, session_details) in [
        (session_one, SESSION),
        (session_two, SESSION_TWO),
        (unauth_session, UNAUTH_SESSION),
    ] {
        session
            .send(POST!("/core/v4/validate/email").body(r#"{"Email":"einstein@pm.me"}"#))
            .await?;

        let req = r.read().pop_back().unwrap();
        let uid_hdr = req.headers().get("x-pm-uid").unwrap();
        let acc_hdr = req.headers().get("authorization").unwrap();

        // Make sure we send with the correct credentials
        assert_eq!(uid_hdr.to_str()?, session_details.uid.to_string());
        assert_eq!(
            acc_hdr.to_str()?,
            format!("Bearer {}", session_details.access_token.to_string())
        );
    }

    unauth_session_without_credentials
        .send(POST!("/core/v4/validate/email").body(r#"{"Email":"einstein@pm.me"}"#))
        .await?;

    let req = r.read().pop_back().unwrap();
    let uid_hdr = req.headers().get("x-pm-uid").unwrap();
    let acc_hdr = req.headers().get("authorization").unwrap();

    // We don't know these credentials before hand. Check that something is there.
    assert!(uid_hdr.to_str()? != "");
    assert!(acc_hdr.to_str()?.contains("Bearer"));

    Ok(())
}

// Using the same session key or session credential uid should result in a failure to create a session
#[muon::test]
async fn test_create_session_failures(s: Arc<Server>) -> Result<()> {
    let c = s.client::<String>().await;

    let session_credentials: SessionCredentials =
        serde_json::from_value(session_json()).expect("session credentials json should be valid");

    let session_key = "session_one".to_string();

    // Create the base session - this should succeed
    let _ = c
        .new_session_with_credentials(session_key.clone(), session_credentials)
        .await
        .expect("Session should be created");

    // try to create another session with the same session key but different credentials - this should fail
    let session_credentials_different: SessionCredentials =
        serde_json::from_value(session_two_json())
            .expect("session credentials json should be valid");

    match c.new_session_with_credentials(session_key.clone(), session_credentials_different).await {
        StdOk(_) => bail!("Session creation should not succeed for the same session_key and different session credentials!"),
        Err(_) => {},
    }

    // try to create another session with a different session key but the same credentials - this should fail
    let session_credentials: SessionCredentials =
        serde_json::from_value(session_json()).expect("session credentials json should be valid");

    match c.new_session_with_credentials("different_session_key".to_string(), session_credentials).await {
        StdOk(_) => bail!("Session creation should not succeed for a different session key and the same session credentials!"),
        Err(_) => {},
    }

    Ok(())
}
