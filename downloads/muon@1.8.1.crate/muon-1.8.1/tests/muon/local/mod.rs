use serde_json::{json, Value};

/// Very simple ping tests.
mod ping;

/// Auth (SRP) tests.
mod auth;

/// Request building and sending tests.
mod request;

/// Retry handling tests.
mod retries;

/// Timeout tests.
mod timeout;

/// Runtime tests.
mod runtime;

/// TLS tests.
mod tls;

/// Drop tests.
mod drop;

/// Proxy tests.
#[cfg(feature = "test-proxy")]
mod proxy;

/// Session tests.
mod session;

struct SessionDetails<'a> {
    uid: &'a str,
    user_id: Option<&'a str>,
    access_token: &'a str,
    refresh_token: &'a str,
}

const SESSION: SessionDetails = SessionDetails {
    uid: "a50e8400-e29b-41d4-a716-446655440000",
    user_id: Some("b50e8400-e29b-41d4-a716-446655440001"),
    access_token: "c50e8400-e29b-41d4-a716-446655440002",
    refresh_token: "d50e8400-e29b-41d4-a716-446655440003",
};

const SESSION_TWO: SessionDetails = SessionDetails {
    uid: "a90e8400-e29b-41d4-a716-446655440000",
    user_id: Some("b90e8400-e29b-41d4-a716-446655440001"),
    access_token: "c90e8400-e29b-41d4-a716-446655440002",
    refresh_token: "d90e8400-e29b-41d4-a716-446655440003",
};

const UNAUTH_SESSION: SessionDetails = SessionDetails {
    uid: "ffffffff-e29b-41d4-a716-446655440000",
    user_id: None,
    access_token: "ffffffff-e29b-41d4-a716-446655440002",
    refresh_token: "ffffffff-e29b-41d4-a716-446655440003",
};

fn session_json() -> Value {
    json!({
        "UID": SESSION.uid,
        "UserID": SESSION.user_id,
        "AccessToken": SESSION.access_token,
        "RefreshToken": SESSION.refresh_token,
        "Scopes": [],
    })
}

fn session_two_json() -> Value {
    json!({
        "UID": SESSION_TWO.uid,
        "UserID": SESSION_TWO.user_id,
        "AccessToken": SESSION_TWO.access_token,
        "RefreshToken": SESSION_TWO.refresh_token,
        "Scopes": [],
    })
}

fn unauth_session_json() -> Value {
    json!({
        "UID": UNAUTH_SESSION.uid,
        "UserID": UNAUTH_SESSION.user_id,
        "AccessToken": UNAUTH_SESSION.access_token,
        "RefreshToken": UNAUTH_SESSION.refresh_token,
        "Scopes": [],
    })
}
