use anyhow::Result;
use muon::test::server::{Server, HTTPS};
use muon::tls::{RustlsTls, TokioTls};
use muon::GET;
use std::sync::Arc;

#[muon::test(scheme(HTTPS))]
async fn test_tls_rustls(s: Arc<Server>) -> Result<()> {
    let c = s.builder().await.tls(RustlsTls).build()?;
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    unauth_session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}

#[muon::test(scheme(HTTPS))]
#[ignore = "self-signed certificate"]
async fn test_tls_tokio(s: Arc<Server>) -> Result<()> {
    let c = s.builder().await.tls(TokioTls).build()?;
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    unauth_session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
