//! This example demonstrates how to use an externally-managed auth session.

use anyhow::Result;
use muon::{App, Client, GET};

#[tokio::main]
async fn main() -> Result<()> {
    // Create a new session.
    let app = App::new("windows-vpn@4.1.0")?;
    let session = Client::new(app, muon::env::EnvId::new_atlas().into_store())
        .await?
        .new_session_without_credentials(())
        .await?;

    // Begin the auth flow.
    let auth = session.auth();

    // Provide an externally-managed auth UID.
    let session = auth.from_uid("abcdef", "abc123def456").await;

    // The session will **not** manage the tokens.
    // It assumes the tokens are managed externally.
    session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
