//! ## Store
//!
//! This module defines the `Store` trait, which provides a generic contract for
//! implementing a persistent session store. A persistent store allows a client
//! application to save and retrieve user [`Auth`] information across application
//! restarts (e.g., in a database, a file, or the system keychain).
//!
//! ### Core Concepts
//!
//! The `Store` trait is designed to be flexible and support both single-user
//! applications and complex multi-account scenarios.
//!
//! - **Authentication State**: The central data type is [`Auth`], which encapsulates
//!   all necessary information for a user's session.
//! - **The `Auth::None` State**: `Auth::None` represents the absence of a session. It is the
//!   expected return value from `get_auth` for a non-existent key, but it should **never**
//!   be persisted in the store itself. The only way to remove a session is by calling `remove_auth`.
//! - **Multi-Session Support**: The trait is generic over a `SessionKey`, which
//!   must implement [`SessionKeyable`]. This key acts as a unique identifier for
//!   each user session, allowing a single store instance to manage multiple
//!   accounts concurrently.
//! - **State Inconsistency**: In cases where the stored data becomes out-of-sync
//!   with the server (e.g., a session token expires), the design philosophy is to
//!   trust the Proton API's response. The store should simply provide the last known
//!   state, and the client will handle API errors by initiating re-authentication
//!   if necessary.
//!
//! ### Error Handling
//!
//! The store's methods return a [`Result`] with a generic [`StoreError`]. This
//! error type is intentionally opaque because the underlying storage mechanisms
//! can vary widely. Implementers are responsible for handling their specific
//! backend errors and mapping them to `StoreError`.
//!
//! ### Example without error handling
//!
//! This example demonstrates a simple, in-memory store for managing multiple
//! sessions, compliant with the new contract.
//!
//! ```
//! use muon::client::Auth;
//! use muon::env::EnvId;
//! use muon::store::{Store, StoreError};
//! use muon::SessionKeyable;
//! use std::collections::HashMap;
//!
//! /// A dummy in-memory persistent storage for multiple user sessions.
//! #[derive(Debug)]
//! pub struct InMemoryStore<SessionKey: SessionKeyable> {
//!     env: EnvId,
//!     auth_map: HashMap<SessionKey, Auth>,
//! }
//!
//! impl<SessionKey: SessionKeyable> InMemoryStore<SessionKey> {
//!     /// Creates a new, empty in-memory store for the Atlas environment.
//!     pub fn new() -> Self {
//!         Self {
//!             env: EnvId::new_atlas(),
//!             auth_map: HashMap::new(),
//!         }
//!     }
//! }
//!
//! #[async_trait::async_trait]
//! impl<SessionKey: SessionKeyable> Store<SessionKey> for InMemoryStore<SessionKey> {
//!     fn env(&self) -> EnvId {
//!         self.env.clone()
//!     }
//!
//!     async fn get_auth(&self, key: &SessionKey) -> Result<Auth, StoreError> {
//!         // If the key is not found, it correctly defaults to the conceptual `Auth::None` state.
//!         Ok(self.auth_map.get(key).cloned().unwrap_or(Auth::None))
//!     }
//!
//!     async fn set_auth(&mut self, key: &SessionKey, auth: Auth) -> Result<(), StoreError> {
//!         // Per the contract, `auth` will never be `Auth::None`.
//!         self.auth_map.insert(key.clone(), auth);
//!         Ok(())
//!     }
//!
//!     async fn remove_auth(&mut self, key: &SessionKey) -> Result<Option<Auth>, StoreError> {
//!         // Removal is the only way to delete a session. Returns true if it existed.
//!         Ok(self.auth_map.remove(key))
//!     }
//!
//!     async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError> {
//!         // The returned map will never contain an `Auth::None` value.
//!         Ok(self.auth_map.clone())
//!     }
//!
//!     async fn set_all_auth(&mut self, auth: HashMap<SessionKey, Auth>) -> Result<(), StoreError> {
//!         // The incoming map is guaranteed not to have `Auth::None` values.
//!         self.auth_map = auth;
//!         Ok(())
//!     }
//!
//!     async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
//!         self.auth_map.clear();
//!         Ok(())
//!     }
//! }
//! ```
//!
//! ### Example with error handling
//!
//! This example shows a file-based store for a single session (`SessionKey = ()`)
//! that correctly handles session removal by deleting the file.
//!
//! ```
//! use muon::client::Auth;
//! use muon::env::EnvId;
//! use muon::store::{Store, StoreError};
//! use std::collections::HashMap;
//! use std::io::ErrorKind;
//! use std::path::{Path, PathBuf};
//! // NOTE: This example requires `serde` and `serde_json` dependencies,
//! // and assumes `Auth` derives `Serialize` and `Deserialize`.
//! use serde::{Deserialize, Serialize};
//!
//! // Dummy functions for the example
//! fn display_error_modal(_: &str) {}
//!
//! /// A custom error type for our file store.
//! #[derive(Debug)]
//! enum FileStoreError {
//!     Io(std::io::Error),
//!     Serialization(serde_json::Error),
//! }
//!
//! /// A store that persists the session to a single file.
//! #[derive(Debug)]
//! struct FallibleFileStore {
//!     env: EnvId,
//!     path: PathBuf,
//! }
//!
//! impl FallibleFileStore {
//!     fn handle_error(&self, error: FileStoreError) -> StoreError {
//!         display_error_modal(&format!("A storage error occurred: {:?}", error));
//!         StoreError
//!     }
//!
//!     fn write(&self, auth: Auth) -> Result<(), StoreError> {
//!         let data = serde_json::to_string(&auth).map_err(|e| self.handle_error(FileStoreError::Serialization(e)))?;
//!         std::fs::write(&self.path, data).map_err(|e| self.handle_error(FileStoreError::Io(e)))
//!     }
//! }
//!
//! #[async_trait::async_trait]
//! impl Store<()> for FallibleFileStore {
//!     fn env(&self) -> EnvId {
//!         self.env.clone()
//!     }
//!
//!     async fn get_auth(&self, _key: &()) -> Result<Auth, StoreError> {
//!         match std::fs::read_to_string(&self.path) {
//!             Ok(data) => serde_json::from_str(&data).map_err(|e| self.handle_error(FileStoreError::Serialization(e))),
//!             // If the file is not found, it means there is no session. Return `Auth::None`.
//!             Err(e) if e.kind() == ErrorKind::NotFound => Ok(Auth::None),
//!             Err(e) => Err(self.handle_error(FileStoreError::Io(e))),
//!         }
//!     }
//!
//!     async fn set_auth(&mut self, _key: &(), auth: Auth) -> Result<(), StoreError> {
//!         // Per the `Store` contract, `auth` will not be `Auth::None`.
//!         self.write(auth)
//!     }
//!
//!     async fn remove_auth(&mut self, _key: &()) -> Result<Option<Auth>, StoreError> {
//!         // Removing the auth state means deleting the backing file.
//!         let auth = self.get_auth(&()).await?;
//!         let auth = if auth != Auth::None {
//!             auth
//!         } else {
//!             return Ok(None);
//!         };
//!         match std::fs::remove_file(&self.path) {
//!             Ok(_) => Ok(Some(auth)), // File existed and was removed.
//!             Err(e) if e.kind() == ErrorKind::NotFound => Ok(None), // File didn't exist, so it was already "removed".
//!             Err(e) => Err(self.handle_error(FileStoreError::Io(e))),
//!         }
//!     }
//!
//!     async fn get_all_auth(&self) -> Result<HashMap<(), Auth>, StoreError> {
//!         let auth = self.get_auth(&()).await?;
//!         if let Auth::None = auth {
//!             Ok(HashMap::new())
//!         } else {
//!             Ok(HashMap::from([((), auth)]))
//!         }
//!     }
//!
//!     async fn set_all_auth(&mut self, mut auth: HashMap<(), Auth>) -> Result<(), StoreError> {
//!         // If the map contains the unit key, write its auth. Otherwise, remove the session file.
//!         if let Some(auth_state) = auth.remove(&()) {
//!             self.write(auth_state)
//!         } else {
//!             self.remove_auth(&()).await.map(|_| ())
//!         }
//!     }
//!
//!     async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
//!         self.remove_auth(&()).await.map(|_| ())
//!     }
//! }
//! ```
use std::collections::HashMap;

use crate::auth::Auth;
use crate::common::IntoDyn;
use crate::env::EnvId;
use crate::{export, SessionKeyable};
use async_trait::async_trait;
use muon_proc::{autoimpl, derive_dyn};
use thiserror::Error;

export! {
    /// Implements a thread-safe wrapper around [`Store`].
    mod safe (as pub(crate));

    /// Implements an in-memory store.
    mod inmemory (as pub(crate));
}

/// An error indicating that an operation on a [`Store`] failed.
///
/// This is an opaque error type. Implementers of the [`Store`] trait are
/// responsible for handling their own backend-specific errors (e.g., IO,
/// database) and mapping them to this error.
#[derive(Debug, Error)]
#[error("failed to access the session store")]
pub struct StoreError;

/// A trait defining the contract for persistent session storage.
///
/// This is the core abstraction that decouples the client from any specific
/// storage backend (e.g., in-memory, file system, database). By implementing
/// this trait, applications provide their own logic for how and where session
/// data ([`Auth`]) is saved.
///
/// The trait is generic over a [`SessionKeyable`] type, which allows it to
/// support both single-session and multi-session applications seamlessly.
#[async_trait]
#[autoimpl(for(DynStore<SessionKey>))]
#[derive_dyn(Debug)]
pub trait Store<SessionKey: SessionKeyable>: Send + Sync + 'static {
    /// Gets the Proton environment (`prod`, `atlas`, etc.) to which this store is bound.
    ///
    /// This ensures that credentials from different environments are not mixed within
    /// the same store instance.
    fn env(&self) -> EnvId;

    /// Retrieves the authentication state for a given session key.
    ///
    /// If the session key is not found in the store, this method must return
    /// `Ok(Auth::None)`. A missing key is treated as a valid, non-authenticated
    /// state, not as an error.
    ///
    /// # Errors
    ///
    /// Returns [`StoreError`] if the backend storage fails during the read operation.
    async fn get_auth(&self, key: &SessionKey) -> Result<Auth, StoreError>;

    /// Sets or updates the authentication state for a given session key.
    ///
    /// If the key already exists, its value is updated. If it does not exist, a
    /// new entry is created.
    ///
    /// The provided `auth` state must not be [`Auth::None`]. To clear a session,
    /// [`remove_auth`](Self::remove_auth) must be used instead.
    ///
    /// # Errors
    ///
    /// Returns [`StoreError`] if the backend storage fails during the write operation.
    async fn set_auth(&mut self, key: &SessionKey, auth: Auth) -> Result<(), StoreError>;

    /// Removes a session key and its associated authentication state from the store.
    ///
    /// After this operation, a call to [`get_auth`](Self::get_auth) with the same key
    /// should return `Ok(Auth::None)`.
    ///
    /// # Returns
    ///
    /// - `Ok(Some(Auth))` if the key was present in the store and was successfully removed.
    /// - `Ok(None)` if the key was not found in the store.
    ///
    /// # Errors
    ///
    /// Returns [`StoreError`] if the backend storage fails during the removal operation.
    async fn remove_auth(&mut self, key: &SessionKey) -> Result<Option<Auth>, StoreError>;

    /// Retrieves a map of all persisted session keys and their authentication states.
    ///
    /// The returned map must not contain any entries where the value is [`Auth::None`].
    ///
    /// # Errors
    ///
    /// Returns [`StoreError`] if the backend storage fails during the read operation.
    async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError>;

    /// Replaces all authentication states in the store with the provided map.
    ///
    /// This is a destructive operation that completely overwrites the existing
    /// stored data. Any keys not present in the new `auth` map will be removed. The
    /// provided map is not expected to contain any [`Auth::None`] values.
    ///
    /// # Errors
    ///
    /// Returns [`StoreError`] if the backend storage fails during the write operation.
    async fn set_all_auth(&mut self, auth: HashMap<SessionKey, Auth>) -> Result<(), StoreError>;

    /// Removes all authentication states from the store.
    ///
    /// After this operation, a call to [`get_all_auth`](Self::get_all_auth) should
    /// return an empty map.
    ///
    /// # Errors
    ///
    /// Returns [`StoreError`] if the backend storage fails during the write operation.
    async fn remove_all_auth(&mut self) -> Result<(), StoreError>;
}

/// A type-erased, dynamically-dispatchable `Store`.
pub type DynStore<SessionKey> = Box<dyn Store<SessionKey>>;

impl<SessionKey: SessionKeyable, This: Store<SessionKey>> IntoDyn<DynStore<SessionKey>> for This {
    fn into_dyn(self) -> DynStore<SessionKey> {
        Box::new(self)
    }
}
