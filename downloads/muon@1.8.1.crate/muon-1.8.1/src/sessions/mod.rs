mod session;
mod session_credentials;

use serde::de::DeserializeOwned;
use serde::Serialize;
pub use session::Session;
pub use session_credentials::SessionCredentials;

/// Represents the set of capabilities required for a type to be used as a
/// session key.
///
/// This trait acts as an alias, grouping together several fundamental traits
/// from the standard library and the `serde` crate. By using `SessionKeyable`
/// as a trait bound, generic code can concisely specify that a type is suitable
/// for use as a key in session management—for instance, as a key in a `HashMap`
/// that might be persisted or sent over a network.
///
/// # Required Capabilities
///
/// A type implementing `SessionKeyable` must be:
/// - `Eq` + `Hash`: To be used as a key in hash maps or sets.
/// - `Clone`: To be easily duplicated.
/// - `Debug`: To be printable for debugging purposes.
/// - `Serialize` + `DeserializeOwned`: To allow for serialization and
///   deserialization, enabling persistence, caching, or network transfer.
///
/// # Example
///
/// ```
/// use serde::{de::DeserializeOwned, Serialize, Deserialize};
/// use std::collections::HashMap;
///
/// // The trait definition and its blanket implementation
/// pub trait SessionKeyable:
///     Eq + std::hash::Hash + Clone + std::fmt::Debug + Serialize + DeserializeOwned
/// {}
/// impl<T> SessionKeyable for T where
///     T: Eq + std::hash::Hash + Clone + std::fmt::Debug + Serialize + DeserializeOwned
/// {}
///
/// // A custom type for session keys, deriving all necessary traits.
/// #[derive(Debug, Clone, Hash, Eq, PartialEq, Serialize, Deserialize)]
/// struct UserId(u64);
///
/// // Our struct `UserId` now automatically implements `SessionKeyable`
/// // because of the blanket implementation above.
///
/// // A generic function that can work with any valid session key type.
/// fn get_session_data<'a, K: SessionKeyable>(
///     sessions: &'a HashMap<K, String>,
///     key: &K
/// ) -> Option<&'a String> {
///     sessions.get(key)
/// }
///
/// let mut sessions: HashMap<UserId, String> = HashMap::new();
/// let user_id = UserId(123);
/// sessions.insert(user_id.clone(), "user_data".to_string());
///
/// let data = get_session_data(&sessions, &user_id);
/// assert_eq!(data, Some(&"user_data".to_string()));
/// ```
pub trait SessionKeyable:
    Eq
    + std::hash::Hash
    + Clone
    + std::fmt::Debug
    + Serialize
    + DeserializeOwned
    + Send
    + Sync
    + 'static
{
}

/// A blanket implementation that automatically confers `SessionKeyable` to any
/// type that satisfies its requirements.
///
/// This means you don't need to implement `SessionKeyable` manually. Instead,
/// you can simply derive or implement the underlying traits (`Eq`, `Hash`,
/// `Clone`, `Debug`, `Serialize`, `DeserializeOwned`) for your type.
impl<T> SessionKeyable for T where
    T: Eq
        + std::hash::Hash
        + Clone
        + std::fmt::Debug
        + Serialize
        + DeserializeOwned
        + Send
        + Sync
        + 'static
{
}

/// The session already exists in the store
#[derive(Debug, thiserror::Error)]
#[error("the session already exists")]
pub struct SessionAlreadyExists;

/// The session credentials are already registered under another name in the
/// store
#[derive(Debug, thiserror::Error)]
#[error("the UID of the session credentials already exists. Only unique UIDs are allowed to ensure session uniqueness.")]
pub struct DuplicatedSessionCredentials;

/// The given type of session cannot be used in this context.
/// For instance refreshing an external session
#[derive(Debug, thiserror::Error)]
#[error("the provided session type is not supported for this operation.")]
pub struct InvalidSessionType;
