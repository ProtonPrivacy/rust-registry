#![allow(warnings)]

//! This module contains code snippets for documentation

use crate::env::EnvId;
use crate::flow::LoginFlowData;
use crate::store::{Store, StoreError};
use crate::Session;
use crate::SessionKeyable;
use crate::{Auth, Client, Error};
use async_trait::async_trait;
use std::collections::HashMap;

/// todo
#[derive(Debug)]
pub struct MyPersistenceStorage;

impl MyPersistenceStorage {
    /// todo
    pub fn prod() -> Self {
        Self
    }
}

#[async_trait]
impl<SessionKey: SessionKeyable> Store<SessionKey> for MyPersistenceStorage {
    fn env(&self) -> EnvId {
        EnvId::new_atlas()
    }

    async fn get_auth(&self, _key: &SessionKey) -> Result<Auth, StoreError> {
        Ok(Auth::None)
    }
    async fn set_auth(&mut self, _key: &SessionKey, _auth: Auth) -> Result<(), StoreError> {
        Ok(())
    }
    async fn remove_auth(&mut self, _key: &SessionKey) -> Result<Option<Auth>, StoreError> {
        Ok(None)
    }
    async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError> {
        Ok(Default::default())
    }
    async fn set_all_auth(&mut self, _auth: HashMap<SessionKey, Auth>) -> Result<(), StoreError> {
        Ok(())
    }
    async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
        Ok(())
    }
}

/// todo
pub fn show_user_cant_login_modal(_: impl Into<Error>) {}

/// todo
pub fn display_authenticated_user_info<SessionKey: SessionKeyable>(_: &Session<SessionKey>) {}

/// todo
pub fn load_user_preferences(_: &str) -> Result<(), Error> {
    Ok(())
}

/// todo
pub fn ask_user_for_2fa() -> String {
    "".to_owned()
}

/// todo
pub fn ask_user_for_mbp() -> String {
    "".to_owned()
}

/// todo
pub fn unlock_pgp_key<SessionKey: SessionKeyable>(_: &Session<SessionKey>, _: &str) {}
