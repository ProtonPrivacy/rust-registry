use crate::auth::Auth;
use crate::flow::{FlowErr, UserIdErr};
use crate::http::{Status, GET};
use crate::rest::auth;
use crate::util::ByteSliceExt;
use crate::{Session, SessionKeyable, Tokens};

/// A flow for acquiring a fork.
#[must_use]
#[derive(Debug)]
pub struct FromForkFlow<SessionKey: SessionKeyable> {
    session: Session<SessionKey>,
}

impl<SessionKey: SessionKeyable> FromForkFlow<SessionKey> {
    pub(super) fn new(session: Session<SessionKey>) -> Self {
        Self { session }
    }

    /// Acquire the fork with the given selector.
    ///
    /// The selector is a unique identifier for the fork.
    pub async fn with_selector(self, selector: impl AsRef<str>) -> WithSelectorFlow<SessionKey> {
        WithSelectorFlow::new(self.session, selector.as_ref()).await
    }

    /// Acquire the fork from a user code.
    pub async fn with_code(self) -> WithCodeFlow<SessionKey> {
        WithCodeFlow::new(self.session).await
    }
}

/// A flow for a fork with a selector.
#[must_use]
#[derive(Debug)]
pub enum WithSelectorFlow<SessionKey: SessionKeyable> {
    /// The flow is complete; the session is returned, along with any payload.
    Ok(Session<SessionKey>, Option<Vec<u8>>),
    /// The login via selector couldn't proceed
    Failed {
        /// The child originating the login via selector
        session: Session<SessionKey>,
        /// The reason why it did not succeed
        reason: FlowErr,
    },
}

impl<SessionKey: SessionKeyable> WithSelectorFlow<SessionKey> {
    async fn new(session: Session<SessionKey>, selector: &str) -> Self {
        info!(%selector, "acquiring forked session");
        let req = GET!("/auth/v4/sessions/forks/{selector}");
        let res = return_variant_on_error!(session.send(req).await, session, Self::Failed);
        let res = return_variant_on_error!(res.ok(), session, Self::Failed);
        let res: auth::v4::sessions::forks::GetIdRes =
            return_variant_on_error!(res.into_body_json(), session, Self::Failed);

        // Build new access tokens from the fork.
        let tok = Tokens::access(
            res.auth.access_token(),
            res.auth.refresh_token(),
            res.auth.scopes(),
        );

        // Get the ID of the user that logged in.
        let Some(user_id) = res.auth.user_id() else {
            return Self::Failed {
                session,
                reason: UserIdErr.into(),
            };
        };

        info!(uid = %res.auth.uid(), "building new auth object");
        let auth = Auth::internal(user_id, res.auth.uid(), tok);

        info!(%auth, "auth complete, storing tokens");
        session.set_auth(auth).await;

        let payload = return_variant_on_error!(
            (res.payload).map(|p| p.b64_into()).transpose(),
            session,
            Self::Failed
        );

        Self::Ok(session, payload)
    }
}

/// A flow for a fork with a user code.
#[must_use]
#[derive(Debug)]
pub enum WithCodeFlow<SessionKey: SessionKeyable> {
    /// Poll the fork for completion.
    Poll(WithCodePollFlow<SessionKey>),

    /// The flow is complete; the session is returned.
    Ok(Session<SessionKey>, Option<Vec<u8>>),

    /// The flow couldn't complete; the session is returned unlogged
    Failed {
        /// The session that failed to log via a code flow
        session: Session<SessionKey>,
        /// The reason why this login method failed
        reason: FlowErr,
    },
}

impl<SessionKey: SessionKeyable> WithCodeFlow<SessionKey> {
    async fn new(session: Session<SessionKey>) -> Self {
        // Generate a new random human-readable code.
        let req = GET!("/auth/v4/sessions/forks");
        let res = return_variant_on_error!(session.send(req).await, session, Self::Failed);
        let res = return_variant_on_error!(res.ok(), session, Self::Failed);
        let res: auth::v4::sessions::forks::GetRes =
            return_variant_on_error!(res.into_body_json(), session, Self::Failed);

        // The selector should be used to poll, the code returned to the user.
        let selector = res.selector;
        let code = res.code;

        Self::Poll(WithCodePollFlow {
            session,
            selector,
            code,
        })
    }
}

/// A flow for polling a fork with a user code.
#[must_use]
#[derive(Debug)]
pub struct WithCodePollFlow<SessionKey: SessionKeyable> {
    session: Session<SessionKey>,
    selector: String,
    code: String,
}

impl<SessionKey: SessionKeyable> WithCodePollFlow<SessionKey> {
    /// Return the user code used for the fork process
    pub fn code(&self) -> &str {
        &self.code
    }

    /// Poll the fork for completion.
    pub async fn poll(self) -> WithCodeFlow<SessionKey> {
        info!(selector = %self.selector, "polling forked session");
        let req = GET!("/auth/v4/sessions/forks/{}", self.selector);
        let res = return_variant_on_error!(
            self.session.send(req).await,
            self.session,
            WithCodeFlow::Failed
        );

        // If the fork is not yet complete, return a poll flow.
        let res: auth::v4::sessions::forks::GetIdRes = if res.is(Status::UNPROCESSABLE_ENTITY) {
            return WithCodeFlow::Poll(self);
        } else {
            return_variant_on_error!(res.into_body_json(), self.session, WithCodeFlow::Failed)
        };

        // Build new access tokens from the fork.
        let tok = Tokens::access(
            res.auth.access_token(),
            res.auth.refresh_token(),
            res.auth.scopes(),
        );

        // Get the ID of the user that logged in.
        let Some(user_id) = res.auth.user_id() else {
            return WithCodeFlow::Failed {
                session: self.session,
                reason: UserIdErr.into(),
            };
        };

        info!(uid = %res.auth.uid(), "building new auth object");
        let auth = Auth::internal(user_id, res.auth.uid(), tok);

        info!(%auth, "fork complete, storing tokens");
        self.session.set_auth(auth).await;

        let payload = return_variant_on_error!(
            (res.payload).map(|p| p.b64_into()).transpose(),
            self.session,
            WithCodeFlow::Failed
        );

        WithCodeFlow::Ok(self.session, payload)
    }
}
