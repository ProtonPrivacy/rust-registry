use crate::rest::auth;
use crate::test::server::error::{cerr, ServerRes};
use axum::extract::State;
use axum::Json;
use crate::test::server::backend::{Auth, Backend};
use serde_json::json;

/// Handle `POST /auth/v4/sessions`.
pub async fn post(
    State(this): State<Backend>
) -> ServerRes<Json<auth::v4::SessionCredentials>> {

    let uid = this.new_unauth_session().await?;
    let Auth { reftok, acctok, .. } = this.get_auth_session(uid).await?;
    let (acctok, scopes) = acctok.ok_or_else(|| cerr!(500, "missing auth session"))?;
    let scopes: Vec<String> = scopes.iter().map(ToString::to_string).collect();
    
    let session_credentials: auth::v4::SessionCredentials = serde_json::from_value(
        json!({
            "UID": uid.to_string(),
            "UserID": None::<String>,
            "AccessToken": acctok.to_string(),
            "RefreshToken": reftok.to_string(),
            "Scopes": scopes,
        })
    ).expect("session credentials json should be valid");

    Ok(Json(session_credentials))
}