# muon-test-server

A controllable test server for the **`muon`** library.

`muon-test-server` lets you run a fake/programmable API that a `muon` client talks to, so you can write deterministic tests for success paths, failures, retries, timeouts, and weird edge cases—without relying on real infrastructure.

# Warning
This crate is standalone, it only defines the server part and does **not** export `muon` specific structures. However, from a test server, one can easily create an associated `muon` client.

To get a full-featured - battery included - test framework please use [muon-test](https://gitlab.protontech.ch/ProtonVPN/rust/muon-test).

---

## Use cases

- Test a `muon` client’s behavior when:
  - the API returns errors (4xx/5xx)
  - responses are slow / time out
  - the API returns malformed payloads
  - pagination behaves oddly
  - auth expires and needs refresh
  - retries/backoff should kick in

---

## Installation

Add it as a dev dependency:

```toml
[dev-dependencies]
muon-test-server = "0.1"
```