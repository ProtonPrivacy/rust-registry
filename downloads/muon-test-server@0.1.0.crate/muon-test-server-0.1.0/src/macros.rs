/// Create a `Url` from arguments that can be formatted with `format!`.
#[macro_export]
#[doc(hidden)]
macro_rules! url {
    ($($tt:tt)*) => {{
        url::Url::parse(&format!($($tt)*))
    }};
}
