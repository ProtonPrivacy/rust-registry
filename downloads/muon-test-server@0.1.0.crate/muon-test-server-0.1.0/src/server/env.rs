use std::collections::HashSet;

/// A custom environment.
#[derive(Debug, Clone)]
pub struct TestEnv {
    pub api_pins: Option<HashSet<[u8; 32]>>,
    pub servers: HashSet<String>,
}

impl TestEnv {
    /// Create a new test environment.
    pub fn new(api_pins: Option<HashSet<[u8; 32]>>, server: String) -> Self {
        let servers = vec![server].into_iter().collect();
        Self { api_pins, servers }
    }
}
