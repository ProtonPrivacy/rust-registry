use axum::Json;
use axum::extract::State;
use data_encoding::BASE64;
use muon_rest::auth;

use crate::server::backend::Backend;
use crate::server::error::ServerRes;

/// Handle `POST /auth/v4/info`.
pub async fn post(
    State(this): State<Backend>,
    Json(body): Json<auth::v4::info::Post>,
) -> ServerRes<Json<auth::v4::info::PostRes>> {
    // Get the user's data.
    let user_id = this.get_user_id(&body.username).await?;
    let user = this.get_user(user_id).await?;

    let version = user.verifier.version;
    let salt = BASE64.encode(&user.verifier.salt);
    // Begin the SRP auth.
    let (srp_id, challenge, modulus) = this.new_srp_session(user_id, user.verifier).await?;

    // Build the JSON response.
    let session = srp_id.to_string();
    let server_ephemeral = BASE64.encode(&challenge);

    // Build the JSON response.
    Ok(Json(auth::v4::info::PostRes {
        session,
        version,
        salt,
        modulus,
        server_ephemeral,
    }))
}
