/// `/tests/ping`
pub mod ping;
