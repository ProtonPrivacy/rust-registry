use axum::extract::{Request, State};

use crate::server::backend::Backend;
use crate::server::error::ServerRes;

/// Handle `POST /core/v4/validate/email`
pub async fn post(State(_): State<Backend>, _: Request) -> ServerRes<()> {
    Ok(())
}
