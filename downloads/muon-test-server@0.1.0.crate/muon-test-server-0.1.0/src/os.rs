use std::pin::Pin;

use futures::TryFutureExt as _;
use futures::task::{FutureObj, Spawn, SpawnError};

// --- basic implementation of the operating system ---
#[derive(Debug, Clone)]
pub struct StdTime {
    at_start: std::time::Instant,
}

impl Default for StdTime {
    fn default() -> Self {
        Self {
            at_start: std::time::Instant::now(),
        }
    }
}

pub type SleepFut<'a> = Pin<Box<dyn Future<Output = ()> + Send + Sync + 'a>>;
impl StdTime {
    pub fn sleep(&self, duration: core::time::Duration) -> SleepFut<'static> {
        Box::pin(tokio::time::sleep(duration))
    }
}

impl StdTime {
    pub fn boottime_at_start(&self) -> std::time::Instant {
        self.at_start
    }

    pub fn now_boottime(&self) -> std::time::Instant {
        std::time::Instant::now()
    }

    pub fn now_realtime(&self) -> std::time::SystemTime {
        std::time::SystemTime::now()
    }

    pub fn realtime_epoch(&self) -> std::time::SystemTime {
        std::time::UNIX_EPOCH
    }
}

#[derive(Debug, Clone, Default)]
pub struct TokioTcpConnector;

pub type Socket = tokio::net::TcpStream;
impl TokioTcpConnector {
    pub fn tcp_connect(
        &self,
        addr: std::net::SocketAddr,
    ) -> impl Future<Output = Result<tokio::net::TcpStream, std::io::Error>> {
        tokio::net::TcpStream::connect(addr)
    }
}

#[derive(Debug, Clone, Default)]
pub struct TokioResolver;

impl TokioResolver {
    pub fn resolve(
        &self,
        host: &str,
    ) -> impl std::future::Future<Output = std::result::Result<Vec<core::net::IpAddr>, std::io::Error>>
    {
        tokio::net::lookup_host(format!("{host}:80"))
            .map_ok(|addresses| addresses.map(|addr| addr.ip()).collect())
    }
}

#[derive(Debug, Clone, Default)]
pub struct TokioOs {
    pub time: StdTime,
    pub dialer: TokioTcpConnector,
    pub resolver: TokioResolver,
}

#[derive(Debug, Clone)]
pub struct TokioExecutor;

impl Spawn for TokioExecutor {
    fn spawn_obj(&self, future: FutureObj<'static, ()>) -> Result<(), SpawnError> {
        let _ = tokio::spawn(future);
        Ok(())
    }
}
