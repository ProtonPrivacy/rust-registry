use std::borrow::ToOwned;

use axum::Json;
use axum::extract::State;
use axum::http::header::HeaderMap;
use muon_rest::auth;
use serde_json::json;

use crate::server::backend::Backend;
use crate::server::error::{ServerRes, cerr};

/// Handle `POST /auth/v4/refresh`.
pub async fn post(
    State(this): State<Backend>,
    headers: HeaderMap,
    Json(body): Json<auth::v4::refresh::Post>,
) -> ServerRes<Json<auth::v4::refresh::PostRes>> {
    // Get the UID from the `x-pm-uid` header.
    let uid = headers
        .get("x-pm-uid")
        .and_then(|v| v.to_str().ok())
        .map(ToOwned::to_owned)
        .ok_or_else(|| cerr!(400, "missing x-pm-uid header"))?;

    // Get the refresh token from the request.
    let tok = body.refresh_token;

    // Grant new auth tokens.
    let uid = this.refresh_auth_session(&uid, &tok).await?;
    let auth = this.get_auth_session(uid).await?;
    let (acctok, scopes) = (auth.acctok).ok_or_else(|| cerr!(500, "missing auth session"))?;
    let scopes: Vec<String> = scopes.iter().map(ToString::to_string).collect();

    let session_credentials: auth::v4::SessionCredentials = serde_json::from_value(json!({
        "UID": uid.to_string(),
        "UserID": Some(auth.user_id.to_string()),
        "AccessToken": acctok.to_string(),
        "RefreshToken": auth.reftok.to_string(),
        "Scopes": scopes,
    }))
    .expect("session credentials json should be valid");

    // Build the JSON response.
    Ok(Json(auth::v4::refresh::PostRes {
        auth: session_credentials,
    }))
}
