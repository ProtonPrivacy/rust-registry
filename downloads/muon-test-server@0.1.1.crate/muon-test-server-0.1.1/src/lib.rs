//! # Muon Test
//!
//! This crate implements testing utilities for the `muon` crate.

#[macro_use]
mod cfg;

/// Random stuff.
pub mod rand;

/// Matcher utilities for server expectations.
pub mod matcher;

/// Runs a `tinyproxy` instance.
pub mod proxy;

/// Local test server.
pub mod server;

/// Operating System implementation
pub mod os;

mod macros;
