use rand::distr::{Alphanumeric, SampleString};
use url::Url;

use crate::url;
/// Generate a random URL that is very very *very* unlikely to exist.
#[must_use]
pub fn random_url() -> Url {
    url!("https://{}", random_domain()).unwrap()
}

/// Generate a random domain name.
#[must_use]
pub fn random_domain() -> String {
    format!("{}.xyz", random_string(32))
}

/// Generate a random alphanumeric of the given length.
#[must_use]
pub fn random_string(len: usize) -> String {
    Alphanumeric.sample_string(&mut rand::rng(), len)
}
