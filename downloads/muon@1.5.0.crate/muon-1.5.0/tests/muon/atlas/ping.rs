use crate::atlas::new_client;
use anyhow::Result;
use muon::GET;

#[tokio::test]
async fn test_ping() -> Result<()> {
    new_client().send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
