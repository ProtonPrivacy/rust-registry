use anyhow::Result;
use muon::app::AppVersion;
use muon::common::prelude::*;
use muon::common::{Host, Server};
use muon::dns::{CloudflareDoh, DohClient, DohService, GoogleDoh, Quad9Doh};
use muon::env::{DynEnv, Env, Prod};
use muon::rt::{AsyncDialer, AsyncResolver, AsyncSpawner, DynResolver, Resolver};
use muon::test::store::TestStore;
use muon::tls::{BaseTrustAnchor, BaseVerifier, RustlsTls, TlsExt, TlsPin, TlsPinSet};
use muon::util::ByteSliceExt;
use muon::{App, Client, GET};

#[tokio::test]
async fn test_doh_normal_routing() -> Result<()> {
    // Create a new app.
    let app = App::new("linux-mail@4.1.0")?;
    let store = TestStore::prod();

    // Create the client with the standard environment.
    let client = Client::builder(app, store).doh([GoogleDoh]).build()?;

    // Ping should work; we'll use standard routing.
    if let Err(err) = client.send(GET!("/tests/ping")).await {
        panic!("unexpected error: {err}");
    }

    Ok(())
}

#[cfg(not(ci))] // FixMe: it is failing in the CI due to the proxy doing some weird stuff..
#[tokio::test]
async fn test_doh_alt_routing() -> Result<()> {
    // Create a new app.

    use muon::util::DurationExt;

    let app = App::new("linux-mail@4.1.0")?;
    let store = TestStore::custom(AltEnv::new(Prod));

    // Create the client with the custom environment.
    let client = Client::builder(app, store)
        .doh([GoogleDoh])
        .doh([CloudflareDoh])
        .doh([Quad9Doh])
        .build()?;

    // Ping should work; we'll use alternate routing.
    if let Err(err) = client.send(GET!("/tests/ping").allowed_time(30.s())).await {
        panic!("unexpected error: {err}");
    }

    Ok(())
}

#[tokio::test]
async fn test_doh_alt_routing_pinning() -> Result<()> {
    let app = App::new("linux-mail@4.1.0")?;
    let store = TestStore::custom(AltEnv::new(Prod).bad());

    // Create the client with the custom environment.
    let client = Client::builder(app, store).doh([GoogleDoh]).build()?;

    // Ping should fail; we'll use alternate routing, but the pins are wrong.
    if let Ok(res) = client.send(GET!("/tests/ping")).await {
        panic!("unexpected success: {res}");
    }

    Ok(())
}

/// An environment that forces alternate routing.
#[derive(Debug)]
struct AltEnv {
    env: DynEnv,
    bad: bool,
}

impl AltEnv {
    fn new(env: impl Env) -> Self {
        Self {
            env: env.into_dyn(),
            bad: false,
        }
    }

    fn bad(self) -> Self {
        Self { bad: true, ..self }
    }
}

impl Env for AltEnv {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        (self.env.servers(version))
            .into_iter()
            .filter(|s| s.host().is_indirect())
            .collect()
    }

    fn pins(&self, server: &Server) -> Option<TlsPinSet> {
        if self.bad {
            Some(TlsPinSet::new([TlsPin::new(rand::random())]))
        } else {
            self.env.pins(server)
        }
    }
}

#[tokio::test]
async fn test_doh_client_direct() -> Result<()> {
    let host = Host::direct("ip.me")?;
    let want = AsyncResolver.resolve(&host).await?.into_set();

    let have = new_resolver(GoogleDoh)?.resolve(&host).await?;
    assert_eq!(have.into_set(), want);

    let have = new_resolver(CloudflareDoh)?.resolve(&host).await?;
    assert_eq!(have.into_set(), want);

    let have = new_resolver(Quad9Doh)?.resolve(&host).await?;
    assert_eq!(have.into_set(), want);

    Ok(())
}

#[tokio::test]
async fn test_doh_client_indirect() -> Result<()> {
    let dir = "api.protonmail.ch".as_b32();
    let alt = Host::indirect(format!("d{dir}.protonpro.xyz"))?;

    let have = new_resolver(GoogleDoh)?.resolve(&alt).await?;
    assert!(!have.into_set().is_empty());

    let have = new_resolver(CloudflareDoh)?.resolve(&alt).await?;
    assert!(!have.into_set().is_empty());

    let have = new_resolver(Quad9Doh)?.resolve(&alt).await?;
    assert!(!have.into_set().is_empty());

    Ok(())
}

fn new_resolver(service: impl DohService) -> Result<DynResolver> {
    let connector = muon::http::HyperConnector::new(
        AsyncSpawner::default(),
        AsyncResolver,
        AsyncDialer,
        RustlsTls.build_any(BaseTrustAnchor, BaseVerifier)?,
        EnvProxy::all("http_proxy"),
    );

    Ok(DohClient::new(service, connector.into_dyn()).into_dyn())
}
