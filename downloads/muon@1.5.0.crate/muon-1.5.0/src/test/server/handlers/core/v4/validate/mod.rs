/// `/core/v4/validate/email`
pub mod email;
