//! ## Timeout
//!
//! This module provides a layer that enforce timeouts on various operations.

use crate::Result;
use futures::prelude::*;
use futures_timer::Delay;
use muon_proc::autoimpl;
use pin_project::pin_project;
use std::borrow::Borrow;
use std::pin::Pin;
use std::task::{ready, Context, Poll};
use std::time::Duration;
use thiserror::Error;

/// The timeout for all DNS UDP request
pub(crate) const DNS_UDP_QUERY: Duration = Duration::from_secs(3);
/// The timeout for all DNS request going over TCP, considering that TCP will retry, we let it work a bit longer
pub(crate) const DNS_TCP_QUERY: Duration = Duration::from_secs(4);
/// The TCP handshake timeout
pub(crate) const TCP_CONNECT_TIMEOUT: Duration = Duration::from_secs(5); // TCP retries are (by default) at 1s and 3s. Cancel at 5s letting ~2s to the last trial.
/// The TLS handshake timeout
pub(crate) const TLS_HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(3);
/// Timeout when trying to establish a HTTP Tunnel through an HTTP Proxy (HTTP Connect -> HTTP 200 OK)
pub(crate) const PROXY_TUNNEL_HTTP_CONNECT_TIMEOUT: Duration = Duration::from_secs(5);
/// Interval for the HTTP2 ping frame
pub(crate) const HTTP2_KEEP_ALIVE_INTERVAL: Duration = Duration::from_secs(5);
/// Timeout after which the connection is considered dead
pub(crate) const HTTP2_KEEP_ALIVE_TIMEOUT: Duration = Duration::from_secs(20);

/// A timeout error.
#[derive(Debug, Error, PartialEq, Eq)]
#[error("operation timed out")]
pub struct Timeout;

/// Create a new timeout layer with the given duration.
pub fn with_timeout(timeout: impl Borrow<Duration>) -> TimeoutLayer {
    TimeoutLayer(timeout.borrow().to_owned())
}

/// A layer that enforces a timeout.
#[must_use]
#[derive(Debug)]
pub struct TimeoutLayer(Duration);

impl Borrow<Duration> for TimeoutLayer {
    fn borrow(&self) -> &Duration {
        &self.0
    }
}

impl Borrow<Duration> for &TimeoutLayer {
    fn borrow(&self) -> &Duration {
        &self.0
    }
}

/// Applies a timeout to a future.
#[autoimpl]
pub trait WithTimeout: Future + Sized {
    /// Set the timeout for this future.
    fn with_timeout(self, t: impl Borrow<Duration>) -> TimeoutFut<Self> {
        TimeoutFut::with_timeout(self, t.borrow().to_owned())
    }

    /// Set an optional timeout for this future.
    fn maybe_with_timeout(self, t: Option<impl Borrow<Duration>>) -> TimeoutFut<Self> {
        if let Some(t) = t.map(|t| t.borrow().to_owned()) {
            TimeoutFut::with_timeout(self, t)
        } else {
            TimeoutFut::without_timeout(self)
        }
    }
}

/// A future with a timeout.
#[pin_project]
#[derive(Debug)]
pub struct TimeoutFut<F> {
    #[pin]
    inner: F,

    #[pin]
    delay: Option<Delay>,
}

impl<F> TimeoutFut<F> {
    /// Wrap a future with a timeout of the given duration.
    pub fn with_timeout(inner: F, duration: Duration) -> Self {
        let delay = Some(Delay::new(duration));

        Self { inner, delay }
    }

    /// Wrap a future but don't set a timeout.
    pub fn without_timeout(inner: F) -> Self {
        Self { inner, delay: None }
    }
}

impl<F: Future> Future for TimeoutFut<F> {
    type Output = Result<F::Output, Timeout>;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context) -> Poll<Self::Output> {
        let this = self.as_mut().project();

        if let Some(delay) = this.delay.as_pin_mut() {
            if let Poll::Ready(()) = delay.poll(cx) {
                return Poll::Ready(Err(Timeout));
            }
        }

        Poll::Ready(Ok(ready!(this.inner.poll(cx))))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::util::DurationExt;

    #[test]
    fn test_with_timeout() {
        futures::executor::block_on(async {
            let fut = Delay::new(1.s());
            let fut = fut.with_timeout(500.ms());
            assert_eq!(fut.await, Err(Timeout));

            let fut = Delay::new(500.ms());
            let fut = fut.with_timeout(1.s());
            assert_eq!(fut.await, Ok(()));
        });
    }
}
