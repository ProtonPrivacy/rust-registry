use crate::common::prelude::*;
use crate::http::common::pool::{Pool, PooledSender, TryGet};
use crate::http::prelude::*;
use crate::{Error, ErrorKind, Result};
use futures::TryFutureExt;
use std::fmt::{Display, Formatter, Result as FmtResult};
use std::sync::Arc;
use thiserror::Error;

/// An HTTP sender.
#[derive(Debug)]
pub struct HttpSender {
    servers: Vec<Server>,
    connector: DynHttpConnector,
    pool: Arc<Pool>,
}

impl HttpSender {
    /// Create a new HTTP sender.
    #[must_use]
    pub fn new<I: IntoDyn<DynHttpConnector>>(connector: I, servers: Vec<Server>) -> Self {
        Self {
            servers,
            connector: connector.into_dyn(),
            pool: Arc::default(),
        }
    }

    #[instrument(level = "debug", skip(self), fields(%req), err)]
    async fn send(&self, req: HttpReq) -> Result<HttpRes> {
        req.audit();

        let timeout = req.get_allowed_time().to_owned();

        self.send_inner(req)
            .with_timeout(timeout)
            .map_err(ErrorKind::send)
            .await?
    }

    async fn send_inner(&self, req: HttpReq) -> Result<HttpRes> {
        let mut pool = self.pool.lock().await;

        for s in &self.servers {
            pool = match pool.get(&s.endpoint) {
                TryGet::Some(sender) => return self.send_with(sender, req).await,
                TryGet::None(pool) => pool,
            };
        }

        let mut errors = Vec::new();

        for s in &self.servers {
            // FixMe: why not connecting to all servers in parallel and take the first one?
            match self.connector.connect(s).await {
                Ok(sender) => {
                    let sender = pool.insert(&s.endpoint, sender);
                    return self.send_with(sender, req).await;
                }

                Err(err) => {
                    error!(server = %s, %err, "failed to connect to server");
                    errors.push(err)
                }
            }
        }

        Err(HttpSendErr::new(errors))?
    }

    async fn send_with(&self, sender: PooledSender, req: HttpReq) -> Result<HttpRes> {
        match sender.send(req).await {
            Ok(res) => {
                sender.repool().await;
                Ok(res)
            }

            Err(err) => {
                sender.unpool().await;
                Err(err)
            }
        }
    }
}

impl Sender<HttpReq, HttpRes> for HttpSender {
    fn send(&self, req: HttpReq) -> BoxFut<Result<HttpRes>> {
        Box::pin(self.send(req))
    }
}

mod errors {
    use super::*;

    #[derive(Debug, Error)]
    pub struct HttpSendErr(Vec<Error>);

    impl HttpSendErr {
        pub fn new(errors: Vec<Error>) -> Self {
            Self(errors)
        }
    }

    impl Display for HttpSendErr {
        fn fmt(&self, f: &mut Formatter) -> FmtResult {
            if let Some(err) = self.0.last() {
                write!(f, "{err}")
            } else {
                write!(f, "no servers available")
            }
        }
    }

    impl From<HttpSendErr> for Error {
        fn from(err: HttpSendErr) -> Self {
            ErrorKind::send(err)
        }
    }
}

use self::errors::*;
