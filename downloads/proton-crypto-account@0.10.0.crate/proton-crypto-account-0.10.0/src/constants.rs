pub(crate) const FLAG_EMAIL_NO_SIGN: u32 = 8;
pub(crate) const FLAG_EMAIL_NO_ENCRYPT: u32 = 4;
pub(crate) const FLAG_NOT_OBSOLETE: u32 = 2;
pub(crate) const FLAG_NOT_COMPROMISED: u32 = 1;
