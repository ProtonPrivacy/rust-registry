use serde::{Deserialize, Serialize};
use serde_json::Value;

/// `POST /auth/v4/2fa`
///
/// Authenticates a user using 2FA.
///
/// It is assumed the user already has a valid auth;
/// this request is only used to acquire additional auth scopes.
#[derive(Debug, Serialize, Deserialize)]
pub enum Post {
    /// Provides a TOTP code for 2FA.
    #[serde(rename = "TwoFactorCode")]
    TOTP(String),

    /// Provides a FIDO2 assertion for 2FA.
    #[serde(rename = "FIDO2")]
    FIDO(Value),
}

/// The response from a `POST /auth/v4/2fa` request.
///
/// Contains the additional auth scopes granted by the successful 2FA.
#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct PostRes {
    /// The granted auth scopes.
    pub scopes: Vec<String>,
}
