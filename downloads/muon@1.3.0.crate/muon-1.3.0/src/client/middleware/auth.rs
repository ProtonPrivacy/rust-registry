use crate::auth::{Auth, Tokens};
use crate::client::headers::{AuthTokenHeader, AuthUidHeader};
use crate::client::ClientInternalStorage;
use crate::common::{BoxFut, Sender, SenderLayer};
use crate::http::{HttpReq, HttpReqExt, HttpRes, Status, StatusErr, POST};
use crate::rest::auth;
use crate::store::{AuthVersion, SafeStore};
use crate::{Error, ErrorKind, Result};
use futures::TryFutureExt;
use thiserror::Error;

/// Errors that can occur while using the auth layer.
#[derive(Debug, Error)]
pub enum AuthErr {
    /// The session could not be refreshed.
    #[error("refresh failed")]
    Refresh,

    /// The session does not exist.
    #[error("non-existent session")]
    Session,
}

/// An auth layer: sets the auth headers from the store if available,
/// refreshes the auth session if necessary, and retries the request.
#[must_use]
#[derive(Debug)]
pub struct AuthLayer {
    stores: ClientInternalStorage,
}

impl AuthLayer {
    /// Create a new auth layer from the given store.
    pub fn new(stores: ClientInternalStorage) -> Self {
        AuthLayer { stores }
    }
}

impl AuthLayer {
    async fn on_send<S>(&self, inner: &S, req: HttpReq) -> Result<HttpRes, AuthLayerErr>
    where
        S: Sender<HttpReq, HttpRes>,
        S: ?Sized,
    {
        let (ver, auth) = self.stores.get_auth().await;

        let Some(uid) = auth.uid() else {
            debug!("no auth session available, sending as-is");
            return Ok(inner.send(req).await?);
        };

        debug!(%uid, "attaching auth UID to request");
        let req = req.header(AuthUidHeader::new(uid));

        let Some(tok) = auth.tokens() else {
            debug!(%uid, "no auth tokens available, sending as-is");
            return Ok(inner.send(req).await?);
        };

        if let Some(tok) = tok.acc_tok() {
            debug!(%uid, "attaching auth token to request");
            let req = req.clone().header(AuthTokenHeader::new(tok));

            debug!(%uid, "sending authenticated request");
            match inner.send(req).await? {
                t if !t.is(Status::UNAUTHORIZED) => return Ok(t),
                _ => warn!(%uid, "session unauthorized"),
            }
        }

        let Some(user_id) = auth.user_id() else {
            error!(%uid, "no user ID associated with auth session");
            return Err(AuthLayerErr::StoreState(StoreStateErr));
        };

        match refresh_store(inner, self.stores.local(), user_id, uid, tok, &ver).await {
            Ok(auth) => match auth.acc_tok() {
                Some(tok) => {
                    info!(%uid, "refresh succeeded, sync to persistent store");
                    self.stores.sync_stores().await;

                    info!(%uid, "sending authenticated request with updated tokens");
                    Ok(inner.send(req.header(AuthTokenHeader::new(tok))).await?)
                }

                None => {
                    error!(%uid, "no access token available after refresh");
                    Err(AuthErr::Refresh)?
                }
            },

            Err(err @ AuthLayerErr::Auth(AuthErr::Session)) => {
                warn!(%uid, "auth session no longer exists");
                self.stores.local().set_auth(Auth::None).await;
                self.stores.sync_stores().await;

                Err(err)
            }

            Err(err) => Err(err),
        }
    }
}

impl SenderLayer<HttpReq, HttpRes> for AuthLayer {
    fn on_send<'a: 'fut, 'fut>(
        &'a self,
        inner: &'a dyn Sender<HttpReq, HttpRes>,
        req: HttpReq,
    ) -> BoxFut<'fut, Result<HttpRes>> {
        Box::pin(self.on_send(inner, req).err_into())
    }
}

async fn auth_refresh<S>(inner: &S, uid: &str, tok: &str) -> Result<Tokens, AuthLayerErr>
where
    S: Sender<HttpReq, HttpRes>,
    S: ?Sized,
{
    // Build the refresh request.
    let req = auth::v4::refresh::Post {
        refresh_token: tok.to_owned(),
        response_type: "token".to_owned(),
        grant_type: "refresh_token".to_owned(),
        redirect_uri: "https://protonmail.ch".to_owned(),
    };

    // Send the refresh request.
    let res = POST!("/auth/v4/refresh")
        .header(AuthUidHeader::new(uid))
        .body_json(req)?
        .send_with(inner)
        .await?;

    // Parse the refresh response.
    let res: auth::v4::refresh::PostRes = match res.ok() {
        Ok(res) => {
            debug!("auth refresh successful");
            res.into_body_json()?
        }

        Err(StatusErr(Status::UNPROCESSABLE_ENTITY, _)) => {
            error!("non-existent auth session");
            return Err(AuthErr::Session)?;
        }

        Err(err) => {
            error!(%err, "unexpected error during auth refresh");
            return Err(AuthErr::Refresh)?;
        }
    };

    // The UID should *never* change.
    assert_eq!(res.auth.uid, uid);

    // Build the new set of tokens.
    Ok(Tokens::access(
        res.auth.access_token,
        res.auth.refresh_token,
        res.auth.scopes,
    ))
}

async fn refresh_store<S>(
    inner: &S,
    store: &SafeStore,
    user_id: &str,
    uid: &str,
    tok: &Tokens,
    ver: &AuthVersion,
) -> Result<Auth, AuthLayerErr>
where
    S: Sender<HttpReq, HttpRes>,
    S: ?Sized,
{
    debug!(%uid, "locking store for auth refresh");
    let mut store = store.write().await;

    debug!(%uid, "checking current auth session version");
    let auth = match store.get_auth().await {
        (ref cur, _) if cur == ver => {
            info!(%uid, "attempting auth refresh");
            let tok = auth_refresh(inner, uid, tok.ref_tok()).await?;

            info!(%uid, "building new auth object");
            let auth = Auth::internal(user_id, uid, tok);

            info!(%uid, "storing new auth tokens");
            store.set_auth(auth.clone()).await;

            auth
        }

        (_, auth) => {
            debug!("auth session already updated");
            auth
        }
    };
    Ok(auth)
}

mod errors {
    use super::*;

    #[derive(Debug, Error)]
    #[error("invalid store state")]
    pub struct StoreStateErr;

    #[derive(Debug, Error)]
    #[error("auth layer: {0}")]
    pub enum AuthLayerErr {
        Auth(#[from] AuthErr),
        StatusErr(#[from] StatusErr),
        StoreState(#[from] StoreStateErr),
        Inner(#[from] Error),
    }

    impl From<AuthLayerErr> for Error {
        fn from(err: AuthLayerErr) -> Self {
            if let AuthLayerErr::Inner(err) = err {
                err.map_kind(ErrorKind::Send)
            } else {
                ErrorKind::send(err)
            }
        }
    }
}

use self::errors::*;
