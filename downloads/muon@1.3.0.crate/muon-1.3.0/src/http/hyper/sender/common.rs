use async_trait::async_trait;
use http::{Request, Response};
use muon_proc::autoimpl;

#[async_trait]
pub trait ReadySend<B> {
    async fn ready_send(&self, req: Request<B>) -> hyper::Result<Response<Vec<u8>>>;
}

#[async_trait]
pub trait ReadySendMut<B> {
    async fn ready_send_mut(&mut self, req: Request<B>) -> hyper::Result<Response<Vec<u8>>>;
}

#[autoimpl]
#[async_trait]
pub trait SendWith<B>: Into<Request<B>> + Sized {
    async fn send_with<T>(self, sender: &T) -> hyper::Result<Response<Vec<u8>>>
    where
        T: ReadySend<B> + Send + Sync,
    {
        sender.ready_send(self.into()).await
    }

    async fn send_with_mut<T>(self, sender: &mut T) -> hyper::Result<Response<Vec<u8>>>
    where
        T: ReadySendMut<B> + Send,
    {
        sender.ready_send_mut(self.into()).await
    }
}

pub fn fmt_req<B>(req: &Request<B>) -> String {
    format!("{} {}", req.method(), req.uri())
}
