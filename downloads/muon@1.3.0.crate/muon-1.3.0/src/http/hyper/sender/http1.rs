use crate::common::prelude::*;
use crate::common::DynSocket;
use crate::http::hyper::compat::{HyperIo, HyperRt};
use crate::http::hyper::sender::{fmt_req, ReadySend, ReadySendMut, SendWith};
use crate::http::{Body, Collect, HttpReq, HttpRes, Version};
use crate::rt::DynSpawner;
use crate::{ErrorKind, Result};
use async_trait::async_trait;
use futures::lock::Mutex;
use futures::TryFutureExt;
use http::{Request, Response};
use hyper::client::conn::http1;
use hyper::client::conn::http1::SendRequest;
use hyper::rt::Executor;
use url::Url;

pub async fn new_http1_sender(
    sock: impl IntoDyn<DynSocket>,
    exec: impl IntoDyn<DynSpawner>,
    base: Url,
) -> Result<H1Sender> {
    let sock = HyperIo(sock.into_dyn());
    let exec = HyperRt(exec.into_dyn());

    H1Sender::connect(sock, exec, base)
        .map_err(ErrorKind::connect)
        .await
}

#[derive(Debug)]
pub struct H1Sender {
    sender: Mutex<SendRequest<Body>>,
    base: Url,
}

impl H1Sender {
    fn new(sender: SendRequest<Body>, base: Url) -> Self {
        let sender = Mutex::new(sender);

        Self { sender, base }
    }

    async fn connect(sock: HyperIo, exec: HyperRt, base: Url) -> hyper::Result<Self> {
        debug!(%base, "performing HTTP/1.1 handshake");

        let (sender, driver) = http1::handshake(sock).await?;

        exec.execute(driver.with_upgrades());

        Ok(Self::new(sender, base))
    }

    async fn send(&self, req: HttpReq) -> Result<HttpRes> {
        debug!(%req, "sending with HTTP/1.1 sender");

        HttpReq::build(req, Version::HTTP_11, &self.base)?
            .send_with(&self.sender)
            .ok_into()
            .map_err(|e| {
                debug!("send error occured: {e}");
                if e.is_closed() {
                    ErrorKind::closed(e)
                } else {
                    ErrorKind::send(e)
                }
            })
            .await
    }
}

impl Sender<HttpReq, HttpRes> for H1Sender {
    fn send(&self, req: HttpReq) -> BoxFut<Result<HttpRes>> {
        Box::pin(self.send(req))
    }
}

impl Drop for H1Sender {
    fn drop(&mut self) {
        debug!("dropping H1Sender");
    }
}

#[async_trait]
impl<B: http_body::Body + Send + 'static> ReadySend<B> for Mutex<SendRequest<B>> {
    #[instrument(level = "debug", skip_all, fields(req = %fmt_req(&req)), err)]
    async fn ready_send(&self, req: Request<B>) -> hyper::Result<Response<Vec<u8>>> {
        debug!("sending request with HTTP/1.1 sender");
        let mut this = self.lock().await;

        debug!("waiting for HTTP/1.1 sender to be ready");
        this.ready().await?;

        debug!("HTTP/1.1 sender is ready, sending request");
        this.send_request(req).await?.collect().await
    }
}

#[async_trait]
impl<B: http_body::Body + Send + 'static> ReadySendMut<B> for SendRequest<B> {
    #[instrument(level = "debug", skip_all, fields(req = %fmt_req(&req)), err)]
    async fn ready_send_mut(&mut self, req: Request<B>) -> hyper::Result<Response<Vec<u8>>> {
        debug!("waiting for HTTP/1.1 sender to be ready");
        self.ready().await?;

        debug!("HTTP/1.1 sender is ready, sending request");
        self.send_request(req).await?.collect().await
    }
}
