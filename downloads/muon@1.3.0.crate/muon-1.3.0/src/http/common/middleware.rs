//! HTTP middleware.

use crate::common::{BoxFut, IntoDyn, RetryPolicy, Sender, SenderLayer};
use crate::http::{AsHeader, DynHttpSenderLayer, HttpReq, HttpRes};
use crate::Result;
use std::sync::Arc;

/// Creates a layer that sets a header on every outgoing request.
#[must_use]
pub fn set_header(header: impl AsHeader + Send + Sync + 'static) -> DynHttpSenderLayer {
    SetHeaderLayer(Arc::new(header)).into_dyn()
}

/// Creates a layer that sets the retry policy on every outgoing request
/// (if not already set).
#[must_use]
pub fn set_retry_policy(policy: RetryPolicy) -> DynHttpSenderLayer {
    SetRetryPolicyLayer(policy).into_dyn()
}

/// A layer that sets a header on every outgoing request.
struct SetHeaderLayer<T>(Arc<T>);

impl<T: AsHeader> SetHeaderLayer<T> {
    async fn on_send(&self, inner: &dyn Sender<HttpReq, HttpRes>, req: HttpReq) -> Result<HttpRes> {
        inner.send(req.header(self.0.as_ref())).await
    }
}

impl<T> SenderLayer<HttpReq, HttpRes> for SetHeaderLayer<T>
where
    T: AsHeader + Send + Sync + 'static,
{
    fn on_send<'a: 'fut, 'fut>(
        &'a self,
        inner: &'a dyn Sender<HttpReq, HttpRes>,
        req: HttpReq,
    ) -> BoxFut<'fut, Result<HttpRes>> {
        Box::pin(self.on_send(inner, req))
    }
}

/// A layer that sets the retry policy on every outgoing request.
struct SetRetryPolicyLayer(RetryPolicy);

impl SetRetryPolicyLayer {
    async fn on_send(&self, inner: &dyn Sender<HttpReq, HttpRes>, req: HttpReq) -> Result<HttpRes> {
        if req.get_retry_policy().is_none() {
            Ok(inner.send(req.retry_policy(self.0)).await?)
        } else {
            Ok(inner.send(req).await?)
        }
    }
}

impl SenderLayer<HttpReq, HttpRes> for SetRetryPolicyLayer {
    fn on_send<'a: 'fut, 'fut>(
        &'a self,
        inner: &'a dyn Sender<HttpReq, HttpRes>,
        req: HttpReq,
    ) -> BoxFut<'fut, Result<HttpRes>> {
        Box::pin(self.on_send(inner, req))
    }
}
