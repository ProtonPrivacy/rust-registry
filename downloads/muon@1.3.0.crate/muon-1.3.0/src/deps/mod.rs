//! ## Deps
//!
//! This module re-exports dependencies needed by derived code.

pub extern crate cfg_if;
pub extern crate itertools;
pub extern crate url;
