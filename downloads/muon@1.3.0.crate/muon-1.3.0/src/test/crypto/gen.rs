#![allow(warnings)]
#![allow(clippy::pedantic)]

include!(env!("GEN_GO_CRYPTO"));
