use crate::atlas::{new_client, PASS, PASS_2FA, TOTP_2FA, USER, USER_2FA};
use anyhow::{bail, Result};
use muon::client::flow::{ForkFlowResult, LoginExtraInfo, LoginFlow, WithSelectorFlow};
use muon::rest::core;
use muon::GET;
use serde_json::json;
use std::future::Future;
use totp_rs::{Algorithm, Secret, TOTP};

#[tokio::test]
async fn test_auth_deprecated() -> Result<()> {
    #[allow(deprecated)]
    _test_auth(new_client().auth().login(USER, PASS)).await
}

#[tokio::test]
async fn test_auth_with_extra() -> Result<()> {
    _test_auth(
        new_client()
            .auth()
            .login_with_extra(USER, PASS, LoginExtraInfo::default()),
    )
    .await
}

async fn _test_auth(login_flow: impl Future<Output = LoginFlow>) -> Result<()> {
    #[allow(deprecated)]
    let client = match login_flow.await {
        LoginFlow::Ok(c, _) => c,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let req = GET!("/core/v4/users");
    let res = client.send(req).await?;
    let res: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    assert_eq!(res.user.name, USER);

    Ok(())
}

#[tokio::test]
async fn test_auth_with_fingerprint() -> Result<()> {
    let fingerprint = json!([
        {
            "appLang": "en",
            "timezone": "Europe/Zurich",
            "deviceName": "TestDevice",
            "regionCode": "CH",
            "timezoneOffset": 0,
            "isJailbreak": false,
            "preferredContentSize": "2.0",
            "storageCapacity": 63.8,
            "isDarkmodeOn": false,
            "keyboards": [],
            "frame": { "name": "username" },
            "v": "2.0.0"
        }
    ]);
    let extra_info = LoginExtraInfo::builder()
        .with_fingerprint(fingerprint.into())
        .build();
    let client = match new_client()
        .auth()
        .login_with_extra(USER, PASS, extra_info)
        .await
    {
        LoginFlow::Ok(c, _) => c,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let req = GET!("/core/v4/users");
    let res = client.send(req).await?;
    let res: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    assert_eq!(res.user.name, USER);

    Ok(())
}

#[tokio::test]
async fn test_auth_2fa() -> Result<()> {
    let client = match new_client()
        .auth()
        .login_with_extra(USER_2FA, PASS_2FA, LoginExtraInfo::default())
        .await
    {
        LoginFlow::TwoFactor(c, _) => match (c.has_totp(), c.has_fido()) {
            (true, _) => c.totp(next_totp(TOTP_2FA)?).await?,
            (_, true) => bail!("FIDO not supported"),
            _ => bail!("unexpected 2FA methods"),
        },

        LoginFlow::Ok(_, _) => bail!("unexpected success"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let req = GET!("/core/v4/users");
    let res = client.send(req).await?;
    let res: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    assert_eq!(res.user.name, USER_2FA);

    Ok(())
}

#[tokio::test]
async fn test_auth_fork() -> Result<()> {
    // Create a new client.
    let c1 = match new_client()
        .auth()
        .login_with_extra(USER, PASS, LoginExtraInfo::default())
        .await
    {
        LoginFlow::Ok(c, _) => c,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    // Make a fork of the parent session.
    let ForkFlowResult::Success(c1, selector) =
        c1.fork("Other").payload("foo bar baz").send().await
    else {
        bail!("Failed to fork")
    };

    // Create a new client for the child session.
    let WithSelectorFlow::Ok(c2, _) = new_client()
        .auth()
        .from_fork()
        .with_selector(selector)
        .await
    else {
        bail!("Failed to take ownership of the fork")
    };

    // Both clients should be authorized.
    let req = GET!("/core/v4/users");
    let res = c1.send(req).await?;
    let res: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    assert_eq!(res.user.name, USER);

    let req = GET!("/core/v4/users");
    let res = c2.send(req).await?;
    let res: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    assert_eq!(res.user.name, USER);

    Ok(())
}

fn next_totp(secret: &str) -> Result<String> {
    const DIGITS: usize = 6;
    const SKEW: u8 = 1;
    const STEP: u64 = 30;
    const SHA1: Algorithm = Algorithm::SHA1;

    let secret = Secret::Encoded(secret.to_owned()).to_bytes()?;
    let totp = &TOTP::new(SHA1, DIGITS, SKEW, STEP, secret)?;
    let next = totp.generate_current()?;

    Ok(next)
}
