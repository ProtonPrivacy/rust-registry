use muon::client::Builder;
use muon::test::store::TestStore;
use muon::{App, Client};

const USER: &str = "plus";
const PASS: &str = "plus";

const USER_2FA: &str = "twofa";
const PASS_2FA: &str = "a";
const TOTP_2FA: &str = "4R5YJICSS6N72KNN3YRTEGLJCEKIMSKJ";

/// Simple ping tests against the Atlas API.
mod ping;

/// Auth tests.
mod auth;

/// Error tests.
mod error;

/// Timeout tests.
mod timeout;

/// Mail tests.
mod mail;

/// Runtime tests.
mod runtime;

/// Parallel tests.
mod parallel;

/// TLS tests.
mod tls;

/// Creates a new test client.
fn new_client() -> Client {
    new_builder().build().expect("client should build")
}

/// Creates a new test client builder.
fn new_builder() -> Builder {
    let app = App::default();
    let store = new_atlas_store();

    Client::builder(app, store)
}

/// Create a new test store for the Atlas environment.
fn new_atlas_store() -> TestStore {
    if let Ok(name) = std::env::var("ENV_NAME") {
        TestStore::atlas_name(&name)
    } else {
        TestStore::atlas()
    }
}
