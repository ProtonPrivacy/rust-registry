#!/bin/env python3
'''
This script generates a binary status output based on the provided JSON input.
It reads a JSON array from standard input, where each object in the array contains
fields 'status', 'load', and 'partial_score'. The output is a binary format that
includes a header and the values from the JSON objects.

Example usage:
    echo '[{"Status": 3, "Load": 50, "PartialScore": 0.5}, {"Status": 3, "Load": 25, "PartialScore": 0.75}]' | python3 make_binary_status.py > output.bin
'''

import json
import struct
import sys


def make_binary_status(loads):
    format_string = '<bbbb' + ('bbf' * len(loads))

    values = [1, 0, 0, 0]  # Initial values for the first four bytes
    for load in loads:
        values.extend([
            load['Status'],  # Status
            load['Load'],    # Load
            load['PartialScore']  # Partial score
        ])

    return struct.pack(format_string, *values)


if __name__ == "__main__":
    sys.stdout.buffer.write(make_binary_status(json.load(sys.stdin)))
