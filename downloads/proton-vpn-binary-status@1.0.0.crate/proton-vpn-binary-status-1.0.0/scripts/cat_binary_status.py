#!/bin/env python3

import sys
import json
import struct

if sys.stdin.buffer.read(4) != bytearray([1, 0, 0, 0]):
    raise ValueError("Not a valid binary status file")

print("[")
while b := sys.stdin.buffer.read(6):
    (status, load, partial_score) = struct.unpack("<BBf", b)

    print("  ", end="")
    json.dump({
        "Status" : status,
        "Load"   : load,
        "PartialScore" : partial_score,
    }, sys.stdout)
    print(",")
print("]")

