use async_compat::Compat;
use futures::TryFutureExt as _;
use muon::rt::{
    InstantFactory, Monotonic, MuonInstant, MuonSystemTime, OperatingSystem, Resolve,
    SinceUnixEpoch, Sleep, SystemTimeFactory, TcpConnect,
};
use std::pin::Pin;

#[macro_export]
macro_rules! new_client {
    ($app: expr, $env: expr) => {{
        use shared::*;
        muon::Client::builder($app.clone(), $env.clone())
            .with_operating_system(MyOperatingSystem::default(), rand::rng())
            .with_multi_thread_executor(TokioExecutor)
    }};
}

#[derive(Debug, Clone)]
pub struct TimeCapability {
    at_start: std::time::Instant,
}

impl Default for TimeCapability {
    fn default() -> Self {
        Self {
            at_start: std::time::Instant::now(),
        }
    }
}

impl Sleep for TimeCapability {
    type Sleep<'a>
        = Pin<Box<dyn Future<Output = ()> + Send + Sync + 'a>>
    where
        Self: 'a;

    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'static> {
        Box::pin(tokio::time::sleep(duration))
    }
}

impl InstantFactory for TimeCapability {
    type Instant = MuonInstant;

    fn now(&self) -> Self::Instant {
        MuonInstant::from_duration(std::time::Instant::now() - self.at_start)
    }
}

unsafe impl Monotonic for TimeCapability {}

impl SystemTimeFactory for TimeCapability {
    type SystemTime = MuonSystemTime;

    fn now(&self) -> Self::SystemTime {
        MuonSystemTime::since_unix_epoch(
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .expect("failed to get time"),
        )
    }
}

#[derive(Debug, Clone, Default)]
pub struct MyTcpConnector;

impl TcpConnect for MyTcpConnector {
    type Socket = Compat<tokio::net::TcpStream>;
    type Err = std::io::Error;

    fn tcp_connect(
        &self,
        addr: std::net::SocketAddr,
    ) -> impl Future<Output = Result<Self::Socket, Self::Err>> {
        tokio::net::TcpStream::connect(addr).map_ok(Compat::new)
    }
}

#[derive(Debug, Clone, Default)]
pub struct MyResolver;

impl Resolve for MyResolver {
    fn resolve(
        &self,
        host: &str,
    ) -> impl std::future::Future<Output = std::result::Result<Vec<core::net::IpAddr>, Self::Err>>
    {
        tokio::net::lookup_host(format!("{host}:80"))
            .map_ok(|addresses| addresses.map(|addr| addr.ip()).collect())
    }

    type Err = std::io::Error;
}

#[derive(Debug, Clone, Default)]
pub struct MyOperatingSystem {
    time: TimeCapability,
    dialer: MyTcpConnector,
    resolver: MyResolver,
}

impl OperatingSystem for MyOperatingSystem {
    type Resolver = MyResolver;
    type TcpConnector = MyTcpConnector;
    type Time = TimeCapability;

    fn get_time_capabilities(&self) -> &Self::Time {
        &self.time
    }

    fn get_tcp_connector(&self) -> &Self::TcpConnector {
        &self.dialer
    }

    fn get_resolver(&self) -> &Self::Resolver {
        &self.resolver
    }
}

#[derive(Debug, Clone)]
pub struct TokioExecutor;

impl futures::task::Spawn for TokioExecutor {
    fn spawn_obj(
        &self,
        future: futures::task::FutureObj<'static, ()>,
    ) -> Result<(), futures::task::SpawnError> {
        let _ = tokio::spawn(future);
        Ok(())
    }
}
