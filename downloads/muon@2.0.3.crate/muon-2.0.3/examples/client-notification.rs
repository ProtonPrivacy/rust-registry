//! This example demonstrates how to receive notification from inside of muon
use anyhow::Result;
use muon::common::notification::{Event, InformationalEvent};
use muon::util::DurationExt;
use muon::{App, GET};
use tracing::info;
mod shared;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let app = App::new("windows-vpn@4.1.0")?.with_user_agent("Mozilla/5.0");
    let env = muon::env::Environment::new_atlas();
    let (client, probe_receiver) = new_client!(app.clone(), env.clone())
        .without_persistence::<()>()
        .with_notification_receiver(|data| match data {
            muon::common::notification::Event::Informational(_) => None,
            otherwise => Some(otherwise),
        });

    let client = client.build()?;

    std::thread::spawn(move || {
        while let Ok(event) = probe_receiver.recv() {
            let (key, event) = event.into_parts();
            match event {
                Event::Informational(InformationalEvent::RateLimited) => {
                    println!("session {key:?} is ratelimited")
                }
                Event::Informational(InformationalEvent::InternalServerError) => {
                    unimplemented!("this event has been filtered")
                }
                Event::Informational(_) => { /* more might be added */ }
                Event::ActionRequired(_) => { /* more might be added */ }
            }
        }
    });

    let session = client.new_session_without_credentials(()).await?;

    let req = GET!("/tests/ping").allowed_time(2.s());

    info!("created session with environment {:?}", session.env());

    let resp = session.send(req).await?;

    info!("{resp} {}", resp.body_str()?);

    Ok(())
}
