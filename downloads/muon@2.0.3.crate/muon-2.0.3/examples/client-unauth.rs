//! This example demonstrates how a un-authenticated session sends a request
use anyhow::Result;
use muon::{App, GET};
use tracing::info;
mod shared;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let app = App::new("windows-vpn@4.1.0")?.with_user_agent("Mozilla/5.0");
    let env = muon::env::Environment::new_atlas();

    let session = new_client!(app, env)
        .without_persistence::<()>()
        .build()?
        .new_session_without_credentials(())
        .await?;

    info!("created session with environment {:?}", session.env());

    let fut = async move { session.send(GET!("/tests/ping")).await };

    let resp = tokio::spawn(fut).await.unwrap()?;

    println!("{resp} {}", resp.body_str()?);

    Ok(())
}
