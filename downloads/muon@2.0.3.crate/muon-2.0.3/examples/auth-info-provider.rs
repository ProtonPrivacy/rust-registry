//! This example demonstrates the basic login flow for a muon client with an
//! info provider The info provider is used by the muon client to fetch the
//! fingerprint and attach it to the login call

use anyhow::{Result, bail};
use muon::auth::LoginFlow;
use muon::json::json;
use muon::{App, Environment, Fingerprint, GET, ProvideInformation};
use std::sync::{Arc, Mutex};
mod shared;
// An example implementation of InfoProvider used by the muon Client to fetch
// the fingerprint.
#[derive(Debug, Clone)]
struct ExampleInfoProvider {
    /// This is fine: 99% of the time their wont be a fingerprint update, so
    /// this will mostly be read-only by Muon
    cache: Arc<std::sync::Mutex<Fingerprint>>,
}

impl ExampleInfoProvider {
    fn new() -> (Self, tokio::sync::mpsc::Sender<Fingerprint>) {
        let (send_fingerprint, mut recv_fingerprint) = tokio::sync::mpsc::channel(10);

        let this = Self {
            cache: Mutex::new(Fingerprint(json!({
                "mail-android-99.9.40.0-challenge":{
                    "appLang":"en",
                    "deviceName":"TestDevice",
                    "frame":{
                        "name":"username"
                    },
                    "isDarkmodeOn":false,
                    "isJailbreak":false,
                    "keyboards":[

                    ],
                    "preferredContentSize":"2.0",
                    "regionCode":"CH",
                    "storageCapacity":"63.8",
                    "timezone":"Europe/Zurich",
                    "timezoneOffset":"0",
                    "v":"2.0.0"
                }
            })))
            .into(),
        };
        let this_copy = this.clone();

        // just spawn a task that replace the cached fingerprint... this shall not
        // happen often. If the fingerprint is updated super frequently, then just
        // change the synchronization mechanism... ArcSwap, or else.
        tokio::spawn(async move {
            while let Some(fingerprint) = recv_fingerprint.recv().await {
                let mut cache = this_copy.cache.lock().unwrap();
                *cache = fingerprint;
            }
        });

        (this, send_fingerprint)
    }
}

impl ProvideInformation for ExampleInfoProvider {
    fn fingerprint(&self) -> Option<Fingerprint> {
        Some(self.cache.lock().unwrap().clone())
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    // update the fingerprint cache from the update channel for instance
    let (fingerprint_provider, _) = ExampleInfoProvider::new();

    // First, define which app is using the client.
    let app = App::new("windows-vpn@4.1.0")?;

    // Set the user agent, if desired.
    let app = app.with_user_agent("Mozilla/5.0");

    // Then, specify where the session will persist its session data. We'll use the
    // TestStore for this example; a real app would implement its own store.
    // A store is tied to a specific environment; a prod store holds prod tokens,
    // an atlas store holds atlas tokens, etc.
    let env = Environment::new_atlas();

    // Finally, create the session. The session will be configured to connect to the
    // prod environment, and the session data will be stored in the TestStore.
    // Additionally an info_provider is attached to the Client.
    // The info_provider is used to fetch the fingerprint from the apps that
    // integrate muon. This fingerprint is attached to the login call to help
    // prevent fraud.
    let session = new_client!(app, env)
        .without_persistence::<()>()
        .with_info_provider(fingerprint_provider.clone())
        .build()?
        .new_session_without_credentials(())
        .await?;

    // Auth stuff is done via the auth flow.
    // To begin, call the auth method on the session.
    let auth = session.auth();

    // We can use the auth flow to login.
    let session = match auth.login("visionary", "a").await {
        // The session is now authenticated,
        // and the tokens are in the store.
        LoginFlow::Ok(session, _) => session,

        // The session needs 2FA to complete the login.
        // We can inspect the session to see what kind of 2FA is available.
        LoginFlow::TwoFactor(session, _) => {
            if session.has_totp() {
                session.totp("123456").await?
            } else if session.fido_details().is_some() {
                unimplemented!()
            } else {
                bail!("no 2FA available");
            }
        }

        LoginFlow::Failed { reason, .. } => {
            println!("Login failure: {reason}, session is staying un-logged.");
            session
        }
    };

    // The session can *always* do the ping
    session.send(GET!("/tests/ping")).await?.ok()?;

    // Now we can use the session to make authenticated requests, if the login was
    // successful. The session will automatically use the tokens in the store.
    // If the tokens are expired, the session will refresh them.
    session.send(GET!("/core/v4/users")).await?.ok()?;

    Ok(())
}
