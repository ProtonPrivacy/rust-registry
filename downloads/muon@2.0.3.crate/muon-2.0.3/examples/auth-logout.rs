//! This example demonstrates the basic logout flow for a muon session.

use anyhow::{Result, bail};
use muon::auth::LoginFlow;
use muon::{App, Environment, GET};
mod shared;
#[tokio::main]
async fn main() -> Result<()> {
    // Create a new session.
    let app = App::new("windows-vpn@4.1.0")?;
    let env = Environment::new_atlas();
    // Please check the auth-info-provider.rs example to see how to pass a
    // fingerprint to the muon client. The fingerprint is important in combating
    // fraud.
    let session = new_client!(app, env)
        .without_persistence::<()>()
        .build()?
        .new_session_without_credentials(())
        .await?;

    // Authenticate the session.
    let session = match session.auth().login("visionary", "a").await {
        LoginFlow::Ok(session, _) => session,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected 2FA"),
        LoginFlow::Failed { reason, .. } => return Err(reason.into()),
    };

    println!("{}", session.send(GET!("/core/v4/users")).await?.ok()?);

    // Now logout.
    session.logout().await;
    // you can still ping
    session.send(GET!("/tests/ping")).await?.ok()?;
    // but you can't query authenticated routes
    assert!(session.send(GET!("/core/v4/users")).await?.ok().is_err());

    Ok(())
}
