//! This example demonstrates the muon builder.
use anyhow::Result;
use async_compat::Compat;
use futures::TryFutureExt;
use muon::common::RetryPolicy;
use muon::rt::{
    InstantFactory, Monotonic, MuonInstant, MuonSystemTime, OperatingSystem, Resolve,
    SinceUnixEpoch as _, Sleep, SystemTimeFactory, TcpConnect,
};
use muon::transport::http::hyper::builder::Hyper;
use muon::{App, Client, Environment, GET};
use std::pin::Pin;
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct TimeCapability {
    at_start: std::time::Instant,
}

impl Default for TimeCapability {
    fn default() -> Self {
        Self {
            at_start: std::time::Instant::now(),
        }
    }
}

impl Sleep for TimeCapability {
    type Sleep<'a>
        = Pin<Box<dyn Future<Output = ()> + Send + Sync + 'a>>
    where
        Self: 'a;

    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'static> {
        Box::pin(tokio::time::sleep(duration))
    }
}

impl InstantFactory for TimeCapability {
    type Instant = MuonInstant;

    fn now(&self) -> Self::Instant {
        MuonInstant::from_duration(std::time::Instant::now() - self.at_start)
    }
}

unsafe impl Monotonic for TimeCapability {}

impl SystemTimeFactory for TimeCapability {
    type SystemTime = MuonSystemTime;

    fn now(&self) -> Self::SystemTime {
        MuonSystemTime::since_unix_epoch(
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .expect("failed to get time"),
        )
    }
}

#[derive(Debug, Clone, Default)]
pub struct MyTcpConnector;

impl TcpConnect for MyTcpConnector {
    type Socket = Compat<tokio::net::TcpStream>;

    async fn tcp_connect(&self, addr: std::net::SocketAddr) -> Result<Self::Socket, Self::Err> {
        tokio::net::TcpStream::connect(addr).await.map(Compat::new)
    }

    type Err = std::io::Error;
}

#[derive(Debug, Clone, Default)]
pub struct MyResolver;

impl Resolve for MyResolver {
    type Err = std::io::Error;

    fn resolve(
        &self,
        host: &str,
    ) -> impl std::future::Future<Output = std::result::Result<Vec<core::net::IpAddr>, Self::Err>>
    {
        tokio::net::lookup_host(format!("{host}:80"))
            .map_ok(|addresses| addresses.map(|addr| addr.ip()).collect())
    }
}

#[derive(Debug, Clone, Default)]
pub struct MyOperatingSystem {
    time: TimeCapability,
    dialer: MyTcpConnector,
    resolver: MyResolver,
}

impl OperatingSystem for MyOperatingSystem {
    type Resolver = MyResolver;
    type TcpConnector = MyTcpConnector;
    type Time = TimeCapability;

    fn get_time_capabilities(&self) -> &Self::Time {
        &self.time
    }

    fn get_tcp_connector(&self) -> &Self::TcpConnector {
        &self.dialer
    }

    fn get_resolver(&self) -> &Self::Resolver {
        &self.resolver
    }
}

#[derive(Debug, Clone)]
pub struct TokioExecutor;

impl futures::task::Spawn for TokioExecutor {
    fn spawn_obj(
        &self,
        future: futures::task::FutureObj<'static, ()>,
    ) -> Result<(), futures::task::SpawnError> {
        let _ = tokio::spawn(future);
        Ok(())
    }
}

type MySessionKey = ();

#[tokio::main(flavor = "multi_thread", worker_threads = 10)]
async fn main() -> Result<()> {
    // Create a new client builder.
    let app = App::new("windows-vpn@4.1.0")?;
    let env = Environment::new_atlas();

    // you will get drived about what is mandatory and what is not.
    // TL;DR: OS, randomness, executor, and persistence are mandatory
    let client = Client::builder_with_transport::<Hyper>(app, env)
        .with_operating_system(MyOperatingSystem::default(), rand::rng())
        .with_multi_thread_executor(TokioExecutor)
        .retry_policy(RetryPolicy::default())
        .without_persistence::<MySessionKey>()
        .build()?;

    let session = client.new_session_without_credentials(()).await?;

    let s1 = session.clone();
    let s2 = session.clone();
    let s3 = session.clone();

    let _ = tokio::join!(
        tokio::time::sleep(Duration::from_secs(30)),
        tokio::spawn(async move {
            let _ = s1.send(GET!("/tests/ping")).await;
        }),
        tokio::spawn(async move {
            let _ = s2.send(GET!("/tests/ping")).await;
        }),
        tokio::spawn(async move {
            let _ = s3.send(GET!("/tests/ping")).await;
        })
    );

    Ok(())
}
