//! This example demonstrates the basic login flow for a muon session.
#![recursion_limit = "256"]

use anyhow::{Result, bail};
use muon::auth::*;
use muon::error::ErrorKind;
use muon::store::*;
use muon::{App, Environment, GET};
use std::collections::HashMap;
use std::fs::File;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::mpsc::{Sender, channel};
use std::thread;
use tracing::*;
mod shared;
/// The types of errors that can come out of my [`FallibleFileStore`]
#[derive(Debug, Clone, Copy)]
enum FallibleFileStoreErrors {
    /// The disk is full
    Full,
    /// The file is not found
    NotFound,
    /// The file is corrupted/not interpretable
    Corrupted,
    /// Something else
    #[allow(dead_code)]
    Other(std::io::ErrorKind),
}

impl From<&std::io::Error> for FallibleFileStoreErrors {
    fn from(value: &std::io::Error) -> Self {
        match value.kind() {
            std::io::ErrorKind::NotFound => Self::NotFound,
            std::io::ErrorKind::WriteZero => Self::Full,
            kind => Self::Other(kind),
        }
    }
}

impl From<&serde_json::Error> for FallibleFileStoreErrors {
    fn from(_: &serde_json::Error) -> Self {
        info!("failed to read json");

        Self::Corrupted
    }
}

/// Something that can handle errors and do something with it
/// Here we use some mpsc sender to send the error to other threads that might
/// be itnerested (in practice it would be an Observer pattern probably)
#[derive(Debug, Default, Clone)]
struct StoreErrorHandler(Arc<Vec<Sender<FallibleFileStoreErrors>>>);

impl StoreErrorHandler {
    /// Deal with my concrete error type.
    /// Note: it is important that we can match the type to ensure everything is
    /// treated correctly.
    pub fn handle_error(&self, err: FallibleFileStoreErrors) {
        // e.g., write the error in a file
        let _ = tempfile::tempfile().and_then(|mut f| writeln!(f, "{:?}", err));
        // or send to other threads for asynchronous handling (e.g., display a modal)
        for notifiees in self.0.iter() {
            let _ = notifiees.send(err);
        }
    }
}

/// A store that persist in a file and that can fail
#[derive(Debug, Clone)]
struct FallibleFileStore {
    dir: Arc<tempfile::TempDir>,
    err_handler: StoreErrorHandler,
}

impl FallibleFileStore {
    /// Create a prod file storage, it mostly create the initial file with
    /// Auth::none in it
    pub async fn prod(err_handler: StoreErrorHandler) -> muon::Result<Self> {
        let dir = tempfile::tempdir().map_err(ErrorKind::storage)?;
        info!("Persistence storage in {:?}", dir.path());
        let path = dir.path().join("auth");
        let _ = File::options()
            .write(true)
            .truncate(true)
            .create(true)
            .open(path)
            .map_err(ErrorKind::storage)?;
        let store = Self {
            dir: dir.into(),
            err_handler,
        };
        Ok(store)
    }

    pub fn auth_file_path(&self) -> impl AsRef<Path> {
        self.dir.path().join("auth")
    }
}

impl FallibleFileStore {
    async fn read(path: PathBuf, err_handler: StoreErrorHandler) -> Auth {
        debug!("getting auth from {:?}", path);
        // Try to read the file, if an error occurs ask the handler to deal with it
        let Ok(auth_content) = tokio::fs::read(path)
            .await
            .inspect_err(|e| err_handler.handle_error(e.into()))
        else {
            // otherwise, return an error for IO issues
            err_handler.handle_error(FallibleFileStoreErrors::NotFound);
            return Auth::None;
        };
        debug!("auth {:?}", std::str::from_utf8(&auth_content));
        // try to interpret the file, if impossible, ask the error handler again... and
        // return an error
        let auth = serde_json::from_slice::<Auth>(&auth_content).unwrap_or_default();

        debug!("auth {:?}", auth);
        // all good return the session in the file
        auth
    }

    fn write(&self, auth: Auth) {
        // try to open the file in write mode... it musts exist though! otherwise return
        // that we can't and ask  the hadnler to deal with the error
        let Ok(mut file) = File::options()
            .write(true)
            .truncate(true)
            .open(self.auth_file_path())
            .inspect_err(|e| self.err_handler.handle_error(e.into()))
        else {
            self.err_handler
                .handle_error(FallibleFileStoreErrors::NotFound);
            return;
        };

        // This is not expected to fail but still in case we can ask the handler...
        let Ok(auth_str) = serde_json::to_string_pretty(&auth)
            .inspect_err(|e| self.err_handler.handle_error(e.into()))
        else {
            self.err_handler
                .handle_error(FallibleFileStoreErrors::Corrupted);
            return;
        };

        // write and in case of error propagate to handler...
        let _ = file
            .write_all(auth_str.as_bytes())
            .inspect_err(|e| self.err_handler.handle_error(e.into()));
    }
}

impl Store for FallibleFileStore {
    type Key = ();

    fn set_auth(&mut self, _key: Self::Key, auth: Auth) {
        self.write(auth)
    }

    fn remove_auth(&mut self, _key: &Self::Key) {
        let path = self.auth_file_path().as_ref().to_path_buf();
        let err = self.err_handler.clone();
        tokio::spawn(async move {
            tokio::fs::File::options()
                .write(true)
                .truncate(true)
                .open(path)
                .await
                .inspect_err(|e| err.handle_error(e.into()))
        });
    }

    fn get_all_auth(&self) -> HashMap<Self::Key, Auth> {
        let (s, r) = std::sync::mpsc::channel();

        let fut = Self::read(
            self.auth_file_path().as_ref().to_path_buf(),
            self.err_handler.clone(),
        );

        tokio::spawn(async move {
            let r = fut.await;
            let _ = s.send(r);
        });

        let mut map = HashMap::new();

        let auth = r.recv().unwrap_or_default();

        if !matches!(auth, Auth::None) {
            map.insert((), auth);
        }

        map
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let (gui_error_handler, error_handler_channel) = channel::<FallibleFileStoreErrors>();

    // this is our thread that will do the user output, it can be some GUI display,
    // CLI display, whatever... Herein, it is in a thread to mimick what would
    // happen in a real case: a thread doing the display
    let spawn = thread::spawn(move || {
        let err = error_handler_channel.recv().unwrap();

        match err {
            FallibleFileStoreErrors::Full => {
                error!("Persistent storage is full! Persistence is disabled")
            }
            FallibleFileStoreErrors::NotFound => {
                error!("Persistence storage file is absent! Persistence is disabled")
            }
            FallibleFileStoreErrors::Corrupted => {
                error!("Persistent storage is corrupted! Persistence is disabled")
            }
            FallibleFileStoreErrors::Other(_) => error!(
                "An unknown error happened on the persistence storage! Persistence is disabled"
            ),
        }
    });

    // First, define which app is using the client.
    let app = App::new("windows-vpn@4.1.0")?;

    // Set the user agent, if desired.
    let app = app.with_user_agent("Mozilla/5.0");

    let env = Environment::new_atlas();

    // Then, specify where the client will persist its session data. We'll use the
    // TestStore for this example; a real app would implement its own store.
    // A store is tied to a specific environment; a prod store holds prod tokens,
    // an atlas store holds atlas tokens, etc.
    let store_error_handler = StoreErrorHandler(vec![gui_error_handler].into());
    let store = FallibleFileStore::prod(store_error_handler).await?;

    // get a new connected session: this should work as the store is empty for
    // now... Finally, create the session. The client will be configured to
    // connect to the prod environment, and the session data will be stored in
    // the TestStore. Please check the auth-info-provider.rs example to see how
    // to pass a fingerprint to the muon client. The fingerprint is important in
    // combating fraud.

    // this is blocking => in case this is an issue spawn it in a task/separate
    // thread
    let client = new_client!(app.clone(), env.clone())
        .with_persistence(store.clone())
        .build()?;

    let session = client.new_session_without_credentials(()).await?;

    // Auth stuff is done via the auth flow.
    // To begin, call the auth method on the session.
    let auth = session.auth();

    // We can use the auth flow to login.
    let session = match auth.login("visionary", "a").await {
        // The session is now authenticated,
        // and the tokens are in the store.
        LoginFlow::Ok(session, _) => session,

        // The session needs 2FA to complete the login.
        // We can inspect the session to see what kind of 2FA is available.
        LoginFlow::TwoFactor(flow, _) => {
            if flow.has_totp() {
                flow.totp("123456").await?
            } else if flow.fido_details().is_some() {
                unimplemented!()
            } else {
                bail!("no 2FA available");
            }
        }
        LoginFlow::Failed { reason, .. } => return Err(reason.into()),
    };

    // Now we can use the session to make authenticated requests.
    // The session will automatically use the tokens in the store.
    // If the tokens are expired, the session will refresh them.
    info!(
        "authenticated call: {}",
        session.send(GET!("/core/v4/users")).await?.ok()?
    );
    drop(session);

    // get a new session: we shouldn't try to refresh any token as we are already
    // logged, we can already make auth calls
    let client = new_client!(app.clone(), env.clone())
        .with_persistence(store.clone())
        .build()?;

    let session = if let Ok(session) = client.new_session_without_credentials(()).await {
        session
    } else {
        client.get_session(()).await.unwrap()
    };

    info!(
        "with persistent storage: {}",
        session.send(GET!("/core/v4/users")).await?.ok()?
    );

    let _ = std::fs::remove_file(store.auth_file_path());
    // but we can still use the auth routes as we have an in memory store...
    info!(
        "without persistent storage: {}",
        session.send(GET!("/core/v4/users")).await?.ok()?
    );
    drop(session);
    // now that the persistent storage is gone, ...
    let session = new_client!(app.clone(), env.clone())
        .with_persistence(store.clone())
        .build()?
        .new_session_without_credentials(())
        .await?;
    // this will fail
    let err = session.send(GET!("/core/v4/users")).await?.ok();

    info!("without persistent storage: {}", err.unwrap_err().0);

    let _ = spawn.join();
    Ok(())
}
