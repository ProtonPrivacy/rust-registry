//! This example demonstrates the interplay between a client and an environment.
//! All sessions created from the client will use the environment specified when
//! creating the store that the client uses. NOTE: The client should be a
//! singleton! Don't create multiple clients in your application.

use anyhow::Result;
use muon::{App, Context, Environment, GET, Session};
use tracing::info;
mod shared;
#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let s1 = new_session("prod").await?;
    let s2 = new_session("atlas").await?;
    let s3 = new_session("atlas:leopold").await?;

    info!("{}", s1.send(GET!("/tests/ping")).await?);
    info!("{}", s2.send(GET!("/tests/ping")).await?);
    info!("{}", s3.send(GET!("/tests/ping")).await?);

    Ok(())
}

async fn new_session(env: &str) -> Result<Session<impl Context<SessionKey = ()>>> {
    info!("creating client for environment {env}");

    let app = App::new("windows-vpn@4.0.1")?;
    let env = match env {
        "prod" => Environment::new_prod(),
        "atlas" => Environment::new_atlas(),
        s => {
            if let Some(name) = s.strip_prefix("atlas:") {
                Environment::new_atlas_name(name)
            } else {
                unreachable!("invalid env: {s}")
            }
        }
    };

    let client = new_client!(app.clone(), env.clone())
        .without_persistence::<()>()
        .build()?;

    info!("created client with environment {:?}", client.env());

    Ok(client.new_session_without_credentials(()).await?)
}
