//! This example demonstrates creating a custom env with a local IP address.

use anyhow::Result;
use muon::app::AppVersion;
use muon::common::Server;
use muon::env::Env;
use muon::tls::certs::TlsCertDer;
use muon::tls::pins::TlsPinSet;
use muon::{App, Environment, GET};

mod shared;

/// Generate a new self-signed certificate and key pair, signed by the given CA.
pub fn generate_ca() -> Result<TlsCertDer> {
    use rcgen::*;
    let kp = KeyPair::generate()?;
    Ok(CertificateParams::default()
        .self_signed(&kp)?
        .der()
        .to_vec())
}

/// A custom environment.
struct MyCustomEnv;

/// Implement [`MyCustomEnv`] to specify the servers for the custom environment.
impl Env for MyCustomEnv {
    fn servers(&self, _: &AppVersion) -> Vec<Server> {
        vec!["https://proton.black/api".parse().unwrap()]
    }

    fn ar_pins(&self) -> Option<&TlsPinSet> {
        None
    }

    fn api_pins(&self) -> Option<&TlsPinSet> {
        None
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    // Create a new client targeting the custom environment.
    let app = App::new("windows-vpn@4.1.0")?.with_user_agent("Mozilla/5.0");
    let env = Environment::new_custom(MyCustomEnv);
    let client = new_client!(app.clone(), env)
        .dangerous()
        .with_additional_roots(generate_ca()) // if needed add an additional trusted root
        .without_persistence::<()>()
        .build()?;

    // Requests will now be sent to the custom environment.
    let session = client.new_session_without_credentials(()).await?;

    session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
