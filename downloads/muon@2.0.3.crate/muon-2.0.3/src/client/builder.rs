use crate::ProvideInformation;
use crate::app::App;
use crate::client::Client;
use crate::common::notification::{Event, SessionEventReceiver, SessionEventSenderFactory};
use crate::common::{
    Context, GenericContext, Pool, ProtonConnectTransport, ProtonRequest, ProtonResponse,
    RetryPolicy,
};
use crate::env::{Env as _, Environment};
use crate::fingerprint::NoInfo;
use crate::http::AsHeader;
use crate::rt::HasSleepCapabilities;
use crate::sessions::SessionKeyable;
use crate::store::{SharedVersionedStorage, Store, WithoutPersistence};
use std::sync::Arc;

#[cfg(target_family = "wasm")]
pub(crate) mod default_transport {
    use crate::cfg::if_cfg;
    use crate::client::builder::BaseBuilder;

    // The default builder on `wasm` targets uses `reqwest`.
    if_cfg! {#[cfg(feature = "transport-reqwest-wasm")], {
        pub use crate::transport::http::reqwest::builder::Reqwest;
        pub type DefaultBuilder = BaseBuilder<Reqwest>;
    } else {
        pub type DefaultBuilder = BaseBuilder<()>;
    }}
}

#[cfg(not(target_family = "wasm"))]
pub(crate) mod default_transport {
    use crate::cfg::if_cfg;
    use crate::client::builder::BaseBuilder;

    if_cfg! {#[cfg(feature = "transport-hyper")], {
        pub use crate::transport::http::hyper::builder::Hyper;
        pub type DefaultBuilder = BaseBuilder<Hyper>;
    } else if_cfg!{#[cfg(feature = "transport-reqwest-rustls")], {
        pub use crate::transport::http::reqwest::builder::Reqwest;
        pub type DefaultBuilder = BaseBuilder<Reqwest>;
    } else {
        pub type DefaultBuilder = BaseBuilder<()>;
    }}}
}

/// Conveniently defines a default transport for the current platform.
pub use default_transport::*;

pub(crate) mod internal {
    use crate::Result;
    use crate::app::App;
    use crate::common::ProtonConnectTransport;
    use crate::env::Environment;
    use std::sync::Arc;

    /// A type that can build an HTTP connector.
    ///
    /// This enables a common builder pattern for configuring clients with
    /// different underlying transports. This trait is sealed and cannot be
    /// implemented outside of this crate.
    pub trait BuildTransport<Req, Res> {
        type Connector: ProtonConnectTransport<Req, Res>;
        /// Builds an HTTP connector for the given `app` and `env`.
        fn build(self, app: &App, env: Arc<Environment>) -> Result<Self::Connector>;
    }
}

pub(crate) use internal::*;

#[derive(Debug)]
pub struct BaseBuilder<T = (), Storage = (), SessionKey = (), InfoProvider = NoInfo> {
    // --- Environment ---
    pub(crate) app: App,
    pub(crate) env: Environment,

    // --- Config ---
    pub(crate) retry_policy: RetryPolicy,

    pub(crate) storage: Storage,

    pub(crate) info_provider: InfoProvider,

    pub(crate) session_event_sender_factory: SessionEventSenderFactory<SessionKey>,

    pub(crate) default_headers: Vec<(String, String)>,

    // --- Transport ---
    pub(crate) inner: T,
}

impl BaseBuilder {
    /// A non-blocking variant of [`Client::builder`].
    pub fn builder<Transport: Default>(app: App, env: Environment) -> BaseBuilder<Transport> {
        BaseBuilder::new(app, env)
    }

    /// Get the [`DefaultBuilder`] auto-detected based on your platform.
    pub fn default_builder(app: App, env: Environment) -> DefaultBuilder {
        DefaultBuilder::new(app, env)
    }
}

impl<T> BaseBuilder<T> {
    fn new(app: App, env: Environment) -> Self
    where
        T: Default,
    {
        Self {
            app,
            env,

            retry_policy: RetryPolicy::default(),
            inner: T::default(),
            storage: (),
            info_provider: NoInfo,
            session_event_sender_factory: SessionEventSenderFactory::blackholed(),
            default_headers: Vec::with_capacity(0),
        }
    }
}

impl<Inner, Storage, SessionKey, InfoProvider>
    BaseBuilder<Inner, Storage, SessionKey, InfoProvider>
{
    pub(crate) fn transform_inner<NextInner>(
        self,
        transform: impl FnOnce(Inner) -> NextInner,
    ) -> BaseBuilder<NextInner, Storage, SessionKey, InfoProvider> {
        BaseBuilder::<NextInner, Storage, SessionKey, InfoProvider> {
            app: self.app,
            env: self.env,
            storage: self.storage,
            info_provider: self.info_provider,
            retry_policy: self.retry_policy,
            session_event_sender_factory: self.session_event_sender_factory,
            default_headers: self.default_headers,
            inner: (transform)(self.inner),
        }
    }
}

impl<T, S, I> BaseBuilder<T, S, I> {
    /// Sets the retry policy.
    pub fn retry_policy(mut self, policy: RetryPolicy) -> Self {
        self.retry_policy = policy;
        self
    }
}

impl<T: BuildTransport<ProtonRequest, ProtonResponse>, S, I, K> BaseBuilder<T, S, K, I> {
    /// Add an info provider to the client. Used by muon to ask for information.
    pub fn with_info_provider<InfoProvider: ProvideInformation>(
        self,
        info_provider: InfoProvider,
    ) -> BaseBuilder<T, S, K, InfoProvider> {
        BaseBuilder::<T, S, K, InfoProvider> {
            app: self.app,
            env: self.env,
            retry_policy: self.retry_policy,
            storage: self.storage,
            inner: self.inner,
            info_provider,
            session_event_sender_factory: self.session_event_sender_factory,
            default_headers: Vec::with_capacity(0),
        }
    }

    pub fn with_persistence<SessionKey: SessionKeyable, StoreImpl: Store<Key = SessionKey>>(
        self,
        storage: StoreImpl,
    ) -> BaseBuilder<T, StoreImpl, SessionKey, I> {
        BaseBuilder::<T, StoreImpl, SessionKey, I> {
            app: self.app,
            env: self.env,
            retry_policy: self.retry_policy,
            storage,
            inner: self.inner,
            info_provider: self.info_provider,
            session_event_sender_factory: SessionEventSenderFactory::blackholed(),
            default_headers: self.default_headers,
        }
    }

    pub fn without_persistence<SessionKey: SessionKeyable>(
        self,
    ) -> BaseBuilder<T, WithoutPersistence<SessionKey>, SessionKey, I> {
        BaseBuilder::<T, WithoutPersistence<SessionKey>, SessionKey, I> {
            app: self.app,
            env: self.env,
            retry_policy: self.retry_policy,
            storage: WithoutPersistence::default(),
            inner: self.inner,
            info_provider: self.info_provider,
            session_event_sender_factory: SessionEventSenderFactory::blackholed(),
            default_headers: self.default_headers,
        }
    }
}

impl<
    Transport: BuildTransport<ProtonRequest, ProtonResponse> + HasSleepCapabilities,
    Storage: Store,
    InfoProvider: ProvideInformation,
> BaseBuilder<Transport, Storage, Storage::Key, InfoProvider>
{
    /// Enable the reception of
    /// [`SessionEvent`](crate::common::notification::SessionEvent) through a
    /// [`SessionEventReceiver`].
    ///
    /// Use the `filter` callback to filter the events you want to be notified
    /// by.
    ///
    /// Important: you can only have a single [`SessionEventReceiver`]. Calling
    /// this function a second time will "kill" the previous receiver and
    /// further call to [`SessionEventReceiver::recv`] will return
    /// [`ReceiverDisconnected`](crate::common::notification::ReceiverDisconnected).
    ///
    /// Note: if you do not consume the events and when the limit (100) of
    /// events is reached, Muon will stop publishing the events and drop them
    /// instead.
    pub fn with_notification_receiver(
        mut self,
        filter: impl Fn(Event) -> Option<Event> + Send + 'static,
    ) -> (Self, SessionEventReceiver<Storage::Key>) {
        let (sender, receiver) = SessionEventSenderFactory::<Storage::Key>::new(filter);
        self.session_event_sender_factory = sender;
        (self, receiver)
    }

    /// Set default headers to every requests, even those originating from Muon.
    pub fn with_default_headers(mut self, headers: impl AsHeader) -> Self {
        self.default_headers = headers.as_header().into_iter().collect();
        self
    }

    // Builds the client.
    pub fn build(
        self,
    ) -> crate::Result<Client<GenericContext<Transport::Connector, Storage, InfoProvider>>> {
        let app = self.app;
        let env = Arc::new(self.env);

        let servers = env.servers(app.app_version());

        let connector = self.inner.build(&app, env.clone())?;
        let time = connector.get_sleep_capability().clone();

        Ok(Client {
            connector: connector.into(),
            env,
            versioned_auth_storage: SharedVersionedStorage::new(self.storage),
            info_provider: self.info_provider,
            servers: servers.into(),
            pool: Arc::new(Pool::default()),
            time,
            app,
            session_event_sender_factory: self.session_event_sender_factory,
            recorder: None,
            default_headers: self.default_headers.into(),
            retry_policy: self.retry_policy,
        })
    }
}

impl<
    Storage: Store,
    T: ProtonConnectTransport<ProtonRequest, ProtonResponse>,
    InformationProvider: ProvideInformation,
> Context for GenericContext<T, Storage, InformationProvider>
{
    type SessionKey = Storage::Key;
    type Storage = Storage;
    type TransportConnector = T;

    type InformationProvider = InformationProvider;
}
