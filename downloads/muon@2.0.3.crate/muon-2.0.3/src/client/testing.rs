use crate::{Client, Context, ProtonRequest};
use derive_more::Deref;

/// A wrapper around [Client] enabling test features
#[derive(Debug, Clone, Deref)]
pub struct TestClient<C: Context>(pub(crate) Client<C>);

impl<C: Context> TestClient<C> {
    /// Record every unique request that is being emitted (excluding 429/5xx
    /// retries).
    #[cfg(feature = "testing-recorder")]
    pub fn get_request_recorder(mut self) -> (Self, std::sync::mpsc::Receiver<ProtonRequest>) {
        let (s, r) = std::sync::mpsc::channel();
        self.0.recorder = Some(s);
        (self, r)
    }
}
