//! ## Client
//!
//! A client is the main component of `Muon`. It allows to communicate with the
//! Proton API by submitting Proton API queries and receiving Proton API
//! responses, using Sessions.
//!
//! The client:
//! - manages its own authentication, refreshing OAuth tokens if needed
//! - ensures that a query is sent by any possible means within user imposed
//!   constraints and fail only if all possible scenarios have been tried. It
//!   means that the client ensures that the query was retried and tried
//!   multiple path to reach the API if needed.
//! - the sessions are shareable and cheaply clonable. It means that the client
//!   handles concurrent access to its shared resources
//! - the client should be a singleton
//!
//! ## Create a client without persistent storage
//!
//! A client needs at least an [`App`](`crate::App`) and an
//! [`EnvId`](`crate::Environment`).
//!
//! ```
//! use muon::{App, Client, Environment, GET};
//! # use muon::tests::util::*;
//! # tokio_test::block_on(async {
//! let app = App::new("windows-vpn@4.1.0")?;
//! let client = new_builder()
//!     .without_persistence::<()>()
//!     .build()?;
//! let session = client.new_session_without_credentials(()).await?;
//! let res = session.send(GET!("/tests/ping")).await?;
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ## Create a client with persistent storage
//! To have a persistent storage, one should provide an implementation of
//! [`Store`](`crate::store::Store`) along with an [`App`](`crate::App`).
//!
//! ### Example
//! ```
//! use muon::{App, Client, Environment, GET};
//! # use muon::tests::util::*;
//! # tokio_test::block_on(async {
//! let app = App::new("windows-vpn@4.1.0")?;
//! let client = new_builder()
//!     .with_persistence(MyPersistenceStorage)
//!     .build()?;
//! let session = client.new_session_without_credentials(()).await?;
//! let res = session.send(GET!("/tests/ping")).await?;
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ## Session interface
//! A [`Session`](`crate::Session`) exposes the interface to:
//! - Authenticate: [`Session::auth`](`crate::Session::auth`) with the
//!   associated flows [`login::AuthFlow`](`crate::login::AuthFlow`). See
//!   [`login`](`crate::login`) for authentication details.
//!
//! ### Login example
//! ```
//! use muon::auth::LoginFlow;
//! use muon::client::PasswordMode;
//! use muon::{App, Client, GET, Environment};
//! use muon::{Fingerprint, ProvideInformation};
//! use serde_json::json;
//! use std::sync::Arc;
//! # use muon::tests::util::*;
//! # tokio_test::block_on(async {
//! # pub fn ask_user_for_mbp() -> String { "".to_owned() }
//! const USER: &str = "user";
//! const PASS: &str = "pass";
//!
//! // InfoProviderImpl is created by the client apps and passed to muon
//! // It takes care of requesting extra info from the clients on a need basis
//! // Including requesting the fingerprint as you can see in [`crate::ProvideInformation`]:
//!
//! // Create the client with an info_provider. The info_provider requests
//! // additional information from the client on demand, including the fingerprint.
//! // The fingerprint is needed, for example, when sending a call to create an unauthenticated session, or during login.
//! let app = App::new("android-mail@99.9.40.0-dev") .unwrap()
//!        .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)");
//! let env = Environment::new_atlas();
//! // build the client for your system and async context
//! let builder = Client::builder(app.clone(), env.clone())
//!        .with_operating_system(MyOperatingSystem::default(), rand::rng())
//!        .with_multi_thread_executor(TokioExecutor);
//! // finalize your client with persistence and (maybe) fingerprint data
//! let client = builder
//!     .without_persistence::<()>()
//!     .with_info_provider(InfoProviderImpl)
//!     .build()?;
//! // get a new unauth session if one does not exist yet
//! let session = client.new_session_without_credentials(()).await?;
//!
//! // perform the login flow
//! let (session, data) = match session.auth().login(USER, PASS).await {
//!     LoginFlow::Ok(authenticated_session, data) => {
//!         // show that we successfully logged in
//!         display_authenticated_user_info(&authenticated_session);
//!
//!         // continue with the authenticated_session and the associated data
//!         (authenticated_session, Some(data))
//!     },
//!
//!     // The user needs to provide 2FA
//!     LoginFlow::TwoFactor(session_needs_2fa, data) => {
//!         // show a modal asking for 2fa
//!         let twofa = ask_user_for_2fa();
//!
//!         // provide the 2fa, we either get an authenticated client or not.
//!         (session_needs_2fa.totp(twofa).await?, Some(data))
//!     },
//!
//!     LoginFlow::Failed {session, reason} => {
//!         // handle the error
//!         show_user_cant_login_modal(reason);
//!
//!         // continue with the unauthenticated session
//!         (session, None)
//!     },
//! };
//!
//! // ensure that we have authenticated data
//! let Some(data) = &data else {
//!     anyhow::bail!("authentication failed");
//! };
//!
//! // load the preferences of the user using its user-id
//! load_user_preferences(&data.user_id)?;
//!
//! // get the password for the user's PGP key (if needed)
//! let password = match data.password_mode {
//!     PasswordMode::One => PASS.to_owned(),
//!     PasswordMode::Two => ask_user_for_mbp(),
//! };
//!
//! // unlock the user's PGP key with the correct password
//! unlock_pgp_key(&session, &password);
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! - logout: [`Session::logout`](`crate::Session::logout`) can never fail as
//!   the local state must always be editable. If there is an error during the
//!   logout process, the application should behave as un-authenticated, and
//!   behave as-is until instructed otherwise by the user (i.e., login). In case
//!   of state inconsistency, the best thing to do is to behave normally (we do
//!   not guess the state) and the API will tell us what to do.
//!
//! ### Logout example
//! ```
//! use muon::{App, Client, Environment};
//! # use muon::tests::util::*;
//! # tokio_test::block_on(async {
//! let session = new_client::<()>()
//!     .new_session_without_credentials(())
//!     .await?;
//!
//! // skipping the login part ...
//!
//! session.logout().await;
//!
//! // the session is now un-authenticated
//!
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! - Fork: [`fork`](crate::Session::fork)
//!
//!   see [`from_fork`](crate::login) for details forking
//! and import forks.
//!
//! ### Fork a parent session example
//! ```
//! # use muon::tests::util::*;
//! # fn display_selector() -> String {"".to_owned()}
//! # fn handle_fork_failure(r: impl Into<muon::Error>) {}
//! # async fn send_selector_to_slave(s: String) {}
//! # tokio_test::block_on(async {
//! use muon::auth::ForkFlowResult;
//! use muon::{App, Client, GET};
//! let client = new_client::<()>();
//!
//! // skipping the login part ...
//! let session = match client
//!     .new_session_without_credentials(())
//!     .await?
//!     .fork("windows-vpn")
//!     .payload(b"hello world")
//!     .send()
//!     .await
//! {
//!     // Client has been forked successfully ...
//!     ForkFlowResult::Success(session, selector) => {
//!         // send the selector to the slave
//!         send_selector_to_slave(selector).await;
//!         // continue normally with the client
//!         session
//!     }
//!     ForkFlowResult::Failure { session, reason } => {
//!         // handle the fork failure; e.g., too many forks or recursive fork
//!         handle_fork_failure(reason);
//!         // continue with the un-forked session
//!         session
//!     }
//! };
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! - Request sending: [`Session::send`](`crate::Session::send`)
//!
//! ### Example
//! ```
//! #
//! # use muon::tests::util::*;
//! # tokio_test::block_on(async {
//! use muon::{App, Client, GET};
//! let session = new_client::<()>()
//!     .new_session_without_credentials(())
//!     .await?;
//! let res = session.send(GET!("/tests/ping")).await?;
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ## Session state storage
//! A [`Client`](`crate::Client`) contains an in-memory storage and a user
//! defined persistence storage following the
//! [`store::Store`](`crate::store::Store`) interface. Both storage are
//! infallible, the in-memory storage is the source of truth for the
//! [`Client`](`crate::Client`).
//!
//! In case the persistence storage can not be synchronized
//! with the local one (e.g., due to IO errors), the state IS considered
//! inconsistent and the application is considered on its own. The persistent
//! storage is assumed to handle his errors on its own (see
//! example-fallible-store).
//!
//! ### How to resync an de-synchronized store
//! ```
//! # use muon::tests::util::*;
//! # fn is_store_unsync() -> bool { true }
//! # fn display_modal_unsync() {}
//! # fn show_user_cant_login_modal<T>(_: T) {}
//! # fn display_authenticated_user_info<T>(_: &T) {}
//! # fn ask_user_for_2fa() -> String {"".to_owned() }
//! # tokio_test::block_on(async {
//! use std::thread;
//! use std::time::Duration;
//!
//! use muon::auth::LoginFlow;
//! use muon::{App, Client, GET};
//! let session = new_client::<()>()
//!     .new_session_without_credentials(())
//!     .await?;
//! let session = match session.auth().login("user", "password").await {
//!     LoginFlow::Ok(authenticated_session, _) => {
//!         // show that we successfully logged in
//!         display_authenticated_user_info(&authenticated_session);
//!         // continue with the authenticated session
//!         authenticated_session
//!     }
//!     // The user needs to provide 2FA
//!     LoginFlow::TwoFactor(session_needs_2fa, _) => {
//!         // show a modal asking for 2fa
//!         let twofa = ask_user_for_2fa();
//!         // provide the 2fa, we either get an authenticated session or not.
//!         session_needs_2fa.totp(twofa).await?
//!     }
//!     LoginFlow::Failed { session, reason } => {
//!         // handle the error
//!         show_user_cant_login_modal(reason);
//!         // continue with the unauthenticated session
//!         session
//!     }
//! };
//!
//! // check if we have received a signal that we have been unsync
//! if is_store_unsync() {
//!     // show a modal telling the user how to unblock the situation
//!     display_modal_unsync();
//!     // wait for the user to resolve
//!     thread::sleep(Duration::from_secs(5));
//!     // manually try to sync again
//!     session.client().sync_stores().await;
//! }
//!
//! # anyhow::Ok(())
//! # });
//! ```

use crate::app::App;
use crate::client::builder::{BaseBuilder, DefaultBuilder};
#[cfg(feature = "testing")]
use crate::client::testing::TestClient;
use crate::common::notification::{SessionEventSender, SessionEventSenderFactory};
use crate::common::{
    BoundSender, Context, ContextSender, ContextSleeper, Endpoint, MuonSender, Pool, PooledSender,
    ProtonConnectTransport, ProtonRequest, ProtonResponse, RetryPolicy, SendRequest as _, Server,
    StubContext, TryGet, WithTimeout as _,
};
use crate::env::Environment;
use crate::error::{ErrorKind, Result};
use crate::rt::{HasRandCapabilities, HasSleepCapabilities, SystemError};
use crate::sessions::{DuplicatedSessionCredentials, Session, SessionAlreadyExists};
use crate::store::SharedVersionedStorage;
use crate::util::TryRace as _;
use crate::{InternalError, SessionCredentials};
use proton_os_interface::time::{InstantFactory as _, Since as _};
use std::sync::Arc;
use std::time::Duration;
use thiserror::Error;
use tracing::{debug, error, info};

pub mod builder;

#[cfg(feature = "testing")]
pub mod testing;

// re-export of auth here
pub use crate::auth::{Auth, PasswordMode, Tokens};

/// Returned if no servers are provided to `HttpSender::sender_for`.
#[derive(Debug, Error)]
#[error("no servers available")]
pub(crate) struct NoServers;

/// A Proton API client.
///
/// The client is the primary interface for interacting with the Proton API.
/// Internally, the client is simply a wrapper around an HTTP sender and a
/// handle to an auth store.
///
/// The client is designed to be cheaply cloneable and shareable across threads.
pub struct Client<C: Context = StubContext> {
    app: App,
    env: Arc<Environment>,
    retry_policy: RetryPolicy,
    servers: Arc<Vec<Server>>,
    connector: Arc<C::TransportConnector>,
    time: ContextSleeper<C>,
    pool: Arc<Pool<ContextSender<C>>>,
    info_provider: C::InformationProvider,
    versioned_auth_storage: SharedVersionedStorage<C::Storage>,
    session_event_sender_factory: SessionEventSenderFactory<C::SessionKey>,
    recorder: Option<std::sync::mpsc::Sender<ProtonRequest>>,

    default_headers: Arc<Vec<(String, String)>>,
}

impl<C: Context + std::fmt::Debug> std::fmt::Debug for Client<C> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Client")
            .field("app", &self.app)
            .field("env", &self.env)
            .field("RetryPolicy", &self.retry_policy)
            .field("servers", &self.servers)
            .field("connector", &std::any::type_name_of_val(&self.connector))
            .field("pool", &self.pool)
            .field("info_provider", &self.info_provider)
            .field("versioned_auth_storage", &self.versioned_auth_storage)
            .finish()
    }
}

impl<C: Context> Clone for Client<C> {
    fn clone(&self) -> Self {
        Self {
            env: self.env.clone(),
            versioned_auth_storage: self.versioned_auth_storage.clone(),
            info_provider: self.info_provider.clone(),
            servers: self.servers.clone(),
            connector: self.connector.clone(),
            time: self.time.clone(),
            pool: self.pool.clone(),
            app: self.app.clone(),
            session_event_sender_factory: self.session_event_sender_factory.clone(),
            recorder: self.recorder.clone(),
            default_headers: self.default_headers.clone(),
            retry_policy: self.retry_policy.clone(),
        }
    }
}

impl Client {
    /// Creates a new client builder.
    pub fn builder(app: App, env: Environment) -> DefaultBuilder {
        BaseBuilder::default_builder(app, env)
    }

    /// Creates a new client builder.
    pub fn builder_with_transport<Transport: Default>(
        app: App,
        env: Environment,
    ) -> BaseBuilder<Transport> {
        BaseBuilder::builder(app, env)
    }
}

/// Manages the creation, retrieval, and storage of `Session` objects.
///
/// # Examples
///
/// A complete lifecycle: building a [`crate::Client`], adding a session,
/// retrieving it, and then removing it.
///
/// ```
/// use muon::{App, Client, Environment, SessionCredentials};
/// use serde_json::json;
///
/// # use muon::tests::util::*;
/// # #[tokio::main]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// #
/// // 1. Configure the application and build the client.
/// let app = App::new("windows-vpn@4.1.0")?;
/// let env = Environment::new_atlas();
/// let client = Client::builder(app, env)
///     .with_operating_system(MyOperatingSystem::default(), rand::rng())
///     .with_multi_thread_executor(TokioExecutor)
///     .without_persistence::<String>().build()?;
///
/// // 2. Add a new session for a user after they log in. This persists the session immediately.
/// let user_id = "user-id-123".to_string();
/// # let creds_json = json!({
/// #     "UserID": "test-user",
/// #     "UID": "test-uid",
/// #     "AccessToken": "test-access",
/// #     "RefreshToken": "test-refresh",
/// #     "Scopes": ["test-scope"],
/// # });
/// # let credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
/// let session = client
///     .new_session_with_credentials(user_id.clone(), credentials)
///     .await?;
/// println!(
///     "Successfully added session for user: {}",
///     session.session_key()
/// );
///
/// // 3. Retrieve all active sessions from storage.
/// for s in client.get_all_sessions().await {
///     println!("Found active session: {}", s.session_key());
/// }
///
/// // 4. Remove all sessions when needed.
/// client.remove_all_sessions().await;
/// println!("All sessions have been removed.");
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// # }
/// ```
/// # Important: Pitfalls of the new Session API
///
/// WARNING: The new Sessions API comes with a couple of caveats, that can lead
/// to:
///
/// 1. Mixing data between users: Sending data meant for `user_1` to `user_2`.
/// 2. Authenticated sessions becoming unauthenticated.
///
/// ## Mixing data between users
/// Session objects are clonable and reference session credentials by a session
/// key. Take the following scenario:
///
/// 1. There's a `session_user` object with the session key `user`, that the
///    codebase assumes is used to send data for `user_1`.
/// 2. The session credentials for the session key `user` are removed.
/// 3. New session credentials, that belong to `user_2`, are added for the
///    session key `user`.
/// 4. Now the `session_user` object will send data that is associated with
///    `user_2` not `user_1`.
/// 5. This can all happen on a separate thread with no notice of any changes,
///    and can lead to data mixing if not careful.
///
/// ## Authenticated sessions becoming unauthenticated
///
/// Assume there's a `Session` object called `session_one` that uses the session
/// key `user`. For the session key `user` there are authenticated session
/// credentials stored.
///
/// Assume that the session credentials for the session key `user` are removed.
/// Now, if the `Session` object `session_one` is used to send a request this is
/// what happens behind the scenes:
///
/// 1. Muon will check if there are session credentials saved for the session
///    key `user`
/// 2. Because there are no session credentials, Muon will ask the backend for
///    unauthenticated session credentials
/// 3. Muon will save the unauthenticated session credentials for the session
///    key `user`
/// 4. Muon will use the unauthenticated session credentials to send the
///    request.
///
/// If the request needs authenticated session credentials, it will return an
/// error.
///
/// ## Mitigation plan
///
/// The issue is that the credentials that a `Session` object references can
/// change without notice. This can lead to subtle, hard to find bugs.
///
/// To address this we need a way to stop `Session` objects whose credentials
/// have changed from performing actions.
///
/// We have a few ideas on how to do this, and a fix is coming soon.
impl<C: Context> Client<C> {
    /// Get the test client enabling tests features
    #[cfg(feature = "testing")]
    pub fn testing(self) -> TestClient<C> {
        TestClient(self)
    }

    /// Get the environment to which this client is bound.
    pub fn env(&self) -> &Environment {
        self.env.as_ref()
    }

    /// Returns a session only if its credentials have been persisted to
    /// storage.
    ///
    /// Note:
    ///
    /// A session created with
    /// [`new_session_without_credentials()`](Self::new_session_without_credentials)
    /// is not immediately persisted, because credentials are not yet available.
    /// It is only saved after the first API request is made using that session
    /// object. On the first API call we get unauth credentials, save them,
    /// and then send the request. Therefore, calling `get_session()`
    /// immediately after `new_session_without_credentials()` will return
    /// `None`.
    ///
    /// A session created with
    /// [`new_session_without_credentials()`](Self::new_session_without_credentials)
    /// is immediately persisted and calling `get_session()` will return
    /// Some(session).
    ///
    /// # Examples
    ///
    /// ```
    /// use muon::{App, Client, Environment};
    /// use serde_json::json;
    /// use muon::SessionCredentials;
    /// # use muon::tests::util::*;
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let client = new_client::<String>();
    ///
    /// let session_key = "test-user".to_string();
    ///
    /// // Initially, the session should not exist.
    /// assert!(client.get_session(session_key.clone()).await.is_none());
    ///
    /// // Create a session object. This does NOT save it to storage yet.
    /// let _session = client.new_session_without_credentials(session_key.clone()).await?;
    ///
    /// // The session has not been persisted, so `get_session` will still return `None`.
    /// // A request must be sent with the session object first.
    /// let retrieved_session = client.get_session(session_key.clone()).await;
    /// assert!(retrieved_session.is_none());
    ///
    /// # // Assume we have some SessionCredentials from the backend
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let session_credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    ///
    /// // Create a session object. It is persisted.
    /// let _session = client.new_session_with_credentials(session_key.clone(), session_credentials).await?;
    ///
    /// // The session is persisted, so `get_session` will still return `Some(session)`.
    /// let retrieved_session = client.get_session(session_key.clone()).await;
    /// assert!(retrieved_session.is_some());
    ///
    /// #
    /// # Ok(())
    /// # }
    /// ```
    pub async fn get_session(&self, session_key: C::SessionKey) -> Option<Session<C>> {
        let (stored_auth, _) = self
            .versioned_auth_storage
            .read()
            .await
            .get_auth(&session_key);
        match stored_auth {
            Auth::Internal { .. } | Auth::External { .. } | Auth::Anonymous { .. } => {
                Some(Session::new(self.clone(), session_key))
            }
            Auth::None => {
                info!("Session {:?} doesn't exist in `get_session`.", session_key);
                None
            }
        }
    }

    /// Retrieves all sessions with persisted credentials and constructs
    /// `Session` objects for them.
    ///
    /// Note that sessions created via `new_session_without_credentials` will
    /// not appear here until after their first API request has been made,
    /// because credentials are not available yet. Credentials for a session
    /// without credentials are requested from the backend during the first API
    /// call. Only after that will the session appear in the result of this
    /// function.
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, Environment, SessionCredentials};
    /// # use serde_json::json;
    /// # use muon::tests::util::*;
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let client = new_client::<String>();
    /// # // Assume we have session credentials from the backend
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    ///
    /// let session_name = "randomuser".to_string();
    ///
    /// let all_sessions = client.get_all_sessions().await;
    /// assert!(all_sessions.is_empty());
    ///
    /// // Use `new_session_with_credentials` to ensure the session is stored immediately.
    /// let _ = client
    ///     .new_session_with_credentials(session_name.clone(), credentials)
    ///     .await?;
    ///
    /// let all_sessions = client.get_all_sessions().await;
    /// assert_eq!(all_sessions.len(), 1);
    ///
    /// client.remove_all_sessions().await;
    ///
    /// let all_sessions = client.get_all_sessions().await;
    /// assert!(all_sessions.is_empty());
    ///
    /// # Ok(())
    /// # }
    /// ```
    pub async fn get_all_sessions(&self) -> Vec<Session<C>> {
        let sessions = self.versioned_auth_storage.read().await.get_all_auth();

        sessions
            .into_keys()
            .map(|session_key| Session::new(self.clone(), session_key))
            .collect()
    }

    /// Creates a new session, persists its credentials,
    /// and returns the corresponding [`Session`] object.
    ///
    /// This method immediately saves the session to the persistent store.
    ///
    /// # Arguments
    ///
    /// * `session_key` - The unique identifier for the new session.
    /// * `credentials` - The credentials obtained from a successful login.
    ///
    /// # Errors
    ///
    /// Returns an error if:
    /// 1. a session with the same `session_key` already exists
    /// 2. a session credential with the same `uid` as the `credentials` already
    ///    exists
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, Environment, SessionCredentials};
    /// # use serde_json::json;
    /// # use muon::tests::util::*;
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let client = new_client::<String>();
    /// // In a real application, credentials would be obtained from a login flow.
    /// // For this example, we'll use default credentials.
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let session_credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    /// let session_key = "new-user-456".to_string();
    ///
    /// let session = client.new_session_with_credentials(session_key.clone(),
    /// session_credentials).await?; println!("Created authenticated session
    /// for: {}", session.session_key());
    ///
    /// // Verify the session was created and can be retrieved immediately.
    /// let retrieved_session = client.get_session(session_key).await;
    /// assert!(retrieved_session.is_some());
    /// # Ok(())
    /// # }
    /// ```
    pub async fn new_session_with_credentials(
        &self,
        session_key: C::SessionKey,
        credentials: SessionCredentials,
    ) -> Result<Session<C>> {
        let stored_auths = self.versioned_auth_storage.read().await.get_all_auth();

        let (stored_auth, _) = stored_auths.get(&session_key).cloned().unwrap_or_default();

        // Using a match instead of if let to ensure all case are handled
        match stored_auth {
            Auth::Internal { .. } | Auth::External { .. } | Auth::Anonymous { .. } => {
                return Err(ErrorKind::auth(SessionAlreadyExists));
            }
            Auth::None => {}
        }
        // Remove all other anonymous sessions with the same session UID
        let uid = credentials.uid();

        for (stored_key, (stored_auth, _)) in &stored_auths {
            if let Some(stored_uid) = stored_auth.uid() {
                if stored_uid == uid && matches!(stored_auth, Auth::Anonymous { .. }) {
                    self.versioned_auth_storage
                        .write()
                        .await
                        .remove_auth(stored_key);
                } else if stored_uid == uid {
                    return Err(ErrorKind::auth(DuplicatedSessionCredentials));
                }
            }
        }
        // Add the session
        // The store will take care of checking if another session exists with the same
        // UID.
        let auth = credentials.as_auth();

        let _ = self
            .versioned_auth_storage
            .write()
            .await
            .set_auth(session_key.clone(), auth)
            .map_err(ErrorKind::auth)?;

        Ok(Session::new(self.clone(), session_key))
    }

    /// Creates a new **unauthenticated** session object in memory.
    ///
    /// This function creates a `Session` object but does not immediately
    /// persist credentials to storage, because they don't exist yet. The
    /// session credentials are only saved (and anonymous credentials are
    /// created on the backend) when the first API request is made using the
    /// returned `Session` object.
    ///
    /// Consequently, calling [`get_session()`](Self::get_session) or
    /// [`get_all_sessions()`](Self::get_all_sessions) immediately after
    /// this function will not find this new session, as it does not yet exist
    /// in the store.
    ///
    /// # Arguments
    ///
    /// * `session_key` - The unique identifier for the new unauthenticated
    ///   session.
    ///
    /// # Errors
    ///
    /// Returns an error if a fully authenticated session already exists with
    /// the same key.
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, Environment};
    /// # use muon::tests::util::*;
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let client = new_client::<String>();
    ///
    /// // Create a session object for a guest user.
    /// let session_key = "guest-user-54".to_string();
    /// let session = client.new_session_without_credentials(session_key.clone()).await?;
    /// println!("Created unauthenticated session object for guest: {}", session.session_key());
    ///
    /// // The session is not yet persisted to storage, so `get_session` will return `None`.
    /// let retrieved_session = client.get_session(session_key.clone()).await;
    /// assert!(retrieved_session.is_none());
    ///
    /// // After the first API request is made with the `session` object,
    /// // it will be stored, and `get_session` will be able to retrieve it.
    /// # Ok(())
    /// # }
    /// ```
    pub async fn new_session_without_credentials(
        &self,
        session_key: C::SessionKey,
    ) -> crate::error::Result<Session<C>> {
        // Checking if an authenticated session is already setup.
        let (stored_auth, _) = self
            .versioned_auth_storage
            .read()
            .await
            .get_auth(&session_key);
        debug!("stored: {stored_auth:?}");
        match stored_auth {
            Auth::Internal { .. } | Auth::External { .. } => {
                Err(ErrorKind::auth(SessionAlreadyExists))
            }
            Auth::None | Auth::Anonymous { .. } => Ok(Session::new(self.clone(), session_key)),
        }
    }

    /// Removes **all** sessions from the persistent store.
    ///
    /// This is a destructive operation that clears all session credentials.
    /// This can be useful for cleanup, resetting state, or in tests.
    ///
    /// WARNING: Any Session objects that are left in memory after calling
    /// `remove_all_sessions` will become unauthenticated Sessions.
    /// This means that if you use them after calling `remove_all_sessions`,
    /// Muon will request unauthenticated credentials from the backend
    /// on the first api call and use those to send the first and all subsequent
    /// requests. The session key of the Session oject will be used to save
    /// the unauthenticated credentials, so if you want to provide new
    /// credentials for the same key after that, an error will be thrown by
    /// `new_session_with_credentials`, because the session key already has
    /// session credentials associated with it.
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, Environment, SessionCredentials};
    /// # use serde_json::json;
    /// # use muon::tests::util::*;
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let client = new_client::<String>();
    ///
    /// # let dummy_credentials = |x: usize| {
    /// #     let creds_json = json!({
    /// #         "UserID": "test-user",
    /// #         "UID": x.to_string(),
    /// #         "AccessToken": "test-access",
    /// #         "RefreshToken": "test-refresh",
    /// #         "Scopes": ["test-scope"],
    /// #     });
    /// #     serde_json::from_value(creds_json).unwrap()
    /// # };
    /// #
    /// // Create a couple of sessions that are immediately persisted.
    /// client.new_session_with_credentials("user1".to_string(), dummy_credentials(1)).await?;
    /// client.new_session_with_credentials("user2".to_string(), dummy_credentials(2)).await?;
    ///
    /// // Adding another session with different credentials
    /// client.new_session_with_credentials("user3".to_string(), dummy_credentials(3)).await?;
    ///
    /// assert_eq!(client.get_all_sessions().await.len(), 3);
    ///
    /// // This will remove all stored sessions.
    /// client.remove_all_sessions().await;
    ///
    /// println!("All sessions have been removed.");
    ///
    /// // Verifying that no sessions remain.
    /// let remaining_sessions = client.get_all_sessions().await;
    /// assert!(remaining_sessions.is_empty());
    /// # Ok(())
    /// # }
    /// ```
    pub async fn remove_all_sessions(&self) {
        self.versioned_auth_storage.write().await.remove_all_auth()
    }

    /// Manually try to synchronize the local store with the persistent
    /// storage(s).
    ///
    /// It will push the local state of the client held in the in-memory storage
    /// into the registered persistent storage(s).
    ///
    /// The sync may or may not fail, but it is the responsibility of the
    /// user-defined [`Store`](crate::store::Store) to handle them.
    /// ```
    /// # use std::time::Duration;
    /// # use std::thread;
    /// # use muon::tests::util::*;
    /// # fn is_store_unsync() -> bool { true }
    /// # fn display_modal_unsync() {}
    /// # tokio_test::block_on(async {
    /// # use muon::{App, Client, http::GET};
    /// let app = App::new("windows-vpn@4.1.0")?;
    /// let app = app.with_user_agent("Mozilla/5.0");
    /// let client = new_client::<()>();
    /// let session = client.new_session_without_credentials(()).await?;
    /// // ... skip the login part ...
    /// session.clone().logout().await;
    /// // storage discrepancy detected ... wait until resolved...
    /// if is_store_unsync() {
    ///     thread::sleep(Duration::from_millis(100));
    ///     // try to re-sync manually
    ///     client.sync_stores().await;
    /// }
    /// # anyhow::Ok(())
    /// # });
    /// ```
    pub async fn sync_stores(&self) {
        self.versioned_auth_storage.write().await.sync_stores();
    }
}

impl<C: Context> Client<C> {
    pub(crate) fn default_retry_policy(&self) -> RetryPolicy {
        self.retry_policy
    }

    pub(crate) fn default_headers(&self) -> &Vec<(String, String)> {
        &self.default_headers
    }

    pub(crate) fn get_prng(&self) -> <C::TransportConnector as HasRandCapabilities>::Rng {
        self.connector.get_prng()
    }

    pub(crate) fn sleeper(&self) -> &<C::TransportConnector as HasSleepCapabilities>::Sleeper {
        &self.time
    }

    pub(crate) fn app(&self) -> &App {
        &self.app
    }

    #[cfg(feature = "testing-recorder")]
    pub(crate) fn get_recorder(&self) -> Option<std::sync::mpsc::Sender<ProtonRequest>> {
        self.recorder.clone()
    }

    pub(crate) fn session_event_sender(
        &self,
        session_key: C::SessionKey,
    ) -> SessionEventSender<C::SessionKey> {
        self.session_event_sender_factory
            .new_session_event_sender(session_key)
    }

    pub(crate) fn information_provider(&self) -> &C::InformationProvider {
        &self.info_provider
    }

    pub(crate) fn storage(&self) -> &SharedVersionedStorage<C::Storage> {
        &self.versioned_auth_storage
    }

    /// The core of the request sending logic.
    ///
    /// First, attempt to connect, then send the request, deduce the time taken
    /// by these operations on the allowed request time.
    ///
    /// Upon irrecoverable error, bail out to the user. Otherwise, retry until
    /// the timeout expires.
    pub(crate) async fn send(
        &self,
        req: ProtonRequest,
        session_key: &C::SessionKey,
    ) -> Result<ProtonResponse> {
        req.audit();

        let mut remaining_time = *req.get_allowed_time();
        let idempotency = req.is_indempotent();
        loop {
            // if there is no more time for the request, then bail out
            if remaining_time.is_zero() {
                return Err(ErrorKind::send(SystemError::Timeout));
            }

            // attempt to connect by whatever means, and compute the time taken
            let sender = self.connect(&mut remaining_time).await?;

            // send the request and compute the time taken
            let res = self
                .send_with(&sender, session_key, &req, &mut remaining_time)
                .await;

            finalize_repool!(res, sender, idempotency)
        }
    }
    /// The core of the request sending logic.
    ///
    /// First, attempt to connect, then send the request, deduce the time taken
    /// by these operations on the allowed request time.
    ///
    /// Upon irrecoverable error, bail out to the user. Otherwise, retry until
    /// the timeout expires.
    pub(crate) async fn force_refresh(&self, session_key: &C::SessionKey) -> Result<()> {
        let mut remaining_time = Duration::from_secs(30);
        let idempotency = false;
        loop {
            // if there is no more time for the request, then bail out
            if remaining_time.is_zero() {
                return Err(ErrorKind::send(SystemError::Timeout));
            }

            // attempt to connect by whatever means, and compute the time taken
            let pooled_sender = self.connect(&mut remaining_time).await?;

            let sender = MuonSender::new(&pooled_sender, self, session_key);

            let res = sender
                .force_refresh()
                .with_timeout(self.sleeper(), remaining_time)
                .await
                .map_err(InternalError::send);
            finalize_repool!(res, pooled_sender, idempotency)
        }
    }
}

impl<C: Context> Client<C> {
    /// Find an available sender, by trying first the direct connection to the
    /// API and then the alternative routes.
    async fn find_available_sender(&self) -> Result<PooledSender<ContextSender<C>>> {
        let (direct, indirect): (Vec<Server>, Vec<Server>) =
            self.servers.iter().cloned().partition(Server::is_direct);

        Ok(match self.sender_for(&direct).await {
            Ok(sender) => sender,
            Err(_) => self.sender_for(&indirect).await?,
        })
    }

    /// Try to find a sender for all the servers.
    ///
    /// If a sender is already available, use it.
    ///
    /// Otherwise, attempt to connect in parallel to the available addresses
    /// (with a single retry per IP)
    async fn sender_for(&self, servers: &[Server]) -> Result<PooledSender<ContextSender<C>>> {
        if servers.is_empty() {
            return Err(ErrorKind::send(NoServers));
        }

        {
            let mut pool = self.pool.lock().await;

            for server in servers {
                pool = match pool.get(&server.endpoint) {
                    TryGet::Some(sender) => return Ok(sender),
                    TryGet::None(pool) => pool,
                };
            }
        }

        // Will process all connects in parallel and take the fastest one.

        match servers
            .iter()
            .map(|server| Box::pin(self.connect_to(server)))
            .try_race()
            .await
        {
            Ok((endpoint, sender)) => Ok(self.pool.lock().await.insert(&endpoint, sender)),
            Err(err) => Err(ErrorKind::connect(err)),
        }
    }

    /// Attempt to connect to the destination server.
    ///
    /// Retry a second time if the first attempt fails
    async fn connect_to(
        &self,
        server: &Server,
    ) -> Result<(Endpoint, BoundSender<ContextSender<C>>), InternalError> {
        let mut max_connect_attempts = 2;
        assert!(max_connect_attempts > 0);
        loop {
            max_connect_attempts -= 1;
            info!("attempting to connect to {server:?}");
            let error = ProtonConnectTransport::connect(self.connector.as_ref(), server).await;
            match error {
                Ok(sender) => return Ok((server.endpoint.clone(), sender)),
                Err(err) if max_connect_attempts > 0 && err.is_retryable() => {
                    error!("error while connecting to {server:?}: {err}, retrying")
                }
                Err(err) => return Err(err),
            }
        }
    }

    async fn connect(
        &self,
        remaining_time: &mut Duration,
    ) -> Result<PooledSender<ContextSender<C>>> {
        info!("attempting connection, time left {remaining_time:?}");
        let start_connect = self.connector.get_sleep_capability().now();
        let sender = self
            .find_available_sender()
            .with_timeout(self.connector.get_sleep_capability(), *remaining_time)
            .await
            .map_err(ErrorKind::connect)??;
        let end_connect = self.connector.get_sleep_capability().now();
        let connect_duration = end_connect.duration_since(start_connect);
        *remaining_time = remaining_time.saturating_sub(connect_duration);
        Ok(sender)
    }

    async fn send_with(
        &self,
        pooled_sender: &PooledSender<ContextSender<C>>,
        session_key: &C::SessionKey,
        req: &ProtonRequest,
        remaining_time: &mut Duration,
    ) -> Result<Result<ProtonResponse, InternalError>, InternalError> {
        info!("sending request, time left {remaining_time:?}");
        let start_send = self.connector.get_sleep_capability().now();

        let sender = MuonSender::new(pooled_sender, self, session_key);

        let res = sender
            .send(req.to_owned())
            .with_timeout(self.connector.get_sleep_capability(), *remaining_time)
            .await
            .map_err(InternalError::send);
        let end_send = self.connector.get_sleep_capability().now();
        let send_duration = end_send.duration_since(start_send);

        debug!("send took {send_duration:?}");
        // deduce the time from the remaining time
        *remaining_time = remaining_time.saturating_sub(send_duration);

        res
    }
}

macro_rules! finalize_repool {
    ($res: expr, $sender: expr, $idempontency: expr) => {
        match $res {
        // we succeed, repool the sender and return the result
        Ok(Ok(resp)) => {
            $sender.repool().await;
            return Ok(resp);
        }
        // we failed, but the error is something we can retry from muon, hence, unpool the
        // sender (that failed), and retry
        Ok(Err(err)) if err.is_retryable() && $idempontency => {
            error!(%err, "retrying idempotent request now");
            $sender.unpool().await;
        }
        // we failed and the error is not retryable from muon, hence, unpool, and return the
        // error
        Err(err) | Ok(Err(err)) => {
            $sender.unpool().await;
            return Err(ErrorKind::send(err));
        }
    }
    };
}

use finalize_repool;
