use crate::auth::{Auth, Scopes, Tokens};
use crate::rest::auth::v4::RawSessionCredentials;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct SessionCredentials(pub(crate) RawSessionCredentials);

impl From<SessionCredentials> for Tokens {
    fn from(val: SessionCredentials) -> Self {
        Tokens::access(val.0.access_token, val.0.refresh_token, val.0.scopes)
    }
}

impl TryFrom<Auth> for SessionCredentials {
    type Error = ();

    fn try_from(value: Auth) -> Result<Self, Self::Error> {
        match value {
            Auth::Internal { user_id, uid, tok } => Ok(SessionCredentials(RawSessionCredentials {
                user_id: Some(user_id),
                uid,
                access_token: tok.acc_tok().ok_or(())?.to_string(),
                refresh_token: tok.ref_tok().to_string(),
                scopes: tok.into_scopes().unwrap_or_default(),
            })),
            Auth::Anonymous { uid, tok } => Ok(SessionCredentials(RawSessionCredentials {
                user_id: None,
                uid,
                access_token: tok.acc_tok().ok_or(())?.to_string(),
                refresh_token: tok.ref_tok().to_string(),
                scopes: tok.into_scopes().unwrap_or_default(),
            })),
            Auth::External { .. } => Err(()),
            Auth::None => Err(()),
        }
    }
}

impl SessionCredentials {
    /// Get the UID of the auth.
    pub fn uid(&self) -> &str {
        &self.0.uid
    }

    /// Get the ID of the user that logged in, if any.
    pub fn user_id(&self) -> Option<&str> {
        self.0.user_id.as_deref()
    }

    /// Get the access token of the auth.
    pub fn access_token(&self) -> &str {
        &self.0.access_token
    }

    /// Get the refresh token of the auth.
    pub fn refresh_token(&self) -> &str {
        &self.0.refresh_token
    }

    /// Get the scopes of the auth.
    pub fn scopes(&self) -> &Scopes {
        &self.0.scopes
    }

    /// Extract the scopes of the auth
    pub fn into_scopes(self) -> Scopes {
        self.0.scopes
    }

    /// Creates a [`Tokens`] instance from the session credentials.
    ///
    /// This method extracts the access token, refresh token, and scopes from
    /// the current [`SessionCredentials`] to construct a new [`Tokens`]
    /// object. It is useful when only the token-related information is
    /// required.
    ///
    /// # Returns
    ///
    /// A new [`Tokens`] instance containing the session's authentication tokens
    /// and scopes.
    ///
    /// # Examples
    ///
    /// ```
    /// use muon::auth::Scopes;
    /// use muon::SessionCredentials;
    /// use serde_json::json;
    ///
    /// // This is the JSON response from the API.
    /// // DO NOT USE THIS IN YOUR CODE.
    /// let creds = json!({
    ///     "UserID": "user-123",
    ///     "UID": "session-uid-456",
    ///     "AccessToken": "access_token_str",
    ///     "RefreshToken": "refresh_token_str",
    ///     "Scopes": ["read", "write"],
    /// });
    ///
    /// # let creds: SessionCredentials = serde_json::from_value(creds).unwrap();
    ///
    /// let tokens = creds.as_tokens();
    ///
    /// assert_eq!(tokens.ref_tok(), "refresh_token_str");
    /// assert_eq!(tokens.acc_tok(), Some("access_token_str"));
    /// assert_eq!(tokens.scopes(), Some(&Scopes::from(vec!["read".to_string(), "write".to_string()])));
    /// ```
    #[must_use]
    pub fn as_tokens(&self) -> Tokens {
        Tokens::access(
            self.access_token(),
            self.refresh_token(),
            self.scopes().clone(),
        )
    }

    /// Converts the session credentials into a generic [`Auth`] representation.
    ///
    /// This method creates an [`Auth`] enum variant based on the presence of a
    /// `user_id`.
    ///
    /// - If `user_id` is `Some`, it creates an `Auth::internal` variant,
    ///   representing a fully authenticated user session.
    /// - If `user_id` is `None`, it creates an `Auth::anonymous` variant,
    ///   representing a session for a user who is not logged in.
    ///
    /// This serves as a convenient way to transform session-specific
    /// credentials into the application's general authentication model.
    ///
    /// # Returns
    ///
    /// An [`Auth`] instance, representing either an internal (authenticated) or
    /// an anonymous user.
    ///
    /// # Examples
    ///
    /// ## Authenticated User
    ///
    /// When `user_id` is present.
    /// ```
    /// use muon::SessionCredentials;
    /// use serde_json::json;
    ///
    /// // This is the JSON response from the API.
    /// // DO NOT USE THIS IN YOUR CODE.
    /// let creds = json!({
    ///     "UserID": "user-123",
    ///     "UID": "session-uid-456",
    ///     "AccessToken": "access_token_str",
    ///     "RefreshToken": "refresh_token_str",
    ///     "Scopes": ["read"],
    /// });
    ///
    /// # let creds: SessionCredentials = serde_json::from_value(creds).unwrap();
    ///
    /// let auth = creds.as_auth();
    /// assert_eq!(auth.user_id(), Some("user-123"));
    /// ```
    ///
    /// ## Anonymous User
    ///
    /// When `user_id` is `None`.
    /// ```
    /// use muon::SessionCredentials;
    /// use serde_json::json;
    ///
    /// // This is the JSON response from the API.
    /// // DO NOT USE THIS IN YOUR CODE.
    /// let creds = json!({
    ///     "UserID": null,
    ///     "UID": "anonymous-session-789",
    ///     "AccessToken": "anon_access_token",
    ///     "RefreshToken": "anon_refresh_token",
    ///     "Scopes": ["read_public"],
    /// });
    ///
    /// # let creds: SessionCredentials = serde_json::from_value(creds).unwrap();
    ///
    /// let auth = creds.as_auth();
    /// assert_eq!(auth.user_id(), None);
    /// ```
    pub fn as_auth(&self) -> Auth {
        if let Some(user_id) = self.user_id() {
            Auth::internal(user_id, self.uid(), self.as_tokens())
        } else {
            Auth::anonymous(self.uid(), self.as_tokens())
        }
    }
}
