use crate::client::builder::{BaseBuilder, BuildTransport};
use crate::rt::*;
use crate::store::Store;
use crate::{
    Client, Context, Environment, Error, Fingerprint, ProtonRequest, ProtonResponse,
    ProvideInformation, SessionKeyable, json,
};
use async_compat::Compat;
use std::collections::HashMap;
use std::pin::Pin;
use std::time::Duration;
use tracing::{error, info};

/// todo
pub fn show_user_cant_login_modal<T>(_: T) {}

/// todo
pub fn display_authenticated_user_info<T>(_: &T) {}

/// todo
pub fn load_user_preferences(_: &str) -> Result<(), Error> {
    Ok(())
}

/// todo
pub fn ask_user_for_2fa() -> String {
    "".to_owned()
}

/// todo
pub fn ask_user_for_mbp() -> String {
    "".to_owned()
}

/// todo
pub fn unlock_pgp_key<T>(_: &T, _: &str) {}

#[derive(Debug, Clone)]
pub struct InfoProviderImpl;

impl ProvideInformation for InfoProviderImpl {
    fn fingerprint(&self) -> Option<Fingerprint> {
        let fingerprint = json::json!({
            "mail-android-99.9.40.0-challenge":{
                "appLang":"en",
                "deviceName":"TestDevice",
                "frame":{
                    "name":"username"
                },
                "isDarkmodeOn":false,
                "isJailbreak":false,
                "keyboards":[

                ],
                "preferredContentSize":"2.0",
                "regionCode":"CH",
                "storageCapacity":"63.8",
                "timezone":"Europe/Zurich",
                "timezoneOffset":"0",
                "v":"2.0.0"
            }
        })
        .into();
        Some(fingerprint)
    }
}

#[derive(Debug)]
pub struct MyPersistenceStorage;

impl Store for MyPersistenceStorage {
    type Key = ();

    fn set_auth(&mut self, key: Self::Key, auth: crate::auth::Auth) {}

    fn remove_auth(&mut self, key: &Self::Key) {}

    fn get_all_auth(&self) -> std::collections::HashMap<Self::Key, crate::auth::Auth> {
        HashMap::default()
    }
}

pub fn new_client<Key: SessionKeyable + 'static>() -> Client<impl Context<SessionKey = Key>> {
    new_builder().without_persistence::<Key>().build().unwrap()
}

pub fn new_builder()
-> BaseBuilder<impl BuildTransport<ProtonRequest, ProtonResponse> + HasSleepCapabilities> {
    let app = crate::App::new("android-mail@99.9.40.0-dev")
        .unwrap()
        .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)");
    let env = Environment::new_atlas();
    let builder = Client::builder(app.clone(), env.clone())
        .with_operating_system(
            crate::tests::util::MyOperatingSystem::default(),
            rand::rng(),
        )
        .with_multi_thread_executor(crate::tests::util::TokioExecutor);
    #[cfg(ci)]
    let builder = builder.proxy(crate::common::EnvProxy::all("http_proxy").into());
    builder
}

#[derive(Debug, Clone)]
pub struct TokioExecutor;

impl futures::task::Spawn for TokioExecutor {
    fn spawn_obj(
        &self,
        future: futures::task::FutureObj<'static, ()>,
    ) -> Result<(), futures::task::SpawnError> {
        let _ = tokio::spawn(future);
        Ok(())
    }
}

#[derive(Debug, Clone)]
pub struct TokioTime {
    at_start: std::time::Instant,
}

impl Default for TokioTime {
    fn default() -> Self {
        Self {
            at_start: std::time::Instant::now(),
        }
    }
}

impl Sleep for TokioTime {
    type Sleep<'a>
        = Pin<Box<dyn Future<Output = ()> + Send + Sync + 'a>>
    where
        Self: 'a;

    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'static> {
        Box::pin(tokio::time::sleep(duration))
    }
}

impl InstantFactory for TokioTime {
    type Instant = MuonInstant;

    fn now(&self) -> Self::Instant {
        MuonInstant::from_duration(std::time::Instant::now() - self.at_start)
    }
}
unsafe impl Monotonic for TokioTime {}

impl SystemTimeFactory for TokioTime {
    type SystemTime = MuonSystemTime;

    fn now(&self) -> Self::SystemTime {
        MuonSystemTime::since_unix_epoch(
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .expect("failed to get time"),
        )
    }
}

#[derive(Debug, Clone, Default)]
pub struct TokioDialer;

impl TcpConnect for TokioDialer {
    type Socket = Compat<tokio::net::TcpStream>;

    async fn tcp_connect(&self, addr: std::net::SocketAddr) -> Result<Self::Socket, Self::Err> {
        tokio::net::TcpStream::connect(addr)
            .await
            .map(Compat::new)
            .inspect_err(|err| error!(%err, "failed to connect to {addr}"))
    }

    type Err = std::io::Error;
}

#[derive(Debug, Clone, Default)]
pub struct TokioResolver;

impl Resolve for TokioResolver {
    async fn resolve(&self, host: &str) -> crate::Result<Vec<std::net::IpAddr>, Self::Err> {
        let addr = tokio::net::lookup_host(format!("{host}:0"))
            .await
            .inspect_err(|err| error!(%err, "failed to resolve {host}"))?;
        Ok(addr.map(|addr| addr.ip()).collect::<Vec<_>>())
    }

    type Err = std::io::Error;
}

#[derive(Debug, Clone)]
pub struct MyOperatingSystem<Time = TokioTime, Dialer = TokioDialer, Resolver = TokioResolver> {
    pub time: Time,
    pub dialer: Dialer,
    pub resolver: Resolver,
}

impl Default for MyOperatingSystem {
    fn default() -> Self {
        Self {
            time: Default::default(),
            dialer: Default::default(),
            resolver: Default::default(),
        }
    }
}
impl MyOperatingSystem {
    pub fn new<T, D, R>(time: T, dialer: D, resolver: R) -> MyOperatingSystem<T, D, R> {
        MyOperatingSystem::<T, D, R> {
            time,
            dialer,
            resolver,
        }
    }
}

impl<
    T: TimeCapabilities + std::fmt::Debug + Send + Sync,
    D: TcpConnect + std::fmt::Debug + Send + Sync,
    R: Resolve + std::fmt::Debug + Send + Sync,
> OperatingSystem for MyOperatingSystem<T, D, R>
{
    type Resolver = R;
    type TcpConnector = D;
    type Time = T;

    fn get_time_capabilities(&self) -> &Self::Time {
        &self.time
    }

    fn get_tcp_connector(&self) -> &Self::TcpConnector {
        &self.dialer
    }

    fn get_resolver(&self) -> &Self::Resolver {
        &self.resolver
    }
}

pub mod local {
    use super::*;
    use crate::rt::MuonInstant;
    use std::cmp::Reverse;
    use std::collections::{BinaryHeap, HashMap};
    use std::pin::Pin;
    use std::sync::{Arc, Mutex, RwLock, Weak};
    use std::task::{Context, Poll, Waker};

    #[derive(Debug)]
    struct SleepInner {
        deadline: MuonInstant,
        done: bool,
        waker: Option<Waker>,
    }

    impl SleepInner {
        fn new(deadline: MuonInstant) -> Self {
            Self {
                deadline,
                done: false,
                waker: None,
            }
        }
    }

    /// A future that completes once its deadline has passed according to the
    /// associated `TimerManager`.
    #[derive(Debug, Clone)]
    pub struct Sleep {
        inner: Arc<Mutex<SleepInner>>,
    }

    impl Sleep {
        fn new(inner: Arc<Mutex<SleepInner>>) -> Self {
            Self { inner }
        }
    }

    impl hyper::rt::Sleep for Sleep {}

    impl Future for Sleep {
        type Output = ();

        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            let mut inner = self.inner.lock().unwrap();

            if inner.done {
                return Poll::Ready(());
            }

            // Store/refresh the waker; the manager will use it to wake us.
            let replace_waker = match &inner.waker {
                Some(w) => !w.will_wake(cx.waker()),
                None => true,
            };
            if replace_waker {
                inner.waker = Some(cx.waker().clone());
            }

            Poll::Pending
        }
    }

    #[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
    struct TimerId(u64);

    #[derive(Debug, Default, Clone)]
    pub struct TimerManager(Arc<RwLock<TimerManagerInner>>);

    impl TimerManager {
        pub(crate) fn advance_to_now(&self) {
            let mut this = self.0.write().unwrap();
            let now = std::time::Instant::now() - this.at_start;
            // eprintln!("acquire write");
            this.advance_to(MuonInstant::from_duration(now));
            // eprintln!("released write");
        }
    }

    impl crate::rt::Sleep for TimerManager {
        type Sleep<'a>
            = Pin<Box<dyn Future<Output = ()> + Send + Sync + 'a>>
        where
            Self: 'a;

        fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'static> {
            Box::pin(tokio::time::sleep(duration))
        }
    }

    /// Local timer manager.
    #[derive(Debug)]
    pub struct TimerManagerInner {
        at_start: std::time::Instant,
        now: MuonInstant,
        next_id: u64,
        heap: BinaryHeap<Reverse<(MuonInstant, TimerId)>>,
        registry: HashMap<TimerId, Weak<Mutex<SleepInner>>>,
    }

    impl Default for TimerManagerInner {
        fn default() -> Self {
            let at_start = std::time::Instant::now();
            Self {
                at_start,
                now: MuonInstant::from_duration(std::time::Instant::now() - at_start),
                next_id: 0,
                heap: BinaryHeap::new(),
                registry: HashMap::new(),
            }
        }
    }

    impl TimerManagerInner {
        pub fn new(start: MuonInstant) -> Self {
            Self {
                now: start,
                ..Default::default()
            }
        }

        pub fn now(&self) -> MuonInstant {
            self.now
        }

        fn _sleep(&mut self, duration: Duration) -> Sleep {
            let id = self.alloc_id();
            let deadline = self.now.saturating_add_duration(duration);

            let inner = Arc::new(Mutex::new(SleepInner::new(deadline)));
            self.registry.insert(id, Arc::downgrade(&inner));
            self.heap.push(Reverse((deadline, id)));

            Sleep::new(inner)
        }

        pub fn advance_to(&mut self, new_now: MuonInstant) {
            if new_now < self.now {
                return;
            }
            self.now = new_now;

            while let Some(Reverse((deadline, id))) = self.heap.peek().cloned() {
                if deadline > self.now {
                    break;
                }
                let _ = self.heap.pop();

                let mut remove_key = false;
                if let Some(wk) = self.registry.get(&id) {
                    if let Some(rc) = wk.upgrade() {
                        let mut inner = rc.lock().unwrap();
                        if !inner.done {
                            inner.done = true;
                            if let Some(w) = inner.waker.take() {
                                w.wake();
                            }
                        }
                    } else {
                        remove_key = true;
                    }
                }
                if remove_key {
                    self.registry.remove(&id);
                }
            }
        }

        fn alloc_id(&mut self) -> TimerId {
            let id = TimerId(self.next_id);
            self.next_id = self.next_id.wrapping_add(1);
            id
        }
    }
}
