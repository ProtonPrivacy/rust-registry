//! # Rest
//! Structures mapping the requests/response to/from the ProtonAPI
//!
//! This module re-exports types from crate `muon_rest`

/// `/auth`
pub mod auth {
    /// `v4`
    pub mod v4 {
        // re-export to be backward compatible
        pub use crate::sessions::SessionCredentials;
        // this is not made publicly available
        pub(crate) use muon_rest::auth::v4::SessionCredentials as RawSessionCredentials;
        pub use muon_rest::auth::v4::{
            Delete, PasswordMode, Post, PostRes, fido2, info, refresh, sessions, tfa,
        };
    }
}

/// `/core`
pub use muon_rest::core;
/// `/tests`
pub use muon_rest::tests;
pub use muon_rest::{ApiErr, Bool};
