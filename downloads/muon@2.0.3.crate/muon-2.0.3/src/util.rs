//! ## Util
//!
//! Just some useful stuff.

use data_encoding::{BASE32_NOPAD, BASE64, BASE64URL_NOPAD, DecodeError};
use futures::{TryFuture, TryFutureExt};
use serde_json::Error as JsonError;
use sha2::{Digest, Sha256};
use std::array::TryFromSliceError;
use std::collections::{HashMap, HashSet};
use std::convert::Infallible;
use std::hash::Hash;
use std::string::FromUtf8Error;
#[cfg(feature = "testing")]
use std::time::Duration;
use thiserror::Error;

/// A decoding error.
#[derive(Debug, Error)]
#[error(transparent)]
pub enum ByteSliceErr {
    /// A data decoding error.
    Data(#[from] DecodeError),

    /// A UTF-8 decoding error.
    Utf8(#[from] FromUtf8Error),

    /// A JSON encoding/decoding error.
    Json(#[from] JsonError),

    /// A slice conversion error.
    Slice(#[from] TryFromSliceError),
}

impl From<Infallible> for ByteSliceErr {
    fn from(err: Infallible) -> Self {
        match err {}
    }
}

/// Extends byte slices with various encoding/decoding/hashing methods.
pub trait ByteSliceExt: AsRef<[u8]> {
    /// Encodes the value as base32.
    fn as_b32(&self) -> String {
        BASE32_NOPAD.encode(self.as_ref())
    }

    /// Encodes the value as base64.
    fn as_b64(&self) -> String {
        BASE64.encode(self.as_ref())
    }

    /// Encodes the value as URL-safe, no-padding base64.
    fn as_b64_url(&self) -> String {
        BASE64URL_NOPAD.encode(self.as_ref())
    }

    /// Decodes the value from base64.
    ///
    /// # Errors
    ///
    /// Returns an error if the value is not valid base64.
    fn b64_into<T>(&self) -> Result<T, ByteSliceErr>
    where
        for<'a> &'a [u8]: TryInto<T>,
        for<'a> <&'a [u8] as TryInto<T>>::Error: Into<ByteSliceErr>,
    {
        (BASE64.decode(self.as_ref())?)
            .as_slice()
            .try_into()
            .map_err(Into::into)
    }

    /// Computes the SHA-256 hash of the value.
    fn sha256(&self) -> [u8; 32] {
        Sha256::digest(self.as_ref()).into()
    }

    /// Convert this to a string as UTF-8.
    ///
    /// # Errors
    ///
    /// Returns an error if the value is not valid UTF-8.
    fn as_utf8(&self) -> Result<String, ByteSliceErr> {
        String::from_utf8(self.as_ref().into()).map_err(ByteSliceErr::Utf8)
    }

    /// Convert this to a string as UTF-8 lossy.
    fn as_utf8_lossy(&self) -> String {
        String::from_utf8_lossy(self.as_ref()).into()
    }
}

impl<T: AsRef<[u8]>> ByteSliceExt for T {}

/// Extends iterators with various methods.
pub trait IntoIterExt: IntoIterator + Sized {
    /// Collects the iterator into a `Vec`.
    fn into_vec<T>(self) -> Vec<T>
    where
        Self: IntoIterator<Item = T>,
    {
        self.into_iter().collect()
    }

    /// Tries to collect the iterator into a `Result<Vec<T>, E>`.
    ///
    /// # Errors
    ///
    /// Returns an error if any of the items fail to convert.
    fn try_into_vec<T, E>(self) -> Result<Vec<T>, E>
    where
        Self: IntoIterator<Item = Result<T, E>>,
    {
        self.into_iter().collect::<Result<Vec<T>, E>>()
    }

    /// Collects the iterator into a `HashMap`.
    fn into_map<K: Hash + Eq, V>(self) -> HashMap<K, V>
    where
        Self: IntoIterator<Item = (K, V)>,
    {
        self.into_iter().collect()
    }

    /// Tries to collect the iterator into a `Result<HashMap<K, V>, E>`.
    ///
    /// # Errors
    ///
    /// Returns an error if any of the items fail to convert.
    fn try_into_map<K: Hash + Eq, V, E>(self) -> Result<HashMap<K, V>, E>
    where
        Self: IntoIterator<Item = Result<(K, V), E>>,
    {
        self.into_iter().collect::<Result<HashMap<K, V>, E>>()
    }

    /// Collects the iterator into a `HashSet`.
    fn into_set<T: Hash + Eq>(self) -> HashSet<T>
    where
        Self: IntoIterator<Item = T>,
    {
        self.into_iter().collect()
    }

    /// Tries to collect the iterator into a `Result<HashSet<T>, E>`.
    ///
    /// # Errors
    ///
    /// Returns an error if any of the items fail to convert.
    fn try_into_set<T: Hash + Eq, E>(self) -> Result<HashSet<T>, E>
    where
        Self: IntoIterator<Item = Result<T, E>>,
    {
        self.into_iter().collect::<Result<HashSet<T>, E>>()
    }

    /// Collects the iterator into a head and a tail, or `None` if empty.
    fn into_head_tail(self) -> Option<(Self::Item, Self::IntoIter)> {
        let mut this = self.into_iter();

        let head = this.next()?;

        Some((head, this))
    }
}

impl<T: IntoIterator + Sized> IntoIterExt for T {}

/// Enables racing futures to retrieve just the fastest one.
///
/// If all fails, return the last error
pub(crate) trait TryRace<F>: IntoIterator<Item = F> + Sized
where
    F: TryFuture + Unpin,
{
    /// Race the futures to retrieve just the fastest one.
    async fn try_race(self) -> Result<F::Ok, F::Error> {
        futures::future::select_ok(self.into_iter())
            .map_ok(|(t, _)| t)
            .await
    }
}

impl<T: IntoIterator<Item = F> + Sized, F: TryFuture + Unpin> TryRace<F> for T {}

#[cfg(feature = "testing")]
/// Trait for working with `Duration`.
///
/// Enables converting numeric types to and from `Duration`.
pub trait DurationExt: num_traits::AsPrimitive<u64> {
    /// Treats the value as `minutes`.
    fn m(self) -> Duration {
        Duration::from_secs(self.as_() * 60)
    }

    /// Treats the value as `seconds`.
    fn s(self) -> Duration {
        Duration::from_secs(self.as_())
    }

    /// Treats the value as `milliseconds`.
    fn ms(self) -> Duration {
        Duration::from_millis(self.as_())
    }

    /// Treats the value as `microseconds`.
    fn us(self) -> Duration {
        Duration::from_micros(self.as_())
    }

    /// Treats the value as `nanoseconds`.
    fn ns(self) -> Duration {
        Duration::from_nanos(self.as_())
    }
}

#[cfg(feature = "testing")]
impl<T: num_traits::AsPrimitive<u64>> DurationExt for T {}

/// Create a `Url` from arguments that can be formatted with `format!`.
#[doc(hidden)]
#[allow(unused)]
macro_rules! url {
    ($($tt:tt)*) => {
        url::Url::parse(&format!($($tt)*))
    };
}

#[allow(unused)]
pub(crate) use url;
