use serde_json::Value;
use std::fmt::Display;
use std::str::FromStr;

/// An interface to the info provider. This is used by the muon Client to ask
/// for extra info from the apps that use it. All functions defined by
/// InfoProvider need return optionals. Apps that integrate muon need to be able
/// to choose if they send the info that muon wants to request.
/// Here's an example on how to use InfoProvider
///
/// For a complete example, see [examples/auth-info-providers.rs]
/// ```
/// # use muon::tests::util::*;
/// use muon::{App, Client, Fingerprint, ProvideInformation};
/// use muon::Environment;
/// use muon::auth::LoginFlow;
/// use std::sync::Arc;
/// use serde_json::json;
///
/// // ExampleInfoProvider shows how to implement the InfoProvider trait a client that uses muon.
/// #[derive(Debug, Clone)]
/// struct ExampleInfoProvider;
/// impl ProvideInformation for ExampleInfoProvider {
///     fn fingerprint(&self) -> Option<Fingerprint> {
///         let fingerprint = json!({
///             "mail-android-99.9.40.0-challenge":{
///                 "appLang":"en",
///                 "deviceName":"TestDevice",
///                 "frame":{
///                     "name":"username"
///                 },
///                 "isDarkmodeOn":false,
///                 "isJailbreak":false,
///                 "keyboards":[
///                 ],
///                 "preferredContentSize":"2.0",
///                 "regionCode":"CH",
///                 "storageCapacity":"63.8",
///                 "timezone":"Europe/Zurich",
///                 "timezoneOffset":"0",
///                 "v":"2.0.0"
///             }
///         })
///         .into();
///         Some(fingerprint)
///     }
/// }
///
/// # #[tokio::main]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// // Please check the auth-info-provider.rs example to see how to pass a fingerprint to the muon client.
/// // The fingerprint is important in combating fraud.
/// let client = new_builder()
///     .without_persistence::<()>()
///     .with_info_provider(ExampleInfoProvider)
///     .build()?;
///
/// // Here we pass in the ExampleInfoProvider using with_info_provider.
/// let session = client.new_session_without_credentials(()).await?;
/// let session = match session.auth().login("visionary", "a").await {
///     LoginFlow::Ok(session, _) => session,
///     LoginFlow::TwoFactor(_, _) => panic!("Second factor required."),
///     LoginFlow::Failed { reason, .. } => panic!("Login failed: {}.", reason),
/// };
/// session.clone().logout().await;
/// # Ok(())
/// # }
/// ```
pub trait ProvideInformation: std::fmt::Debug + Clone {
    fn fingerprint(&self) -> Option<Fingerprint>;
}

impl<T: ProvideInformation> ProvideInformation for &T {
    fn fingerprint(&self) -> Option<Fingerprint> {
        (*self).fingerprint()
    }
}

#[derive(Debug, Clone, Default)]
pub struct NoInfo;

impl ProvideInformation for NoInfo {
    fn fingerprint(&self) -> Option<Fingerprint> {
        None
    }
}

/// Fingerprint to be used for anti-abuse.
#[must_use]
#[derive(Clone, Debug, Default)]
pub struct Fingerprint(pub Value);

impl From<Value> for Fingerprint {
    fn from(value: Value) -> Self {
        Fingerprint(value)
    }
}

impl From<Fingerprint> for Value {
    fn from(val: Fingerprint) -> Self {
        val.0
    }
}

impl Display for Fingerprint {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0.to_string())
    }
}

impl FromStr for Fingerprint {
    type Err = serde_json::Error;

    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        s.parse::<Value>().map(Fingerprint::from)
    }
}
