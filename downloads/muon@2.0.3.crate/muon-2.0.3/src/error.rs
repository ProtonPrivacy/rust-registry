use crate::rt::{IntoSystemError, SystemError};
use derive_more::Display;
use std::error::Error as StdError;

/// A `Result` alias where the `Err` case is `muon::Error`.
pub type Result<T, E = Error> = std::result::Result<T, E>;

pub type SourceError = Box<dyn StdError + Send + Sync>;

/// An error internally produced in Muon.
///
/// If Muon can do something about the error then it should be an explicit
/// variant. Otherwise, it should be a [`InternalError::Irrecoverable`].
#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum InternalError {
    /// DNS resolution related system errors
    #[error("error resolving destination: {0}")]
    Resolve(SystemError),

    /// TCP connect errors
    #[error("error while connecting to destination: {0}")]
    TcpConnect(SystemError),

    /// TCP transmission error
    #[error("error during transmission: {0}")]
    TcpSend(SystemError),

    /// Errors we will not act upon inside of muon, any of those errors
    /// must be sent back to the user directly without retry.
    #[error(transparent)]
    Irrecoverable(crate::Error),
}

impl InternalError {
    pub fn is_recoverable(&self) -> bool {
        !matches!(self, Self::Irrecoverable(_))
    }

    pub fn irrecoverable(error: impl Into<crate::Error>) -> Self {
        Self::Irrecoverable(error.into())
    }

    pub fn resolve(error: impl IntoSystemError) -> Self {
        Self::Resolve(error.into_system_error())
    }

    pub fn connect(error: impl IntoSystemError) -> Self {
        Self::TcpConnect(error.into_system_error())
    }

    pub fn send(error: impl IntoSystemError) -> Self {
        Self::TcpSend(error.into_system_error())
    }

    pub fn is_retryable(&self) -> bool {
        match self {
            InternalError::Resolve(system_error)
            | InternalError::TcpConnect(system_error)
            | InternalError::TcpSend(system_error) => system_error.is_retryable(),
            InternalError::Irrecoverable(_) => false,
        }
    }
}

impl From<crate::Error> for InternalError {
    fn from(value: crate::Error) -> Self {
        Self::Irrecoverable(value)
    }
}

trait SystemErrorExt {
    fn is_retryable(&self) -> bool;
}

impl SystemErrorExt for SystemError {
    fn is_retryable(&self) -> bool {
        matches!(
            self,
            SystemError::Timeout
                | SystemError::ConnectionReset
                | SystemError::ApplicationError
                | SystemError::ConnectionAborted
                | SystemError::NotConnected
                | SystemError::ConnectionRefused
                | SystemError::BrokenPipe
                | SystemError::NetworkDown
                | SystemError::WouldBlock
                | SystemError::InProgress
                | SystemError::Interrupted
                | SystemError::UnexpectedEof
        )
    }
}

/// An error that may occur when using muon.
#[derive(Debug)]
pub struct Error {
    /// The kind of error.
    kind: ErrorKind,

    /// The source of the error, if any.
    src: Option<SourceError>,
}

impl Error {
    pub(crate) fn new<E: Into<SourceError>>(kind: ErrorKind, src: Option<E>) -> Error {
        Error {
            kind,
            src: src.map(Into::into),
        }
    }

    /// Get the kind of error.
    pub fn kind(&self) -> ErrorKind {
        self.kind
    }

    pub(crate) fn map_kind(self, kind: ErrorKind) -> Error {
        Error { kind, ..self }
    }

    /// Create an "other" error.
    ///
    /// This is useful when implementing layers outside this crate.
    pub fn other<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Other, Some(src))
    }
}

impl StdError for Error {
    fn source(&self) -> Option<&(dyn StdError + 'static)> {
        if let Some(src) = &self.src {
            Some(src.source().unwrap_or(src.as_ref()))
        } else {
            None
        }
    }
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        if let Some(src) = &self.src {
            write!(f, "{}: {src}", self.kind)
        } else {
            write!(f, "{}", self.kind)
        }
    }
}

/// The kinds of errors that can occur.
#[derive(Debug, Display, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ErrorKind {
    /// Authentication failure.
    #[display("failed to authenticate")]
    Auth,

    /// Storage error
    #[display("failed to use the store for session data")]
    Storage,

    /// TLS error.
    #[display("TLS error")]
    Tls,

    /// Host resolution failure.
    #[display("failed to resolve host")]
    Resolve,

    /// Host dialing failure.
    #[display("failed to dial host")]
    Dial,

    /// Host connection failure.
    #[display("failed to connect to host")]
    Connect,

    /// Request sending failure.
    #[display("failed to send request")]
    Send,

    /// The connection was closed.
    #[display("connection closed")]
    #[deprecated(note = "use `Send` and/or `Error::retryable` instead")]
    Closed,

    /// Error in request.
    #[display("error in request")]
    Req,

    /// Error in response.
    #[display("error in response")]
    Res,

    /// Other error.
    #[display("other error")]
    Other,
}

impl ErrorKind {
    pub fn auth<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Auth, Some(src))
    }

    /// Defines storage related errors for Store operation
    pub fn storage<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Storage, Some(src))
    }

    #[allow(unused)]
    pub fn tls<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Tls, Some(src))
    }

    pub fn resolve<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Resolve, Some(src))
    }

    pub fn dial<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Dial, Some(src))
    }

    pub fn connect<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Connect, Some(src))
    }

    pub fn send<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Send, Some(src))
    }

    pub(crate) fn req<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Req, Some(src))
    }

    pub(crate) fn res<E: Into<SourceError>>(src: E) -> Error {
        Error::new(ErrorKind::Res, Some(src))
    }
}
