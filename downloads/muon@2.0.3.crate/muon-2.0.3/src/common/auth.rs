use crate::auth::{Auth, Tokens};
use crate::common::{
    AuthTokenHeader, AuthUidHeader, ProtonRequest, ProtonResponse, SendRequest, ServiceType,
};
use crate::http::{POST, StatusErr};
use crate::rest::auth;
use crate::store::{AuthVersion, SharedVersionedStorage, Store, Versioned};
use crate::{
    Context, Error, ErrorKind, InternalError, ProvideInformation, Result, SessionCredentials,
};
use http::status::StatusCode;
use std::borrow::Borrow;
use std::ops::DerefMut;
use std::time::Duration;
use thiserror::Error;
use tracing::{debug, error, info, trace, warn};

const AUTH_V4_REFRESH_DURATION: Duration = Duration::from_secs(15);
const AUTH_V4_SESSIONS_DURATION: Duration = Duration::from_secs(15);

#[derive(Debug)]
pub(crate) struct AuthSender<'a, S, C: Context> {
    pub sender: S,
    pub client: &'a crate::Client<C>,
    pub session_key: &'a C::SessionKey,
}

impl<S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>, C: Context>
    AuthSender<'_, S, C>
{
    pub(crate) async fn force_refresh(&self) -> Result<(), InternalError> {
        let (_, ver) = self
            .client
            .storage()
            .read()
            .await
            .get_auth(self.session_key);

        let _ = refresh_store(&self.sender, self.client, self.session_key, &ver)
            .await
            .map_err(InternalError::irrecoverable)?;

        info!("refresh succeeded, sync to persistent store");
        self.client.storage().write().await.sync_stores();

        Ok(())
    }

    pub(crate) async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, InternalError> {
        let (auth, ver) = self
            .client
            .storage()
            .read()
            .await
            .get_auth(self.session_key);

        let (_, auth) = if let Auth::None = auth {
            info!("attempting to get unauth session");
            let res = new_unauth_session(
                &self.sender,
                self.client.storage(),
                &ver,
                self.client.information_provider(),
                self.session_key,
            )
            .await
            .map_err(InternalError::irrecoverable)?;

            info!("create unauth session succeeded, sync to persistent store");
            self.client.storage().write().await.sync_stores();

            res
        } else {
            trace!("using existing session");
            (ver, auth)
        };

        let Some(uid) = auth.uid() else {
            trace!("no auth session available, sending as-is");
            return self.sender.send(req).await;
        };

        trace!(%uid, "attaching auth UID to request");
        let req = req.header(AuthUidHeader::new(uid));

        let Some(tok) = auth.tokens() else {
            trace!(%uid, "no auth tokens available, sending as-is");
            return self.sender.send(req).await;
        };

        if let Some(tok) = tok.acc_tok() {
            trace!(%uid, "attaching auth token to request");
            let req = req.clone().header(AuthTokenHeader::new(tok));

            debug!(%uid, "sending authenticated request");
            match self.sender.send(req).await? {
                t if !t.is(StatusCode::UNAUTHORIZED) => return Ok(t),
                _ => warn!(%uid, "session unauthorized"),
            }
        }

        match refresh_store(&self.sender, self.client, self.session_key, &ver).await {
            Ok(auth) => match auth.acc_tok() {
                Some(tok) => {
                    info!(%uid, "refresh succeeded, sync to persistent store");
                    self.client.storage().write().await.sync_stores();

                    info!(%uid, "sending authenticated request with updated tokens");
                    Ok(self
                        .sender
                        .send(req.header(AuthTokenHeader::new(tok)))
                        .await?)
                }

                None => {
                    error!(%uid, "no access token available after refresh");
                    Err(InternalError::irrecoverable(ErrorKind::auth(
                        AuthErr::Refresh,
                    )))
                }
            },

            Err(err @ AuthLayerErr::Auth(AuthErr::Session)) => {
                warn!(%uid, "auth session no longer exists");
                // We need to clone the session as remove_auth takes ownership of the session
                self.client
                    .storage()
                    .write()
                    .await
                    .remove_auth(self.session_key);

                Err(InternalError::irrecoverable(err))
            }

            Err(err) => Err(InternalError::irrecoverable(err)),
        }
    }
}

/// Errors that can occur while using the auth layer.
#[derive(Debug, Error)]
pub enum AuthErr {
    /// The session could not be refreshed.
    #[error("refresh failed")]
    Refresh,

    /// The session does not exist.
    #[error("non-existent session")]
    Session,
}

async fn auth_refresh(
    inner: &impl SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
    uid: &str,
    tok: &str,
) -> Result<Tokens, AuthLayerErr> {
    // Build the refresh request.
    let req = auth::v4::refresh::Post {
        refresh_token: tok.to_owned(),
        response_type: "token".to_owned(),
        grant_type: "refresh_token".to_owned(),
        redirect_uri: "https://protonmail.ch".to_owned(),
    };

    // Send the refresh request.
    let refresh_req = POST!("/auth/v4/refresh")
        .header(AuthUidHeader::new(uid))
        .allowed_time(AUTH_V4_REFRESH_DURATION)
        .service_type(ServiceType::Interactive, false)
        .body_json(req)
        .map_err(InternalError::irrecoverable)?;

    let res = inner.send(refresh_req).await?;

    // Parse the refresh response.
    let res: auth::v4::refresh::PostRes = match res.ok() {
        Ok(res) => {
            trace!("auth refresh successful");
            res.into_body_json().map_err(InternalError::irrecoverable)?
        }

        Err(err) => {
            error!(%err, "unexpected error during auth refresh");
            return Err(AuthLayerErr::StatusErr(err));
        }
    };

    let auth = SessionCredentials(res.auth);

    // The UID should *never* change.
    assert_eq!(auth.uid(), uid);

    // Build the new set of tokens.
    Ok(auth.into())
}

async fn refresh_store<C: Context>(
    sender: &impl SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
    client: &crate::Client<C>,
    session_key: &C::SessionKey,
    ver: &AuthVersion,
) -> Result<Auth, AuthLayerErr> {
    // FixMe(aboulmier): this is wrong, we should not lock the whole thing for a
    // single session
    let store = client.storage().write().await;
    let info_provider = client.information_provider();
    trace!("checking current auth session version");
    match store.get_auth(session_key) {
        (ref auth, ref cur) if cur == ver => {
            if let Auth::Anonymous { uid, tok } = auth {
                refresh_unauthenticated_session(sender, store, info_provider, uid, tok, session_key)
                    .await
            } else if let Auth::Internal { user_id, uid, tok } = auth {
                refresh_authenticated_session(sender, store, user_id, uid, tok, session_key).await
            } else {
                Ok(Auth::None)
            }
        }

        (auth, _) => {
            trace!("auth session already updated");
            Ok(auth)
        }
    }
}

async fn refresh_authenticated_session<Storage: Store>(
    inner: &impl SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
    mut store: impl DerefMut<Target = Versioned<Storage>>,
    user_id: &str,
    uid: &str,
    tok: &Tokens,
    session_key: &Storage::Key,
) -> Result<Auth, AuthLayerErr> {
    info!(%uid, "attempting auth refresh");
    let tok = match auth_refresh(inner, uid, tok.ref_tok()).await {
        Ok(tok) => tok,

        Err(AuthLayerErr::StatusErr(StatusErr(code, _))) if code.requires_logout() => {
            if code == StatusCode::BAD_REQUEST {
                error!(
                    "non-existent auth session. Received a 400 from the backend. This indicates a problem with the refresh logic. It could be that the same token was refreshed twice. Please check!"
                );
            } else {
                error!("non-existent auth session");
            }

            return Err(AuthErr::Session)?;
        }

        Err(err) => {
            error!(%err, "unexpected error during auth refresh");
            return Err(AuthErr::Refresh)?;
        }
    };

    info!(%uid, "building new auth object");
    let auth = Auth::internal(user_id, uid, tok);

    info!("storing new auth tokens");
    store.set_auth(session_key.to_owned(), auth.clone())?;

    Ok(auth)
}

async fn refresh_unauthenticated_session<Storage: Store>(
    inner: &impl SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
    mut store: impl DerefMut<Target = Versioned<Storage>>,
    info_provider: impl ProvideInformation,
    uid: &str,
    tok: &Tokens,
    session_key: &Storage::Key,
) -> Result<Auth, AuthLayerErr> {
    info!(%uid, "attempting unauth session refresh");
    match auth_refresh(inner, uid, tok.ref_tok()).await {
        Ok(tok) => {
            info!(%uid, "building new unauth session object");
            let auth = Auth::anonymous(uid, tok);

            info!("storing new unauth session tokens");
            store.set_auth(session_key.to_owned(), auth.clone())?;

            Ok(auth)
        }

        Err(AuthLayerErr::StatusErr(StatusErr(code, _))) if code.requires_unauth() => {
            info!(%uid, "refresh failed - creating a new unauth session object");
            let auth = match unauth_session(inner, info_provider).await {
                Ok(auth) => auth,
                Err(err) => {
                    error!(%err, "unexpected error during unauth session create");
                    return Err(AuthErr::Session)?;
                }
            };

            info!("storing new unauth session tokens");
            store.set_auth(session_key.to_owned(), auth.clone())?;

            Ok(auth)
        }

        Err(err) => {
            error!(%err, "unexpected error during unauth session refresh");
            Err(AuthErr::Refresh)?
        }
    }
}

async fn unauth_session(
    inner: &impl SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
    info_provider: impl ProvideInformation,
) -> Result<Auth, AuthLayerErr> {
    let mut req = crate::POST!("/auth/v4/sessions")
        .allowed_time(AUTH_V4_SESSIONS_DURATION)
        .service_type(ServiceType::Interactive, false);

    if let Some(fingerprint) = info_provider.fingerprint() {
        info!("setting fingerprint {fingerprint}");
        req = req.body(fingerprint.0.to_string());
    }

    // Send the unauth session request
    let res = inner.send(req).await?;
    // Parse the unauth session response.
    let res: crate::rest::auth::v4::RawSessionCredentials = match res.ok() {
        Ok(res) => {
            trace!("unauth session created successfully");
            res.into_body_json().map_err(InternalError::irrecoverable)?
        }

        Err(err) => {
            error!(%err, "unexpected error during unauth session request");
            return Err(AuthLayerErr::StatusErr(err));
        }
    };
    let res = SessionCredentials(res);
    trace!("building new auth object");
    let auth = Auth::anonymous(res.uid().to_owned(), res);

    Ok(auth)
}

async fn new_unauth_session<Storage: Store>(
    inner: &impl SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
    store: &SharedVersionedStorage<Storage>,
    ver: &AuthVersion,
    provider: impl ProvideInformation,
    session_key: &Storage::Key,
) -> Result<(AuthVersion, Auth), AuthLayerErr> {
    trace!("locking store to save unauth session credentials");
    let mut store = store.write().await;

    trace!("checking current auth session version");
    match store.get_auth(session_key) {
        (_, ref cur) if cur == ver => {
            info!("attempting to get unauth session");
            let auth = unauth_session(inner, provider).await?;

            info!("storing new auth tokens");
            let new_ver: AuthVersion = store
                .set_auth(session_key.to_owned(), auth.clone())
                .map_err(AuthLayerErr::from)?;

            Ok((new_ver, auth))
        }

        (auth, ver) => {
            trace!("unauth session already updated");
            Ok((ver, auth))
        }
    }
}

pub(crate) mod errors {
    use super::*;
    use crate::store::DuplicateUidError;

    #[derive(Debug, Error)]
    #[error("auth layer: {0}")]
    pub enum AuthLayerErr {
        Auth(#[from] AuthErr),
        StatusErr(#[from] StatusErr),
        StoreState(#[from] DuplicateUidError),
        Inner(#[from] InternalError),
    }

    impl From<AuthLayerErr> for Error {
        fn from(err: AuthLayerErr) -> Self {
            if let AuthLayerErr::Inner(err) = err {
                ErrorKind::send(err)
            } else {
                ErrorKind::send(err)
            }
        }
    }
}

use self::errors::*;

trait StatusCodeExt: Borrow<StatusCode> {
    fn requires_logout(&self) -> bool {
        [
            StatusCode::BAD_REQUEST,
            StatusCode::UNAUTHORIZED,
            StatusCode::UNPROCESSABLE_ENTITY,
        ]
        .contains(self.borrow())
    }

    fn requires_unauth(&self) -> bool {
        [
            StatusCode::BAD_REQUEST,
            StatusCode::UNAUTHORIZED,
            StatusCode::MISDIRECTED_REQUEST,
            StatusCode::UNPROCESSABLE_ENTITY,
        ]
        .contains(self.borrow())
    }
}

impl<T: Borrow<StatusCode>> StatusCodeExt for T {}

#[cfg(test)]
mod test_auth {
    use crate::auth::Scopes;
    use crate::common::{AuthSender, SendRequest};
    use crate::rest::auth::v4::RawSessionCredentials;
    use crate::tests::util::new_client;
    use crate::{
        Client, Context, DELETE, ErrorKind, InternalError, ProtonRequest, ProtonResponse,
        SessionCredentials,
    };
    use http::StatusCode;
    use std::sync::atomic::AtomicU32;
    use std::time::Duration;

    fn dummy_creds(scope: impl IntoIterator<Item = String>) -> SessionCredentials {
        SessionCredentials(RawSessionCredentials::new(
            "a",
            Some("1"),
            "acc",
            "ref",
            Scopes::new(scope),
        ))
    }
    fn auth_creds() -> SessionCredentials {
        SessionCredentials(RawSessionCredentials::new(
            "a",
            Some("1"),
            "AUTH",
            "ref",
            Scopes::new(["FULL".into()]),
        ))
    }
    #[tokio::test]
    async fn force_refresh() {
        async fn get_scope<C: Context<SessionKey = ()>>(client: &Client<C>) -> Scopes {
            let (auth, _) = client.storage().read().await.get_auth(&());
            auth.scopes().unwrap().clone()
        }
        #[derive(Debug, Default)]
        struct ProtonApiMock;
        impl SendRequest<ProtonRequest, ProtonResponse> for ProtonApiMock {
            type Err = InternalError;
            async fn send(&self, _: ProtonRequest) -> Result<ProtonResponse, Self::Err> {
                let new_creds = dummy_creds(["VPN".to_owned()]);
                Ok(http::Response::builder()
                    .body(serde_json::to_vec(&new_creds).map_err(ErrorKind::res)?)
                    .map(Into::into)?)
            }
        }
        let client = new_client::<()>();
        let _s = client
            .new_session_with_credentials((), dummy_creds([]))
            .await
            .unwrap();
        assert_eq!(get_scope(&client).await.len(), 0);
        let auth = AuthSender {
            sender: ProtonApiMock::default(),
            client: &client,
            session_key: &(),
        };
        auth.force_refresh().await.unwrap();
        let scopes = get_scope(&client).await;
        assert_eq!(scopes.len(), 1);
        assert!(scopes.has("VPN"))
    }

    #[tokio::test]
    async fn concurrent_refresh() {
        fn empty_response(status: StatusCode) -> Result<ProtonResponse, InternalError> {
            Ok(http::Response::builder()
                .status(status)
                .body(vec![])
                .map(Into::into)?)
        }
        #[derive(Debug, Default)]
        struct ProtonApiMock(AtomicU32);
        impl SendRequest<ProtonRequest, ProtonResponse> for ProtonApiMock {
            type Err = InternalError;
            async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, Self::Err> {
                let auth = req
                    .get_header()
                    .iter()
                    .find(|(h, v)| h == "authorization" && v == "Bearer AUTH");

                match req.get_method() {
                    crate::http::Method::POST => {
                        self.0.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                        tokio::time::sleep(Duration::from_millis(500)).await;
                        Ok(http::Response::builder()
                            .body(serde_json::to_vec(&auth_creds()).map_err(ErrorKind::res)?)
                            .map(Into::into)?)
                    }
                    crate::http::Method::DELETE if auth.is_some() => empty_response(StatusCode::OK),
                    crate::http::Method::DELETE => empty_response(StatusCode::UNAUTHORIZED),
                    _ => unreachable!(),
                }
            }
        }
        let client = new_client::<()>();
        let _s = client
            .new_session_with_credentials((), dummy_creds([]))
            .await
            .unwrap();

        let auth = AuthSender {
            sender: ProtonApiMock::default(),
            client: &client,
            session_key: &(),
        };
        let req = DELETE!("/tests/ping");
        let (r1, r2, r3) = tokio::join!(
            auth.send(req.clone()),
            auth.send(req.clone()),
            auth.send(req.clone()),
        );
        assert!(r1.unwrap().status() == StatusCode::OK);
        assert!(r2.unwrap().status() == StatusCode::OK);
        assert!(r3.unwrap().status() == StatusCode::OK);
        assert_eq!(auth.sender.0.load(std::sync::atomic::Ordering::SeqCst), 1);
    }
}
