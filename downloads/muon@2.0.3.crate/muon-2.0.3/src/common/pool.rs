use crate::common::{BoundSender, Endpoint, Host, SendRequest};
use crate::{ProtonRequest, ProtonResponse};
use async_lock::{Mutex, MutexGuard};
use derive_more::Deref;
use std::collections::HashMap;
use std::ops::Deref;
use std::sync::{Arc, Weak};
use tracing::trace;

/// An attempt to get a sender from the pool.
///
/// If it succeeds, it returns the value.
/// Otherwise, it returns the pool guard, enabling a retry.
#[derive(Debug)]
pub(crate) enum TryGet<'a, T> {
    Some(PooledSender<T>),
    None(PoolGuard<'a, T>),
}

/// A pool of HTTP senders.
///
/// This is protected by a mutex.
/// All pool operations must begin by acquiring a lock.
pub(crate) struct Pool<Sender> {
    items: Mutex<HashMap<Endpoint, BoundSender<Sender>>>,
}

impl<Sender> std::fmt::Debug for Pool<Sender> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Pool")
            .field("endpoints", &self.items)
            .finish()
    }
}

impl<S> Default for Pool<S> {
    fn default() -> Self {
        Self {
            items: Default::default(),
        }
    }
}

impl<S> Pool<S> {
    /// Acquire a lock on the pool.
    ///
    /// This returns a [`PoolGuard`] that releases the lock when dropped.
    pub async fn lock<'a>(self: &'a Arc<Self>) -> PoolGuard<'a, S> {
        PoolGuard {
            pool: self,
            lock: self.items.lock().await,
        }
    }
}

/// A guard enabling the pool to be modified.
#[derive(Debug)]
pub(crate) struct PoolGuard<'a, S> {
    pool: &'a Arc<Pool<S>>,
    lock: MutexGuard<'a, HashMap<Endpoint, BoundSender<S>>>,
}

impl<'a, S> PoolGuard<'a, S> {
    /// Get a sender from the pool.
    pub fn get(self, key: &Endpoint) -> TryGet<'a, S>
    where
        S: Clone,
    {
        if let Some(sender) = self.lock.get(key) {
            TryGet::Some(PooledSender::new(key, self.pool, sender))
        } else {
            TryGet::None(self)
        }
    }

    /// Set the sender for the given target URL.
    pub fn insert(mut self, key: &Endpoint, sender: BoundSender<S>) -> PooledSender<S>
    where
        S: Clone,
    {
        self.lock.insert(key.clone(), sender.clone());

        PooledSender::new(key, self.pool, &sender)
    }

    /// Extend the sender's lifetime in the pool.
    ///
    /// TODO: Do we need this?
    fn extend(&mut self, _: &Endpoint) {
        let _ = self;
    }

    /// Remove the sender with the given key.
    fn unpool(&mut self, key: &Endpoint) {
        self.lock.remove(key);
    }
}

/// A pool sender.
///
/// This type wraps a sender and a weak reference to the pool.
/// If a send fails, we assume the sender is broken and remove it from the pool;
/// this is achieved by calling the sender's `unpool` method.
#[derive(Debug, Deref)]
pub(crate) struct PooledSender<S> {
    /// The key by which this sender can be found in the pool.
    key: Endpoint,

    /// The pool from which this sender was taken.
    pool: Weak<Pool<S>>,

    /// The sender itself.
    #[deref]
    sender: BoundSender<S>,
}

impl<S> PooledSender<S> {
    fn new(key: &Endpoint, pool: &Arc<Pool<S>>, sender: &BoundSender<S>) -> Self
    where
        S: Clone,
    {
        let key = key.to_owned();
        let pool = Arc::downgrade(pool);
        let sender = sender.to_owned();

        Self { key, pool, sender }
    }

    /// Extend the sender's lifetime in the pool.
    pub async fn repool(self) {
        if let Some(pool) = self.pool.upgrade() {
            trace!(server = %self.key, "repooling sender");
            pool.lock().await.extend(&self.key);
        } else {
            trace!(server = %self.key, "pool dropped; not repooling sender");
        }
    }

    /// Remove the sender from the pool.
    pub async fn unpool(self) {
        if let Some(pool) = self.pool.upgrade() {
            trace!(server = %self.key, "unpooling sender");
            pool.lock().await.unpool(&self.key);
        } else {
            trace!(server = %self.key, "pool dropped; not unpooling sender");
        }
    }

    /// Get the host this sender will send requests to
    pub fn host(&self) -> &Host {
        self.key.host()
    }
}

impl<S: SendRequest<ProtonRequest, ProtonResponse>> SendRequest<ProtonRequest, ProtonResponse>
    for PooledSender<S>
{
    async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, S::Err> {
        self.deref().send(req).await
    }

    type Err = S::Err;
}
