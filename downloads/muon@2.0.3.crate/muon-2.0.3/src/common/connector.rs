//! ## Connector
//!
//! A connector is responsible for constructing a [`Sender`] that can be used to
//! send messages to a [`Server`]. This module defines the [`Connector`] trait
//! and related types.
//!
//! [`Connector`]: crate::common::Connector
//! [`Sender`]: crate::common::Sender

use crate::common::{BoundSender, SendRequest, Server};
use crate::rt::{HasRandCapabilities, HasSleepCapabilities};
use crate::tls::upgrader::MuonUpgrader;
use crate::{InternalError, Result};

/// Implemented for all "connector" for the ProtonAPI.
///
/// This provides a way to get a [`Sender`](SendRequest) for the ProtonAPI.
pub trait ProtonConnectTransport<Req, Res>: ConnectTransport<Req, Res> {
    fn connect(
        &self,
        server: &Server,
    ) -> impl std::future::Future<Output = Result<BoundSender<Self::Sender>, InternalError>>;
}

/// Implemented for all "connector" for to *any* destination, including the
/// ProtonAPI.
///
/// By definition, this is a super trait of [ProtonConnectTransport].
///
/// This provides a way to get a [`Sender`](SendRequest) for the desired
/// destination.
pub trait ConnectTransport<Req, Res>: HasSleepCapabilities + HasRandCapabilities {
    type Sender: SendRequest<Req, Res, Err = InternalError> + Clone;
    fn connect(
        &self,
        server: &Server,
        upgrader: MuonUpgrader,
    ) -> impl std::future::Future<Output = Result<BoundSender<Self::Sender>, InternalError>>;
}
