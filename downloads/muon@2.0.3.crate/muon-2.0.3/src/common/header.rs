use crate::app::{AppVersion, UserAgent};
use crate::http::{AsHeader, HttpRes};
use std::borrow::Borrow;
use std::time::Duration;

/// A content type header.
#[derive(Debug)]
pub struct ContentType<T: AsRef<str>>(pub T);

impl ContentType<&'static str> {
    /// The `application/dns-message` content type.
    pub const DNS: Self = Self("application/dns-message");
    /// The `application/x-www-form-urlencoded` content type.
    pub const FORM: Self = Self("application/x-www-form-urlencoded");
    /// The `application/json` content type.
    pub const JSON: Self = Self("application/json");
}

impl<T: AsRef<str>> AsHeader for ContentType<T> {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("content-type".into(), self.0.as_ref().to_owned())]
    }
}

/// An accept header.
#[derive(Debug)]
pub struct Accept<T: AsRef<str>>(pub T);

impl Accept<&'static str> {
    /// The `application/dns-message` accept header.
    pub const DNS: Self = Self("application/dns-message");
    /// The `application/json` accept header.
    pub const JSON: Self = Self("application/json");
}

impl<T: AsRef<str>> AsHeader for Accept<T> {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("accept".into(), self.0.as_ref().to_owned())]
    }
}

/// The user agent header.
#[derive(Debug)]
pub struct UserAgentHeader(String);

impl UserAgentHeader {
    /// Create a new user agent header.
    pub fn new(value: impl Borrow<UserAgent>) -> Self {
        Self(value.borrow().to_string())
    }
}

impl AsHeader for UserAgentHeader {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("user-agent".to_owned(), self.0.clone())]
    }
}

/// The `x-pm-appversion` header.
#[derive(Debug)]
pub struct AppVersionHeader(String);

impl AppVersionHeader {
    /// Create a new app version header.
    pub fn new(value: impl Borrow<AppVersion>) -> Self {
        Self(value.borrow().to_string())
    }
}

impl AsHeader for AppVersionHeader {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("x-pm-appversion".to_owned(), self.0.clone())]
    }
}

/// The `x-pm-uid` header.
#[derive(Debug)]
pub struct AuthUidHeader(String);

impl AuthUidHeader {
    /// Create a new auth UID header.
    pub fn new(value: impl AsRef<str>) -> Self {
        Self(value.as_ref().to_owned())
    }
}

impl AsHeader for AuthUidHeader {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("x-pm-uid".to_owned(), self.0.clone())]
    }
}

/// The `authorization` header.
#[derive(Debug)]
pub struct AuthTokenHeader(String);

impl AuthTokenHeader {
    /// Create a new auth token header.
    pub fn new(value: impl AsRef<str>) -> Self {
        Self(value.as_ref().to_owned())
    }
}

impl AsHeader for AuthTokenHeader {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("authorization".to_owned(), bearer(&self.0))]
    }
}

/// The `x-pm-doh-host` header.
#[derive(Debug)]
pub struct DohHostHeader(String);

impl DohHostHeader {
    /// Create a new DOH host header.
    pub fn new(value: impl AsRef<str>) -> Self {
        Self(value.as_ref().to_owned())
    }
}

impl AsHeader for DohHostHeader {
    fn as_header(&self) -> impl IntoIterator<Item = (String, String)> {
        [("x-pm-doh-host".to_owned(), self.0.clone())]
    }
}

fn bearer(tok: &str) -> String {
    format!("Bearer {tok}")
}

pub(crate) trait RetryAfter: Borrow<HttpRes> {
    fn retry_after(&self) -> Duration {
        self.borrow()
            .headers()
            .get("retry-after")
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.parse().ok())
            .map(Duration::from_secs)
            .unwrap_or(Duration::ZERO)
    }
}

impl<This: Borrow<HttpRes>> RetryAfter for This {}
