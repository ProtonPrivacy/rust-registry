use crate::common::{AppVersionHeader, DohHostHeader, Host, SendRequest, UserAgentHeader};
use crate::{App, InternalError, ProtonRequest, ProtonResponse};
use data_encoding::BASE32_NOPAD;

#[derive(Debug)]
pub struct SetHeaders<'a, S: SendRequest<ProtonRequest, ProtonResponse>> {
    pub sender: S,
    pub app: &'a App,
    pub host: Host,
    pub default_headers: &'a Vec<(String, String)>,
}
impl<'a, Sender: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>>
    SendRequest<ProtonRequest, ProtonResponse> for SetHeaders<'a, Sender>
{
    type Err = Sender::Err;

    async fn send(&self, req: ProtonRequest) -> crate::Result<ProtonResponse, Self::Err> {
        let mut req = req
            .header(AppVersionHeader::new(self.app.app_version()))
            .header(UserAgentHeader::new(self.app.user_agent()))
            .header(self.default_headers);

        if let Host::Indirect(host) = &self.host {
            let direct_host: String = host
                .strip_prefix("d")
                .and_then(|s| s.strip_suffix(".protonpro.xyz"))
                .and_then(|s| BASE32_NOPAD.decode(s.as_bytes()).ok()?.try_into().ok())
                .ok_or(InternalError::irrecoverable(crate::ErrorKind::send(
                    "wrong indirect host format",
                )))?;

            req = req.header(DohHostHeader::new(direct_host));
        }

        self.sender.send(req).await
    }
}

#[cfg(feature = "testing-recorder")]
#[derive(Debug)]
pub struct Recorder<S: SendRequest<ProtonRequest, ProtonResponse>> {
    pub sender: S,
    pub recorder: Option<std::sync::mpsc::Sender<ProtonRequest>>,
}

#[cfg(feature = "testing-recorder")]
impl<Sender: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>>
    SendRequest<ProtonRequest, ProtonResponse> for Recorder<Sender>
{
    type Err = Sender::Err;

    async fn send(&self, req: ProtonRequest) -> crate::Result<ProtonResponse, Self::Err> {
        let _ = self
            .recorder
            .as_ref()
            .map(|sender| sender.send(req.clone()));
        self.sender.send(req).await
    }
}
