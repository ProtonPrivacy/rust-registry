#[cfg(feature = "testing-recorder")]
use crate::common::sender::middleware::Recorder;
use crate::common::sender::middleware::SetHeaders;
use crate::common::{AuthSender, ConnectTransport, PooledSender, RetryHandler, SendRequest};
use crate::{Context, InternalError, ProtonRequest, ProtonResponse};
use proton_os_interface::rand::DeriveRng as _;
use rand_chacha::ChaCha8Rng;

type PooledSenderOfContext<C> = PooledSender<
    <<C as Context>::TransportConnector as ConnectTransport<ProtonRequest, ProtonResponse>>::Sender,
>;

#[cfg(not(feature = "testing-recorder"))]
type FullSender<'a, C> = AuthSender<'a, SetHeaders<'a, RetryHandler<'a, C>>, C>;
#[cfg(feature = "testing-recorder")]
type FullSender<'a, C> = AuthSender<'a, SetHeaders<'a, Recorder<RetryHandler<'a, C>>>, C>;

/// A sender for Muon.
///
/// This enforces the x-pm-appversion, user agent, kill-switch protection,
/// unauth session, token refresh, etc.
///
/// This is what should be used for _all_ ProtonAPI requests
pub(crate) struct MuonSender<'a, C: Context> {
    sender: FullSender<'a, C>,
}

impl<'a, C: Context> SendRequest<ProtonRequest, ProtonResponse> for MuonSender<'a, C> {
    type Err = InternalError;

    async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, Self::Err> {
        self.sender.send(req).await
    }
}

impl<'a, C: Context> MuonSender<'a, C> {
    pub fn new(
        pooled_sender: &'a PooledSenderOfContext<C>,
        client: &'a crate::Client<C>,
        session_key: &'a C::SessionKey,
    ) -> MuonSender<'a, C> {
        let rng = client.get_prng().derive::<ChaCha8Rng>();

        // handle 429, 5xx, kill-switch, retries
        let sender = RetryHandler::<C> {
            sender: pooled_sender,
            sleeper: client.sleeper().to_owned(),
            rng: rng.into(),
            probe_emitter: client.session_event_sender(session_key.clone()),
            default_retry_policy: client.default_retry_policy(),
        };

        #[cfg(feature = "testing-recorder")]
        let sender = Recorder {
            sender,
            recorder: client.get_recorder(),
        };

        // Set headers (x-pm-appversion, user-agent, x-pm-doh-host (if AR))
        let host = pooled_sender.host().to_owned();
        let sender = SetHeaders {
            sender: sender,
            app: client.app(),
            host,
            default_headers: client.default_headers(),
        };

        // handle auth-refresh, unauth sessions, authenticated calls, etc.
        let sender = AuthSender {
            sender,
            client,
            session_key,
        };

        Self { sender }
    }

    pub async fn force_refresh(&self) -> Result<(), InternalError> {
        self.sender.force_refresh().await
    }
}
