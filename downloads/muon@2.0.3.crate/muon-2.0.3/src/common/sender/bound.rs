use crate::common::SendRequest;
use crate::{ProtonRequest, ProtonResponse};
use derive_more::From;
use url::Url;

/// A Sender that is bound to a base.
#[derive(From)]
pub struct BoundSender<Sender> {
    http_sender: Sender,
    base: Url,
}

impl<Sender> std::fmt::Debug for BoundSender<Sender> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("BoundSender")
            .field("base", &self.base)
            .finish()
    }
}

impl<Sender: Clone> Clone for BoundSender<Sender> {
    fn clone(&self) -> Self {
        Self {
            http_sender: self.http_sender.clone(),
            base: self.base.clone(),
        }
    }
}

impl<Sender> BoundSender<Sender> {
    pub fn new(http_sender: Sender, base: Url) -> Self {
        Self { http_sender, base }
    }

    #[allow(unused)]
    pub(crate) fn get_unbounded(&self) -> &Sender {
        &self.http_sender
    }
}

impl<Sender: SendRequest<ProtonRequest, ProtonResponse>> SendRequest<ProtonRequest, ProtonResponse>
    for BoundSender<Sender>
{
    async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, Self::Err> {
        let req = req.uri(&self.base);
        self.http_sender.send(req).await
    }

    type Err = Sender::Err;
}
