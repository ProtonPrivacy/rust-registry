//! ## Sender
//!
//! A sender is something that can send requests and receive responses.
//! This module provides the `Sender` trait, which is implemented by types that
//! can send requests.

use crate::{ProtonRequest, ProtonResponse, Result};

pub(crate) mod bound;
pub(crate) use bound::BoundSender;
mod middleware;
pub(crate) mod muon;
pub(crate) use muon::MuonSender;

/// A type capable of sending requests.
pub trait SendRequest<Req, Res> {
    type Err: core::error::Error + Send;
    /// Send the given request and return the response.
    fn send(&self, req: Req) -> impl Future<Output = Result<Res, Self::Err>>;
}

impl ProtonRequest {
    pub async fn send_with<T>(self, sender: &T) -> Result<ProtonResponse, T::Err>
    where
        T: SendRequest<ProtonRequest, ProtonResponse>,
    {
        sender.send(self).await
    }
}
