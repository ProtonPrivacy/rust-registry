//! Probe to Muon internals.
//!
//! Allows to receive notifications to various events happening inside of the
//! library that would be silenced by it.
//!
//! Public interface is:
//! - [`SessionEvent`] / [`Event`] ([`InformationalEvent`]/[`ActionableEvent`])
//! - [`SessionEventReceiver`] and its error [`ReceiverDisconnected`]
//!
//! [`ActionableEvent`]'s feedback _MUST_ be returned via a
//! [`futures::channel::oneshot::Sender`].

use derive_more::From;
use std::sync::mpsc::TryRecvError;
use tracing::warn;

/// A notification about an [`Event`] for a given session.
#[must_use]
#[derive(Debug, PartialEq, Eq)]
pub struct SessionEvent<SessionKey> {
    key: SessionKey,
    event: Event,
}

impl<SK> SessionEvent<SK> {
    /// unpack this structure into its part
    pub fn into_parts(self) -> (SK, Event) {
        (self.key, self.event)
    }

    /// The session key that faced the [`Event`]
    pub fn session_key(&self) -> &SK {
        &self.key
    }

    /// The event that has been seen
    pub fn event(&self) -> &Event {
        &self.event
    }
}

/// The events you may be notified by.
///
/// These events may require an action from the
#[must_use]
#[derive(Debug, PartialEq, Eq, From)]
pub enum Event {
    /// The session has been rate-limited
    Informational(InformationalEvent),
    /// An event that require some actions to be performed
    ActionRequired(ActionableEvent),
}

/// An informational event that does not require any action
#[non_exhaustive]
#[must_use]
#[derive(Debug, PartialEq, Eq)]
pub enum InformationalEvent {
    /// The session has been rate-limited
    RateLimited,
    /// A request received an internal server error
    InternalServerError,
}

/// An event that require an action from your side.
///
/// The result of the action will be returned via a
/// [`futures::channel::oneshot::Sender`].
#[non_exhaustive]
#[must_use]
#[derive(Debug)]
pub enum ActionableEvent {
    // HumanVerification(HumanVerificationData),
    // tbd
    #[cfg(test)]
    /// An example of actionable event for test only
    ActionableExample(tests::ActionableExampleData),
}

impl PartialEq for ActionableEvent {
    fn eq(&self, other: &Self) -> bool {
        std::mem::discriminant(self) == std::mem::discriminant(other)
    }
}

impl Eq for ActionableEvent {}

/// The channel you will receive your [`SessionEvents`](SessionEvent) on.
///
/// This channel *MUST* be drained otherwise notifications will stop coming
/// after reaching the channel capacity.
pub struct SessionEventReceiver<SK> {
    receiver: std::sync::mpsc::Receiver<SessionEvent<SK>>,
    event_filter: Box<dyn Fn(Event) -> Option<Event> + Send>,
}

impl<SK> SessionEventReceiver<SK> {
    pub(crate) fn new(
        receiver: std::sync::mpsc::Receiver<SessionEvent<SK>>,
        data_filter: impl Fn(Event) -> Option<Event> + Send + 'static,
    ) -> Self {
        Self {
            receiver,
            event_filter: Box::new(data_filter),
        }
    }

    /// Block to receive a [`SessionEvent`] about an [`Event`]
    ///
    /// The received [`Events`](Event) are filtered using the callback provided
    /// on creation.
    ///
    /// # Error
    /// If the sender has been disconnected (i.e., you recreated one through
    /// [`Client::get_notification_receiver`](`crate::Client::get_notification_receiver`)) [`ListenerDisconnected`]
    /// error is raised, indicating that you _MUST_ drop this receiver.
    pub fn recv(&self) -> Result<SessionEvent<SK>, ReceiverDisconnected> {
        loop {
            let mut event = self.receiver.recv().map_err(|_| ReceiverDisconnected)?;
            if let Some(data) = (self.event_filter)(event.event) {
                event.event = data;
                return Ok(event);
            }
        }
    }

    /// Receive a [`SessionEvent`] about an [`Event`]. This function is not
    /// blocking and return `Ok(None)` if the channel is empty instead of
    /// blocking.
    ///
    /// # Errors
    /// See [Self::recv]
    pub fn try_recv(&self) -> Result<Option<SessionEvent<SK>>, ReceiverDisconnected> {
        loop {
            let mut event = match self.receiver.try_recv() {
                Ok(e) => e,
                Err(TryRecvError::Empty) => return Ok(None),
                Err(TryRecvError::Disconnected) => return Err(ReceiverDisconnected),
            };

            if let Some(data) = (self.event_filter)(event.event) {
                event.event = data;
                return Ok(Some(event));
            }
        }
    }
}

impl<SK> Iterator for SessionEventReceiver<SK> {
    type Item = SessionEvent<SK>;

    fn next(&mut self) -> Option<Self::Item> {
        self.recv().ok()
    }
}

#[derive(Debug, PartialEq, Eq, thiserror::Error)]
#[error("this receiver has been replaced and is now disconnected.")]
pub struct ReceiverDisconnected;

pub(crate) type Sender<SK> = std::sync::mpsc::SyncSender<SessionEvent<SK>>;

/// A type that creates [`SessionEventSender`] tied to [`SessionEventReceiver`]
#[derive(Debug)]
pub(crate) struct SessionEventSenderFactory<SK>(Option<Sender<SK>>);

impl<SK> SessionEventSenderFactory<SK> {
    /// A new factory that creates senders that do not send any notification
    pub(crate) fn blackholed() -> Self {
        Self(Default::default())
    }

    /// A new factory that creates senders that actually sends notification
    pub(crate) fn new(
        data_filter: impl Fn(Event) -> Option<Event> + Send + 'static,
    ) -> (Self, SessionEventReceiver<SK>) {
        let (sender, receiver) = std::sync::mpsc::sync_channel(10);

        (
            Self(Some(sender)),
            SessionEventReceiver::new(receiver, data_filter),
        )
    }
}

impl<SK> Clone for SessionEventSenderFactory<SK> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}

impl<SK> SessionEventSenderFactory<SK> {
    pub(crate) fn new_session_event_sender(&self, session_key: SK) -> SessionEventSender<SK> {
        SessionEventSender {
            session_key,
            emitter: self.clone(),
        }
    }
}

/// A type that sends [`SessionEvent`] to a [`SessionEventReceiver`]
pub(crate) struct SessionEventSender<SK> {
    session_key: SK,
    emitter: SessionEventSenderFactory<SK>,
}

impl<SK: Clone> SessionEventSender<SK> {
    pub(crate) fn send(&self, event: impl Into<Event>)
    where
        SK: Clone,
    {
        if let Some(emitter) = self.emitter.0.as_ref() {
            let event = event.into();
            let _ = emitter
                .try_send(SessionEvent {
                    key: self.session_key.clone(),
                    event,
                })
                .inspect_err(|err| warn!(%err, "failing to emit Probe"));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use futures::channel::oneshot::Canceled;

    #[derive(Debug, From)]
    /// An example of actionable event for test only
    pub struct ActionableExampleData(futures::channel::oneshot::Sender<()>);

    #[test]
    fn send_notification() {
        // receive everything
        let (sender_factory, receiver) = SessionEventSenderFactory::<()>::new(|event| Some(event));

        let session_event_sender = sender_factory.new_session_event_sender(());

        session_event_sender.send(InformationalEvent::RateLimited);

        assert_eq!(
            receiver.try_recv(),
            Ok(Some(SessionEvent {
                key: (),
                event: InformationalEvent::RateLimited.into()
            }))
        )
    }

    #[tokio::test]
    async fn actional_action_feedback() {
        // receive all actionables, discard informational
        let (sender_factory, receiver) =
            SessionEventSenderFactory::<()>::new(|event| match event {
                e @ Event::ActionRequired(ActionableEvent::ActionableExample(_)) => Some(e),
                _ => None,
            });

        let session_event_sender = sender_factory.new_session_event_sender(());

        let (s, r) = futures::channel::oneshot::channel();

        session_event_sender.send(ActionableEvent::ActionableExample(s.into()));

        let event = receiver
            .try_recv()
            .expect("channel is alive")
            .expect("contains an event");

        assert!(matches!(event.event(), Event::ActionRequired(_)));
        let (_, event) = event.into_parts();

        match event {
            Event::Informational(_) => unimplemented!(),
            Event::ActionRequired(ActionableEvent::ActionableExample(feedback_channel)) => {
                let _ = feedback_channel.0.send(());
            }
        }

        assert_eq!(r.await, Ok(()));

        session_event_sender.send(InformationalEvent::RateLimited);

        assert_eq!(receiver.try_recv(), Ok(None))
    }

    #[tokio::test]
    async fn actional_action_discarded() {
        // we discard everything
        let (sender_factory, receiver) =
            SessionEventSenderFactory::<()>::new(|event| match event {
                _ => None,
            });
        let session_event_sender = sender_factory.new_session_event_sender(());
        let (s, r) = futures::channel::oneshot::channel();
        session_event_sender.send(ActionableEvent::ActionableExample(s.into()));
        // this has been discarded
        assert!(receiver.try_recv().expect("channel is alive").is_none());
        // we get the canceled error has the actionable has been discarded
        assert_eq!(r.await, Err(Canceled));
    }

    #[test]
    fn channel_disconnection() {
        let (sender_factory, receiver) =
            SessionEventSenderFactory::<()>::new(|event| match event {
                e @ Event::Informational(_) => Some(e),
                _ => None,
            });
        drop(sender_factory);
        assert_eq!(receiver.try_recv(), Err(ReceiverDisconnected));
    }
}
