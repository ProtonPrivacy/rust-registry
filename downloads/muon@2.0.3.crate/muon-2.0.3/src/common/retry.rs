use crate::common::notification::{InformationalEvent, SessionEventSender};
use crate::common::{
    ContextSender, ContextSleeper, PooledSender, RetryAfter as _, RetryPolicy, SendRequest,
};
use crate::http::{HttpReq, HttpRes};
use crate::rt::Sleep;
use crate::{Context, InternalError, ProtonRequest, ProtonResponse, Result};
use derive_more::Debug;
use rand_chacha::ChaCha8Rng;
use tracing::{info, warn};

/// A layer that retries certain HTTP codes
#[must_use]
#[derive(Debug)]
pub struct RetryHandler<'a, C: Context> {
    pub(crate) sender: &'a PooledSender<ContextSender<C>>,
    pub(crate) probe_emitter: SessionEventSender<C::SessionKey>,
    pub(crate) default_retry_policy: RetryPolicy,
    #[debug(skip)]
    pub(crate) sleeper: ContextSleeper<C>,
    #[debug(skip)]
    pub(crate) rng: spin::Mutex<ChaCha8Rng>,
}

impl<'a, C: Context> SendRequest<ProtonRequest, ProtonResponse> for RetryHandler<'a, C> {
    type Err = InternalError;

    async fn send(&self, req: HttpReq) -> Result<HttpRes, Self::Err> {
        info!("sending with retry handling");

        let mut maybe_delay_generator = req
            .get_retry_policy()
            .unwrap_or(&self.default_retry_policy)
            .into_generator();

        loop {
            let maybe_next_delay = maybe_delay_generator.next(&mut self.rng.lock());
            match (self.sender.send(req.clone()).await, maybe_next_delay) {
                // 429 handler
                (Ok(res), Some(delay)) if res.is(429) => {
                    self.probe_emitter.send(InformationalEvent::RateLimited);
                    let delay = delay.max(res.retry_after());
                    warn!("rate limited, retrying after {delay:?}");
                    self.sleeper.sleep(delay).await;
                }

                // 5xx handler
                (Ok(res), Some(delay)) if res.status().is_server_error() => {
                    self.probe_emitter
                        .send(InformationalEvent::InternalServerError);
                    let delay = delay.max(res.retry_after());
                    warn!("got HTTP {}, retrying after {delay:?}", res.status());
                    self.sleeper.sleep(delay).await;
                }

                // Network error
                (Err(err), _) => return Err(err),

                (Ok(res), _) => return Ok(res),
            }
        }
    }
}
