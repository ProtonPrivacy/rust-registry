mod connector;
pub(crate) use connector::*;

mod net;
pub use net::*;

mod policy;
pub use policy::{RetryPolicy, *};

if_cfg! {
    #[cfg(not(target_family = "wasm"))], {
        mod proxy;
        pub use proxy::*;
    }
}

/// Notification from inside Muon
pub mod notification;

mod sender;
pub(crate) use sender::*;

mod timeout;
pub(crate) use timeout::*;

mod pool;
pub(crate) use pool::*;

mod header;
pub use header::*;

mod context;
pub use context::*;

mod auth;
pub use auth::*;

mod retry;
use crate::cfg::if_cfg;
pub use retry::*;

/// A boxed error type; the underlying error type is erased.
pub type BoxErr = Box<dyn core::error::Error + Send + Sync>;

/// The request type of muon
pub type ProtonRequest = crate::http::HttpReq;

/// The response type of muon
pub type ProtonResponse = crate::http::HttpRes;
