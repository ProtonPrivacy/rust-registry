use crate::common::{
    BoundSender, ConnectTransport, ProtonConnectTransport, ProtonRequest, ProtonResponse,
    SendRequest, Server,
};
use crate::fingerprint::NoInfo;
use crate::rt::{HasRandCapabilities, HasSleepCapabilities, MuonInstant, Sleep};
use crate::sessions::SessionKeyable;
use crate::store::{Store, WithoutPersistence};
use crate::tls::upgrader::MuonUpgrader;
use crate::{InternalError, ProvideInformation, Result};
use proton_os_interface::time::InstantFactory;
use rand_chacha::ChaCha20Rng;
use std::marker::PhantomData;
use std::pin::Pin;

/// The Muon client context.
///
/// Specifies the mandatory types used by the client.
///
/// To be generic over Muon Session, use this kind of prototype:
/// ```ignore
/// async fn foo<K: SessionKeyable>(session: Session<impl Context<SessionKey=K>) {
///     todo()!
/// }
/// ```
pub trait Context {
    /// The session key for that muon client context
    type SessionKey: SessionKeyable;
    /// The transport for the Proton API being used
    type TransportConnector: ProtonConnectTransport<ProtonRequest, ProtonResponse>;
    /// The persistence storage type
    type Storage: Store<Key = Self::SessionKey>;
    /// The information (e.g., fingerprint) provider
    type InformationProvider: ProvideInformation;
}

/// A generic context across transport for type checking purposes
#[derive(Debug)]
pub struct GenericContext<T, S, InfoProvider>(
    PhantomData<T>,
    PhantomData<S>,
    PhantomData<InfoProvider>,
);

/// A context used as a stub. This does not allow any useful code, and should
/// not be exported.
#[derive(Debug)]
pub struct StubContext;

#[derive(Debug, Clone)]
pub struct StubSender;
impl SendRequest<ProtonRequest, ProtonResponse> for StubSender {
    async fn send(&self, _: ProtonRequest) -> crate::Result<ProtonResponse, Self::Err> {
        unimplemented!("void sender is meant to be used as a type system stub")
    }

    type Err = InternalError;
}

#[derive(Debug, Clone)]
pub struct StubSleeper;
// nosemgrep
unsafe impl crate::rt::Monotonic for StubSleeper {}
impl InstantFactory for StubSleeper {
    type Instant = MuonInstant;

    fn now(&self) -> Self::Instant {
        unimplemented!("void sleeper is meant to be used as a type system stub")
    }
}
impl Sleep for StubSleeper {
    type Sleep<'a>
        = Pin<Box<dyn Future<Output = ()>>>
    where
        Self: 'a;

    fn sleep(&self, _: core::time::Duration) -> Self::Sleep<'_> {
        unimplemented!("void sleeper is meant to be used as a type system stub")
    }
}

#[derive(Debug, Clone)]
pub struct StubTransport;

impl HasSleepCapabilities for StubTransport {
    type Sleeper = StubSleeper;

    fn get_sleep_capability(&self) -> &Self::Sleeper {
        unimplemented!("void StubTransport is meant to be used as a type system stub")
    }
}

impl HasRandCapabilities for StubTransport {
    type Rng = ChaCha20Rng;

    fn get_prng(&self) -> Self::Rng {
        unimplemented!("void StubTransport is meant to be used as a type system stub")
    }
}

impl ProtonConnectTransport<ProtonRequest, ProtonResponse> for StubTransport {
    async fn connect(&self, _: &Server) -> Result<BoundSender<Self::Sender>, InternalError> {
        unimplemented!("void StubTransport is meant to be used as a type system stub")
    }
}

impl ConnectTransport<ProtonRequest, ProtonResponse> for StubTransport {
    type Sender = StubSender;

    async fn connect(
        &self,
        _: &Server,
        _: MuonUpgrader<'_>,
    ) -> Result<BoundSender<Self::Sender>, InternalError> {
        unimplemented!("void StubTransport is meant to be used as a type system stub")
    }
}

impl Context for StubContext {
    type SessionKey = ();
    type Storage = WithoutPersistence<Self::SessionKey>;
    type TransportConnector = StubTransport;
    type InformationProvider = NoInfo;
}

/// Alias to get the Sender of the current Muon context
#[allow(type_alias_bounds)]
pub(crate) type ContextSender<C: Context> =
    <C::TransportConnector as ConnectTransport<ProtonRequest, ProtonResponse>>::Sender;

/// Alias to get the Sleeper of the current Muon context
#[allow(type_alias_bounds)]
pub(crate) type ContextSleeper<C: Context> =
    <C::TransportConnector as HasSleepCapabilities>::Sleeper;
