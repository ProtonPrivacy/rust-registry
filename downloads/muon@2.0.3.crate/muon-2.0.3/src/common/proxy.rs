//! ## Proxy
//!
//! This module defines types and traits by which a client can determine the
//! proxy to use for a given endpoint.

use crate::common::Endpoint;
use derive_more::From;

/// A proxy for the muon client.
///
/// Outside of the CI, no proxy can be selected.
#[derive(Debug, From)]
pub enum Proxy {
    NoProxy,
    Env(EnvProxy),
}

impl Proxy {
    #[allow(unused)]
    pub(crate) fn proxy(&self, _endpoint: &Endpoint) -> Option<Endpoint> {
        match self {
            Proxy::NoProxy => None,
            Proxy::Env(proxy) => proxy.proxy(_endpoint),
        }
    }
}

/// A proxy provider that looks for a proxy in an environment variable.
/// Depending on the variant, it will apply the proxy to all hosts, only direct
/// hosts, or only indirect hosts.
#[derive(Debug)]
pub struct EnvProxy {
    _var: std::ffi::OsString,
    _scope: EnvProxyScope,
}

#[allow(unused)]
#[derive(Debug)]
enum EnvProxyScope {
    All,
    Loopback,
    External,
}

impl EnvProxy {
    fn new(var: impl AsRef<std::ffi::OsStr>, scope: EnvProxyScope) -> Self {
        let var = var.as_ref().to_owned();

        Self {
            _var: var,
            _scope: scope,
        }
    }

    /// Create a new environment variable proxy provider for any host.
    #[must_use]
    pub fn all(var: impl AsRef<std::ffi::OsStr>) -> Self {
        Self::new(var, EnvProxyScope::All)
    }

    /// Create a new environment variable proxy provider for loopback hosts.
    #[must_use]
    pub fn loopback(var: impl AsRef<std::ffi::OsStr>) -> Self {
        Self::new(var, EnvProxyScope::Loopback)
    }

    /// Create a new environment variable proxy provider for external hosts.
    #[must_use]
    pub fn external(var: impl AsRef<std::ffi::OsStr>) -> Self {
        Self::new(var, EnvProxyScope::External)
    }

    fn proxy_env(&self) -> Option<Endpoint> {
        (std::env::var(&self._var).ok())
            .and_then(|var| crate::util::url!("{var}").ok())
            .and_then(|url| url.try_into().ok())
    }

    fn proxy_loopback(&self, name: &crate::common::Name) -> Option<Endpoint> {
        if name.is_loopback() {
            self.proxy_env()
        } else {
            None
        }
    }

    fn proxy_external(&self, name: &crate::common::Name) -> Option<Endpoint> {
        if name.is_loopback() {
            None
        } else {
            self.proxy_env()
        }
    }
}

impl EnvProxy {
    fn proxy(&self, endpoint: &Endpoint) -> Option<Endpoint> {
        match self._scope {
            EnvProxyScope::All => self.proxy_env(),
            EnvProxyScope::Loopback => self.proxy_loopback(endpoint.name()),
            EnvProxyScope::External => self.proxy_external(endpoint.name()),
        }
    }
}
