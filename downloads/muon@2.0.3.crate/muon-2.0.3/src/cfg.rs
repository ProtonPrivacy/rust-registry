#[doc(hidden)]
macro_rules! if_cfg {
    (#[$($mm:tt)*], $tt:tt else $($ff:tt)*) => {
        cfg_if::cfg_if! {
            if #[$($mm)*] {
                $crate::cfg::__unwrap! { $tt }
            } else {
                $crate::cfg::__unwrap! { $($ff)* }
            }
        }
    };

    (#[$($mm:tt)*], $($tt:tt)*) => {
        cfg_if::cfg_if! {
            if #[$($mm)*] {
                $crate::cfg::__unwrap! { $($tt)* }
            }
        }
    };
}

pub(crate) use if_cfg;

#[doc(hidden)]
macro_rules! __unwrap {
    ({ $($tt:tt)* }) => {
        $crate::cfg::__unwrap! { $($tt)* }
    };

    ($($tt:tt)*) => {
        $($tt)*
    };
}
pub(crate) use __unwrap;
