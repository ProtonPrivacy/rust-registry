/// Define what is an Proton application
pub mod app;
pub use app::App;

#[cfg(feature = "transport-hyper")]
mod alternative_routing;

/// Implementation shared amongst transports
pub mod common;
pub use common::{Context, ProtonRequest, ProtonResponse};

/// Implementation of the muon Client managing multiple sessions
pub mod client;
pub use client::Client;

/// Define the authentication types and flows
pub mod auth;

/// Definition of DoH services
#[cfg(feature = "transport-hyper")]
pub mod doh;

/// Define the TLS related types
pub mod tls;

/// How to deal with a single session
pub mod sessions;
pub use sessions::{Session, SessionCredentials, SessionKeyable};

/// Proton Environment related types
pub mod env;
pub use env::Environment;

/// Public error types
pub mod error;
pub(crate) use error::InternalError;
pub use error::{Error, ErrorKind, Result};

/// tranport-protocol related types
pub mod transport;
pub use transport::http;

/// Device fingerprint tools
mod fingerprint;
pub use fingerprint::{Fingerprint, NoInfo, ProvideInformation};

/// Rest API types
pub mod rest;
/// Runtime specification traits
pub mod rt;
/// SSO tools
pub mod store;
/// Nice to have utils
pub mod util;

mod internal {
    pub trait Sealed {}
}
pub(crate) use internal::*;

#[cfg(feature = "unsealed")]
impl<T> Sealed for T {}

#[cfg(any(test, feature = "testing"))]
pub mod tests;

/// Random traits (re-export of proton-os-interface)
pub use proton_os_interface::rand;
/// Json utils (re-export of serde_json)
pub use serde_json as json;

mod cfg;
