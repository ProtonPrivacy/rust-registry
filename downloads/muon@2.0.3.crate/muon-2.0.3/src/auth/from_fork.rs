use crate::auth::{Auth, FlowErr, Tokens, UserIdErr};
use crate::common::Context;
use crate::http::{GET, Status};
use crate::rest::auth;
use crate::sessions::{Session, SessionCredentials};
use crate::util::ByteSliceExt;
use tracing::info;

/// A flow for acquiring a fork.
#[must_use]
#[derive(Debug)]
pub struct FromForkFlow<C: Context> {
    session: Session<C>,
}

impl<C: Context> FromForkFlow<C> {
    pub(super) fn new(session: Session<C>) -> Self {
        Self { session }
    }
}
impl<C: Context> FromForkFlow<C> {
    /// Acquire the fork with the given selector.
    ///
    /// The selector is a unique identifier for the fork.
    pub async fn with_selector(self, selector: impl AsRef<str>) -> WithSelectorFlow<C> {
        WithSelectorFlow::new(self.session, selector.as_ref()).await
    }

    /// Acquire the fork from a user code.
    pub async fn with_code(self) -> WithCodeFlow<C> {
        WithCodeFlow::new(self.session).await
    }
}

/// A flow for a fork with a selector.
#[must_use]
#[derive(Debug)]
pub enum WithSelectorFlow<C: Context> {
    /// The flow is complete; the session is returned, along with any payload.
    Ok(Session<C>, Option<Vec<u8>>),
    /// The login via selector couldn't proceed
    Failed {
        /// The child originating the login via selector
        session: Session<C>,
        /// The reason why it did not succeed
        reason: FlowErr,
    },
}

impl<C: Context> WithSelectorFlow<C> {
    async fn new(session: Session<C>, selector: &str) -> Self {
        info!(%selector, "acquiring forked session");
        let req = GET!("/auth/v4/sessions/forks/{selector}");
        let res = return_variant_on_error!(session.send(req).await, session, Self::Failed);
        let res = return_variant_on_error!(res.ok(), session, Self::Failed);
        let res: auth::v4::sessions::forks::GetIdRes =
            return_variant_on_error!(res.into_body_json(), session, Self::Failed);

        let auth = SessionCredentials(res.auth);
        let auth_uid = auth.uid().to_owned();

        // Get the ID of the user that logged in.
        let Some(user_id) = auth.user_id().map(str::to_owned) else {
            return Self::Failed {
                session,
                reason: UserIdErr.into(),
            };
        };

        // Build new access tokens from the fork.
        let tok: Tokens = auth.into();

        info!(uid = %auth_uid, "building new auth object");
        let auth = Auth::internal(user_id, auth_uid, tok);

        info!(%auth, "auth complete, storing tokens");
        session.set_auth(auth).await;

        let payload = return_variant_on_error!(
            (res.payload).map(|p| p.b64_into()).transpose(),
            session,
            Self::Failed
        );

        Self::Ok(session, payload)
    }
}

/// A flow for a fork with a user code.
#[must_use]
#[derive(Debug)]
pub enum WithCodeFlow<C: Context> {
    /// Poll the fork for completion.
    Poll(WithCodePollFlow<C>),

    /// The flow is complete; the session is returned.
    Ok(Session<C>, Option<Vec<u8>>),

    /// The flow couldn't complete; the session is returned unlogged
    Failed {
        /// The session that failed to log via a code flow
        session: Session<C>,
        /// The reason why this login method failed
        reason: FlowErr,
    },
}

impl<C: Context> WithCodeFlow<C> {
    async fn new(session: Session<C>) -> Self {
        // Generate a new random human-readable code.
        let req = GET!("/auth/v4/sessions/forks");
        let res = return_variant_on_error!(session.send(req).await, session, Self::Failed);
        let res = return_variant_on_error!(res.ok(), session, Self::Failed);
        let res: auth::v4::sessions::forks::GetRes =
            return_variant_on_error!(res.into_body_json(), session, Self::Failed);

        // The selector should be used to poll, the code returned to the user.
        let selector = res.selector;
        let code = res.code;

        Self::Poll(WithCodePollFlow {
            session,
            selector,
            code,
        })
    }
}

/// A flow for polling a fork with a user code.
#[must_use]
#[derive(Debug)]
pub struct WithCodePollFlow<C: Context> {
    session: Session<C>,
    selector: String,
    code: String,
}

impl<C: Context> WithCodePollFlow<C> {
    /// Return the user code used for the fork process
    pub fn code(&self) -> &str {
        &self.code
    }

    /// Poll the fork for completion.
    pub async fn poll(self) -> WithCodeFlow<C> {
        info!(selector = %self.selector, "polling forked session");
        let req = GET!("/auth/v4/sessions/forks/{}", self.selector);
        let res = return_variant_on_error!(
            self.session.send(req).await,
            self.session,
            WithCodeFlow::Failed
        );

        // If the fork is not yet complete, return a poll flow.
        let res: auth::v4::sessions::forks::GetIdRes = if res.is(Status::UNPROCESSABLE_ENTITY) {
            return WithCodeFlow::Poll(self);
        } else {
            return_variant_on_error!(res.into_body_json(), self.session, WithCodeFlow::Failed)
        };
        let auth = SessionCredentials(res.auth);
        // Get the ID of the user that logged in.
        let Some(user_id) = auth.user_id().map(str::to_owned) else {
            return WithCodeFlow::Failed {
                session: self.session,
                reason: UserIdErr.into(),
            };
        };

        let uid = auth.uid().to_owned();

        // Build new access tokens from the fork.
        let tok: Tokens = auth.into();

        info!(uid = %uid, "building new auth object");
        let auth = Auth::internal(user_id, uid, tok);

        info!(%auth, "fork complete, storing tokens");
        self.session.set_auth(auth).await;

        let payload = return_variant_on_error!(
            (res.payload).map(|p| p.b64_into()).transpose(),
            self.session,
            WithCodeFlow::Failed
        );

        WithCodeFlow::Ok(self.session, payload)
    }
}
