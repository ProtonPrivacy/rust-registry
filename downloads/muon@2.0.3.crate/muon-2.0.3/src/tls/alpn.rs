use crate::util::ByteSliceExt;
use derive_more::{Display, From, Into};
use http::Version;
use std::borrow::Borrow;
use std::fmt::Debug;

/// The HTTP2 Alpn identifier
const H2_ID: &[u8] = b"h2";
/// The HTTP 1.1 ALlpn identifier
const H1_ID: &[u8] = b"http/1.1";

/// H2 Alpn
#[allow(unused)]
pub(crate) const H2: Alpn = Alpn::new(H2_ID);
/// H1 Alpn
#[allow(unused)]
pub(crate) const H1: Alpn = Alpn::new(H1_ID);

/// An ALPN protocol.
#[derive(Debug, Display, From, Into, Clone, Copy, PartialEq, Eq, Hash)]
#[display("{}", self.0.as_utf8_lossy())]
pub struct Alpn(&'static [u8]);

impl Alpn {
    /// Create a new ALPN protocol from the given bytes.
    #[must_use]
    pub const fn new(alpn: &'static [u8]) -> Self {
        Self(alpn)
    }

    /// Create a new ALPN protocol from the given string.
    #[must_use]
    pub const fn new_str(alpn: &'static str) -> Self {
        Self(alpn.as_bytes())
    }
}

impl AsRef<[u8]> for Alpn {
    fn as_ref(&self) -> &[u8] {
        self.0
    }
}

impl std::ops::Deref for Alpn {
    type Target = [u8];

    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl Borrow<[u8]> for Alpn {
    fn borrow(&self) -> &[u8] {
        self.0
    }
}

impl From<Alpn> for Version {
    fn from(val: Alpn) -> Self {
        match val {
            Alpn(h1) if h1 == H1_ID => Version::HTTP_11,
            Alpn(h2) if h2 == H2_ID => Version::HTTP_2,
            _ => panic!("unsupported ALPN"),
        }
    }
}
