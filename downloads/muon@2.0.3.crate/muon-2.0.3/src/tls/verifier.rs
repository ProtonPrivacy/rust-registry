use super::certs::{TlsCert, TlsCertDer};
use crate::Result;
use crate::env::{Env, Environment};
use crate::tls::certs::ParseCert as _;
use crate::util::IntoIterExt as _;
use futures_rustls::pki_types::{CertificateDer, ServerName, UnixTime};
use futures_rustls::rustls::CertificateError::{ApplicationVerificationFailure, BadEncoding};
use futures_rustls::rustls::client::WebPkiServerVerifier;
use futures_rustls::rustls::client::danger::{
    HandshakeSignatureValid, ServerCertVerified, ServerCertVerifier,
};
use futures_rustls::rustls::{DigitallySignedStruct, Error, SignatureScheme, crypto};
use std::fmt::Debug;
use std::sync::Arc;

/// The result of a certificate verification.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum VerifyRes {
    /// The verifier accepts the certificate.
    Accept,

    /// The verifier rejects the certificate.
    Reject,

    /// The verifier delegates verification to another verifier.
    Delegate,
}

impl Environment {
    fn verify_against_pins(&self, normal_routing: bool, leaf: &TlsCert) -> VerifyRes {
        let maybe_pins = if normal_routing {
            self.api_pins()
        } else {
            self.ar_pins()
        };

        match maybe_pins {
            Some(pins) if pins.contains(leaf) => VerifyRes::Accept,
            Some(_) => VerifyRes::Reject,

            None if matches!(self, Environment::Prod(_)) => {
                unreachable!("prod environment must use pinning")
            }
            None => VerifyRes::Delegate,
        }
    }
}

#[derive(Debug)]
enum CustomServerVerifier {
    #[allow(unused)]
    WithRoots(WebPkiServerVerifier),
    #[allow(unused)]
    AlwaysAccept,
}

impl ServerCertVerifier for CustomServerVerifier {
    fn verify_server_cert(
        &self,
        end_entity: &CertificateDer<'_>,
        intermediates: &[CertificateDer<'_>],
        server_name: &ServerName<'_>,
        ocsp_response: &[u8],
        now: UnixTime,
    ) -> std::result::Result<ServerCertVerified, Error> {
        match self {
            CustomServerVerifier::WithRoots(web_pki_server_verifier) => web_pki_server_verifier
                .verify_server_cert(end_entity, intermediates, server_name, ocsp_response, now),
            CustomServerVerifier::AlwaysAccept => Ok(ServerCertVerified::assertion()),
        }
    }

    fn verify_tls12_signature(
        &self,
        message: &[u8],
        cert: &CertificateDer<'_>,
        dss: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        match self {
            CustomServerVerifier::WithRoots(web_pki_server_verifier) => {
                web_pki_server_verifier.verify_tls12_signature(message, cert, dss)
            }
            CustomServerVerifier::AlwaysAccept => Ok(HandshakeSignatureValid::assertion()),
        }
    }

    fn verify_tls13_signature(
        &self,
        message: &[u8],
        cert: &CertificateDer<'_>,
        dss: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        match self {
            CustomServerVerifier::WithRoots(web_pki_server_verifier) => {
                web_pki_server_verifier.verify_tls13_signature(message, cert, dss)
            }
            CustomServerVerifier::AlwaysAccept => Ok(HandshakeSignatureValid::assertion()),
        }
    }

    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        match self {
            CustomServerVerifier::WithRoots(web_pki_server_verifier) => {
                web_pki_server_verifier.supported_verify_schemes()
            }
            CustomServerVerifier::AlwaysAccept => crypto::ring::default_provider()
                .signature_verification_algorithms
                .supported_schemes(),
        }
    }
}

#[derive(Debug)]
pub struct ProtonApiVerifier {
    /// Environment to check the pins against. This check takes precedence.
    environment: Arc<Environment>,
    /// Additional verifier (after the pinning is checked). This is used *only*
    /// if the environment has no pinning.
    ///
    /// Note: this is [`CustomServerVerifier::WithRoots`] if
    /// `dangerous-insecure-certificate` is disabled.
    ///
    /// Invariant of this are checked in [`audit_verifier`]
    additional_verifier: Arc<CustomServerVerifier>,
}

impl Clone for ProtonApiVerifier {
    fn clone(&self) -> Self {
        Self {
            environment: self.environment.clone(),
            additional_verifier: self.additional_verifier.clone(),
        }
    }
}

impl AsRef<CustomServerVerifier> for ProtonApiVerifier {
    fn as_ref(&self) -> &CustomServerVerifier {
        &self.additional_verifier
    }
}

fn build_additional_verifier<'a>(
    _maybe_roots: Option<impl IntoIterator<Item = &'a TlsCertDer>>,
) -> Arc<CustomServerVerifier> {
    #[cfg(feature = "dangerous-insecure-certificate")]
    return Arc::new(CustomServerVerifier::AlwaysAccept);

    #[cfg(not(feature = "dangerous-insecure-certificate"))]
    {
        use futures_rustls::rustls::RootCertStore;
        let mut store = RootCertStore::empty();
        store.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());

        if let Some(roots) = _maybe_roots {
            store.add_parsable_certificates(
                roots
                    .into_iter()
                    .map(|root| CertificateDer::from_slice(root)),
            );
        }

        let webpki = Arc::into_inner(
            WebPkiServerVerifier::builder_with_provider(
                Arc::new(store),
                Arc::new(crypto::ring::default_provider()),
            )
            .build()
            .expect("FATAL: failed to build webpki with provided roots"),
        ) // failed to parse provided roots is a fatal error
        .expect("FATAL: failed to take the arc inner"); // SAFETY: we just created the Arc, so we must be able to take the inner.

        Arc::new(CustomServerVerifier::WithRoots(webpki))
    }
}

#[inline(always)]
fn audit_verifier(_verifier: &ProtonApiVerifier) {
    #[cfg(not(feature = "dangerous-insecure-certificate"))]
    assert!(matches!(
        _verifier.as_ref(),
        &CustomServerVerifier::WithRoots(_)
    ),);
}

impl ProtonApiVerifier {
    pub fn new<'a>(
        environment: Arc<Environment>,
        maybe_additional_roots: Option<impl IntoIterator<Item = &'a TlsCertDer>>,
    ) -> Self {
        let this = Self {
            environment,
            additional_verifier: build_additional_verifier(maybe_additional_roots),
        };

        audit_verifier(&this);

        this
    }
}
#[derive(Debug)]
pub(crate) struct ProtonVerifierForHost {
    /// The host we are connecting to.
    normal_routing: bool,
    /// Pinning and maybe an additional verifier
    verifier: ProtonApiVerifier,
}

impl AsRef<CustomServerVerifier> for ProtonVerifierForHost {
    fn as_ref(&self) -> &CustomServerVerifier {
        self.verifier.as_ref()
    }
}

impl ProtonVerifierForHost {
    pub fn new(normal_routing: bool, verifier: ProtonApiVerifier) -> Self {
        Self {
            normal_routing,
            verifier,
        }
    }

    /// this does basic checks on all certificates + check for pinning
    fn verify_pinning(
        &self,
        leaf: &CertificateDer,
        rest: &[CertificateDer],
    ) -> Result<VerifyRes, Error> {
        let leaf = parse_der(leaf)?;
        let _ = rest.iter().map(parse_der).try_into_vec()?;
        Ok(self
            .verifier
            .environment
            .verify_against_pins(self.normal_routing, &leaf))
    }
}

impl ServerCertVerifier for ProtonVerifierForHost {
    fn verify_server_cert(
        &self,
        leaf: &CertificateDer,
        rest: &[CertificateDer],
        name: &ServerName,
        ocsp: &[u8],
        time: UnixTime,
    ) -> Result<ServerCertVerified, Error> {
        audit_verifier(&self.verifier);

        let pinning = self.verify_pinning(leaf, rest)?;

        match pinning {
            VerifyRes::Accept => Ok(ServerCertVerified::assertion()),
            VerifyRes::Reject => Err(ApplicationVerificationFailure)?,
            VerifyRes::Delegate => self
                .verifier
                .additional_verifier
                .verify_server_cert(leaf, rest, name, ocsp, time),
        }
    }

    fn verify_tls12_signature(
        &self,
        message: &[u8],
        cert: &CertificateDer,
        dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, Error> {
        audit_verifier(&self.verifier);

        let pinning = self.verify_pinning(cert, &[])?;

        match pinning {
            VerifyRes::Accept => Ok(HandshakeSignatureValid::assertion()),
            VerifyRes::Reject => Err(ApplicationVerificationFailure)?,
            VerifyRes::Delegate => self
                .verifier
                .additional_verifier
                .verify_tls12_signature(message, cert, dss),
        }
    }

    fn verify_tls13_signature(
        &self,
        message: &[u8],
        cert: &CertificateDer,
        dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, Error> {
        audit_verifier(&self.verifier);

        let pinning = self.verify_pinning(cert, &[])?;

        match pinning {
            VerifyRes::Accept => Ok(HandshakeSignatureValid::assertion()),
            VerifyRes::Reject => Err(ApplicationVerificationFailure)?,
            VerifyRes::Delegate => self
                .verifier
                .additional_verifier
                .verify_tls13_signature(message, cert, dss),
        }
    }

    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        audit_verifier(&self.verifier);
        self.verifier.additional_verifier.supported_verify_schemes()
    }
}

fn parse_der<'a>(cert: &'a CertificateDer<'a>) -> Result<TlsCert<'a>, Error> {
    cert.parse_der().map_err(|_| BadEncoding.into())
}
