use std::fmt::Debug;

/// A TLS upgrader either for the ProtonAPI (with pinning constraints applied)
/// or any other destination.
#[derive(Debug, Clone)]
pub enum MuonUpgrader<'a> {
    Proton(&'a ProtonApiTlsUpgrader),
    Other(&'a OtherUpgrader),
}

#[cfg(feature = "transport-hyper")]
mod tls_upgrade {
    use super::*;
    use crate::common::Name;
    use crate::tls::alpn::Alpn;
    use crate::tls::certs::TlsCertDer;
    use crate::tls::verifier::{ProtonApiVerifier, ProtonVerifierForHost};
    use crate::{ErrorKind, InternalError, Result};
    use futures::{AsyncRead, AsyncWrite};
    use futures_rustls::pki_types::CertificateDer;
    use futures_rustls::rustls::crypto::CryptoProvider;
    use futures_rustls::rustls::time_provider::TimeProvider;
    use futures_rustls::rustls::{ClientConfig, RootCertStore, crypto};
    use futures_rustls::{TlsConnector, TlsStream, client};
    use proton_os_interface::error::IntoSystemError;
    use proton_os_interface::time::{SinceEpoch, SinceUnixEpoch, SystemTimeFactory};
    use std::borrow::{Borrow, BorrowMut};
    use std::sync::Arc;
    use tracing::{error, trace};

    #[derive(Debug)]
    pub(crate) struct RustlsTimeCompat<T>(pub T);

    impl<T: SystemTimeFactory + Debug + Send + Sync> TimeProvider for RustlsTimeCompat<T>
    where
        T::SystemTime: SinceUnixEpoch,
    {
        fn current_time(&self) -> Option<futures_rustls::pki_types::UnixTime> {
            Some(futures_rustls::pki_types::UnixTime::since_unix_epoch(
                self.0.now().to_unix_epoch().duration_since_epoch(),
            ))
        }
    }

    trait TlsStreamExt<'a, IO: 'a>: Borrow<client::TlsStream<IO>> {
        /// Returns the ALPN protocol used, if any.
        fn have_alpn(&'a self) -> Option<&'a [u8]> {
            self.borrow().get_ref().1.alpn_protocol()
        }

        /// Returns which of the given ALPN protocols is used, if any.
        fn find_alpn(&'a self, alpn: &[Alpn]) -> Option<Alpn> {
            let want = self.have_alpn()?;

            alpn.iter().find(|alpn| alpn.as_ref() == want).copied()
        }
    }
    impl<'a, IO: 'a, T: Borrow<client::TlsStream<IO>>> TlsStreamExt<'a, IO> for T {}

    impl MuonUpgrader<'_> {
        pub async fn upgrade<IO: AsyncRead + AsyncWrite + Unpin>(
            &self,
            sock: IO,
            sni: &Name,
            alpn: &[Alpn],
        ) -> Result<(TlsStream<IO>, Option<Alpn>), InternalError> {
            match self {
                MuonUpgrader::Proton(upgrader) => upgrader
                    .upgrade(sock, sni, alpn)
                    .await
                    .inspect_err(|err| error!(%err, "failed to upgrader proton host {sni}")),
                MuonUpgrader::Other(upgrader) => upgrader
                    .upgrade(sock, sni, alpn)
                    .await
                    .inspect_err(|err| error!(%err, "failed to upgrader other host {sni}")),
            }
        }
    }

    /// A TLS upgrader for the Proton API
    #[derive(Debug, Clone)]
    pub struct ProtonApiTlsUpgrader {
        ver: ProtonApiVerifier,
        normal_routing: bool,
        system_time: Arc<dyn TimeProvider + 'static>,
    }

    impl ProtonApiTlsUpgrader {
        /// Create a new rustls-based upgrader from the given verifier and
        /// anchors.
        #[must_use]
        pub(crate) fn new<T>(normal_routing: bool, ver: ProtonApiVerifier, system_time: T) -> Self
        where
            RustlsTimeCompat<T>: TimeProvider + 'static,
        {
            Self {
                normal_routing,
                ver,
                system_time: Arc::new(RustlsTimeCompat(system_time)),
            }
        }

        pub async fn upgrade<IO: AsyncRead + AsyncWrite + Unpin>(
            &self,
            sock: IO,
            sni: &Name,
            alpn: &[Alpn],
        ) -> Result<(TlsStream<IO>, Option<Alpn>), InternalError> {
            let verifier: Arc<ProtonVerifierForHost> = Arc::new(ProtonVerifierForHost::new(
                self.normal_routing,
                self.ver.clone(),
            ));

            upgrade(sock, sni, alpn, |crypto| {
                let mut cfg = ClientConfig::builder_with_provider(crypto.into())
                    .with_safe_default_protocol_versions()
                    .map_err(ErrorKind::tls)?
                    .dangerous()
                    .with_custom_certificate_verifier(verifier)
                    .with_no_client_auth()
                    .with_alpn_protocols(alpn);
                cfg.time_provider = self.system_time.clone();

                Ok(cfg)
            })
            .await
        }
    }

    /// An upgrader for something else than the Proton API (e.g., DoH, Proxy,
    /// ...)
    #[derive(Debug, Clone)]
    pub struct OtherUpgrader(Arc<RootCertStore>);

    impl Default for OtherUpgrader {
        fn default() -> Self {
            Self(Self::default_roots().into())
        }
    }

    impl OtherUpgrader {
        fn default_roots() -> RootCertStore {
            let mut root_cert_store = RootCertStore::empty();
            root_cert_store.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
            root_cert_store
        }

        pub fn new_with_additional_roots(additional_roots: Vec<TlsCertDer>) -> Self {
            let mut roots = Self::default_roots();
            roots.add_parsable_certificates(
                additional_roots
                    .iter()
                    .map(|root| CertificateDer::from_slice(root)),
            );
            Self(roots.into())
        }

        pub async fn upgrade<IO: AsyncRead + AsyncWrite + Unpin>(
            &self,
            sock: IO,
            sni: &Name,
            alpn: &[Alpn],
        ) -> Result<(TlsStream<IO>, Option<Alpn>), InternalError> {
            upgrade(sock, sni, alpn, |crypto| {
                Ok(ClientConfig::builder_with_provider(crypto.into())
                    .with_safe_default_protocol_versions()
                    .map_err(ErrorKind::tls)?
                    .with_root_certificates(self.0.clone())
                    .with_no_client_auth())
            })
            .await
        }
    }

    #[cfg(not(feature = "unsealed"))]
    impl crate::Sealed for ProtonApiTlsUpgrader {}

    trait ClientConfigExt: Sized {
        fn with_alpn_protocols(mut self, alpn: &[Alpn]) -> Self
        where
            Self: BorrowMut<ClientConfig>,
        {
            let alpn = alpn.iter().map(|&s| s.to_vec());

            self.borrow_mut().alpn_protocols.extend(alpn);

            self
        }

        fn into_tls_connector(self) -> TlsConnector
        where
            Self: Into<ClientConfig>,
        {
            TlsConnector::from(Arc::new(self.into()))
        }
    }

    impl ClientConfigExt for ClientConfig {}

    async fn upgrade<IO: AsyncRead + AsyncWrite + Unpin>(
        sock: IO,
        sni: &Name,
        alpn: &[Alpn],
        get_tls_config: impl FnOnce(CryptoProvider) -> Result<ClientConfig, InternalError>,
    ) -> Result<(TlsStream<IO>, Option<Alpn>), InternalError> {
        trace!("building ring crypto provider for {sni}");

        let conf = get_tls_config(crypto::ring::default_provider().into())?;

        let conn = conf.into_tls_connector();

        trace!("performing TLS handshake with {sni:?}");
        let name = sni.to_string().try_into().map_err(ErrorKind::tls)?;

        let sock = conn
            .connect(name, sock)
            .await
            .map_err(|err| InternalError::TcpConnect(IntoSystemError::into_system_error(err)))?;

        let alpn = sock.find_alpn(alpn);

        Ok((TlsStream::Client(sock), alpn))
    }
}

#[cfg(not(feature = "transport-hyper"))]
mod tls_upgrade {
    #[derive(Debug, Clone)]
    pub struct ProtonApiTlsUpgrader(());

    #[derive(Debug, Clone)]
    pub struct OtherUpgrader(());
}

pub(crate) use tls_upgrade::*;
