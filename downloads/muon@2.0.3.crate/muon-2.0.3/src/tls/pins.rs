use std::borrow::Borrow;
use std::collections::HashSet;
use std::collections::hash_set::{IntoIter as HashSetIntoIter, Iter as HashSetIter};
use std::fmt::{Formatter, Result as FmtResult};

use derive_more::{AsRef, Deref};

use crate::Result;
use crate::tls::certs::TlsCert;
use crate::util::ByteSliceExt as _;

/// A TLS pin.
///
/// This is the SHA-256 hash of a certificate's Subject Public Key Info (SPKI).
#[derive(Debug, AsRef, Deref, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TlsPin([u8; 32]);

impl TlsPin {
    /// Create a new TLS pin from the given SHA-256 hash.
    #[must_use]
    pub fn new(pin: [u8; 32]) -> Self {
        Self(pin)
    }
}

impl std::fmt::Display for TlsPin {
    fn fmt(&self, f: &mut Formatter) -> FmtResult {
        write!(f, "{}", self.as_b64())
    }
}

impl std::str::FromStr for TlsPin {
    type Err = Base64DecodingError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        Ok(Self::new(s.b64_into().map_err(|_| Base64DecodingError)?))
    }
}

impl Borrow<[u8; 32]> for TlsPin {
    fn borrow(&self) -> &[u8; 32] {
        &self.0
    }
}

#[derive(Debug, thiserror::Error)]
#[error("Failed to decode base64 string")]
pub struct Base64DecodingError;

/// A TLS pin set.
///
/// This type wraps a set of TLS pins, providing convenient methods for checking
/// whether a given certificate matches any of the pins in the set.
#[derive(Debug, Default, Clone)]
pub struct TlsPinSet(HashSet<TlsPin>);

impl TlsPinSet {
    /// Create a new TLS pin set from the given pins.
    #[must_use]
    pub fn new(pins: impl IntoIterator<Item = TlsPin>) -> Self {
        Self(pins.into_iter().collect())
    }

    /// Create a new TLS pin set from the base64-encoded pins.
    pub fn from_b64<I, T>(pins: I) -> Result<Self, Base64DecodingError>
    where
        I: IntoIterator<Item = T>,
        T: AsRef<str>,
    {
        let pins = (pins.into_iter())
            .map(|pin| pin.as_ref().parse())
            .collect::<Result<HashSet<_>, Base64DecodingError>>()?;

        Ok(Self::new(pins))
    }

    /// Check whether there are pins
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    /// Check whether the given certificate is pinned.
    #[must_use]
    pub fn contains(&self, cert: &TlsCert) -> bool {
        self.0.contains(&cert.public_key().raw.sha256())
    }

    /// Check whether any of the given certificates are pinned.
    #[must_use]
    pub fn contains_any(&self, certs: &[TlsCert]) -> bool {
        certs.iter().any(|cert| self.contains(cert))
    }

    /// Check whether all of the given certificates are pinned.
    #[must_use]
    pub fn contains_all(&self, certs: &[TlsCert]) -> bool {
        certs.iter().all(|cert| self.contains(cert))
    }
}

impl IntoIterator for TlsPinSet {
    type IntoIter = HashSetIntoIter<TlsPin>;
    type Item = TlsPin;

    fn into_iter(self) -> Self::IntoIter {
        self.0.into_iter()
    }
}

impl<'a> IntoIterator for &'a TlsPinSet {
    type IntoIter = HashSetIter<'a, TlsPin>;
    type Item = &'a TlsPin;

    fn into_iter(self) -> Self::IntoIter {
        self.0.iter()
    }
}
