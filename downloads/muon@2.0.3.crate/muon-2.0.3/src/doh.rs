//! ## DNS
//!
//! This module provides DNS resolution capabilities for the `muon` library.
//! It defines the [`Dns`] trait, which is an abstraction over a DNS client,
//! and an adapter to use a DNS client as a [`Resolver`];
//!
//! [`Resolver`]: crate::rt::Resolver

use crate::common::{
    Accept, ConnectTransport, DNS_TCP_QUERY, Name, ProtonRequest, ProtonResponse, SendRequest,
    Server, WithTimeout as _,
};
use crate::http::{GET, HttpRes};
use crate::tls::upgrader::{MuonUpgrader, OtherUpgrader};
use crate::util::{ByteSliceExt, TryRace};
use crate::{ErrorKind, InternalError, Result};
use hickory_proto::op::{Message, Query, ResponseCode};
use hickory_proto::rr::rdata::{A, AAAA};
use hickory_proto::rr::{RData, Record, RecordType};
use hickory_proto::serialize::binary::{BinDecodable, BinEncodable};
use itertools::Itertools;
use std::net::IpAddr;
use tracing::*;
pub const BUILTIN_DOH_SERVICES: &[DohService] = &[DohService::GOOGLE, DohService::QUAD9];

/// A DNS-over-HTTPS service.
#[derive(Debug, Clone)]
pub struct DohService {
    uri: &'static str,
    path: &'static str,
}

impl DohService {
    pub const CLOUDFLARE: DohService = DohService {
        uri: "https://cloudflare-dns.com",
        path: "/dns-query",
    };
    pub const GOOGLE: DohService = DohService {
        uri: "https://dns.google",
        path: "/dns-query",
    };
    pub const QUAD9: DohService = DohService {
        uri: "https://dns.quad9.net",
        path: "/dns-query",
    };

    /// Create a new DoH service.
    ///
    /// See [`DohService::GOOGLE`] for an example
    pub fn new(uri: &'static str, path: &'static str) -> Self {
        let this = Self { uri, path };
        this.audit();
        this
    }

    pub fn server(&self) -> Server {
        self.uri.parse().unwrap()
    }

    pub fn path(&self) -> &'static str {
        self.path
    }

    /// check that we have a sane doh service
    fn audit(&self) {
        let server = self.server();
        assert!(server.base(server.host().name()).is_ok());
    }
}

#[derive(Debug, thiserror::Error)]
#[error("non-zero DNS response code: {0}")]
pub(crate) struct ResponseErr(ResponseCode);

impl ResponseErr {
    pub fn new(code: ResponseCode) -> Self {
        Self(code)
    }
}

/// Resolve the given host to a set of IP addresses.
///
/// This method resolves both IPv4 and IPv6 addresses.
///
/// # Errors
///
/// Returns an [`InternalError`] if the host cannot be resolved.
pub(crate) async fn lookup_addr<
    Connector: ConnectTransport<ProtonRequest, ProtonResponse, Sender = S>,
    S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
>(
    name: &Name,
    connector: &Connector,
    upgrader: &OtherUpgrader,
    service: &[DohService],
) -> Result<Vec<IpAddr>, InternalError> {
    trace!(%name, "looking up IP addresses");

    let mut res = Vec::new();

    for rd in lookup(name, connector, &upgrader, service, RecordType::A).await? {
        let RData::A(A(ip)) = rd else {
            continue;
        };

        res.push(ip.into());
    }

    for rd in lookup(name, connector, &upgrader, service, RecordType::AAAA).await? {
        let RData::AAAA(AAAA(ip)) = rd else {
            continue;
        };

        res.push(ip.into());
    }

    Ok(res)
}

/// Resolve the given host's TXT records as names.
///
/// # Errors
///
/// Returns an error if the host cannot be resolved.
pub(crate) async fn lookup_name<
    Connector: ConnectTransport<ProtonRequest, ProtonResponse, Sender = S>,
    S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
>(
    name: &Name,
    connector: &Connector,
    upgrader: &OtherUpgrader,
    service: &[DohService],
) -> Result<Vec<Name>, InternalError> {
    trace!(%name, "looking up TXT records");

    let mut res = Vec::new();

    for rd in lookup(name, connector, upgrader, service, RecordType::TXT)
        .await
        .inspect_err(|err| warn!(%err, "failed to lookup TXT record"))?
    {
        debug!("RData {rd:?}");

        let RData::TXT(txt) = rd else {
            continue;
        };

        for txt in txt.txt_data() {
            let Ok(txt) = txt.as_utf8() else {
                continue;
            };
            let Ok(name) = txt.parse() else {
                continue;
            };
            res.push(name);
        }
    }
    debug!(?res, "found");

    Ok(res)
}

/// Resolve the given host to a list of `RData` records.
///
/// # Errors
///
/// Returns an error if the host cannot be resolved.
async fn lookup<
    Connector: ConnectTransport<ProtonRequest, ProtonResponse, Sender = S>,
    S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
>(
    name: &Name,
    connector: &Connector,
    upgrader: &OtherUpgrader,
    service: &[DohService],
    rt: RecordType,
) -> Result<Vec<RData>, InternalError> {
    trace!(%name, %rt, "performing DNS lookup");

    let name = name
        .parse()
        .inspect_err(|err| warn!(%err, "failed to parse name"))
        .map_err(|err| InternalError::Irrecoverable(ErrorKind::resolve(err)))?;

    debug!("parsed {name}");

    let qry = Query::query(name, rt);

    let msg = new_message(qry);
    let res = query(connector, upgrader, service, msg).await?;
    let mut ans = Vec::new();

    for msg in res {
        match msg.response_code() {
            ResponseCode::NoError => {
                trace!(msg = %fmt_msg(&msg), "received DNS response");
                ans.extend(get_answers(msg))
            }

            code => {
                error!(%code, "DNS response error");
                Err(ResponseErr::new(code))
                    .map_err(|err| InternalError::Irrecoverable(ErrorKind::resolve(err)))?
            }
        }
    }

    Ok(ans)
}

async fn query_service<
    Connector: ConnectTransport<ProtonRequest, ProtonResponse, Sender = S>,
    S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
>(
    connector: &Connector,
    upgrader: &OtherUpgrader,
    service: &DohService,
    msg: &Message,
) -> Result<Vec<Message>, InternalError> {
    trace!("connecting to DNS-over-HTTPS server");

    let server = service.server();
    let host = server.host();
    let base = server.base(host.name()).map_err(ErrorKind::resolve)?;

    debug!("attempting to connect to {server}");

    let sender = connector
        .connect(&server, MuonUpgrader::Other(upgrader))
        .await?;

    let unbounded_sender = sender.get_unbounded();

    trace!("sending {msg} over HTTPS");

    let request = GET!("{}", service.path())
        .query((
            "dns",
            msg.to_bytes()
                .map_err(|err| InternalError::Irrecoverable(ErrorKind::resolve(err)))?
                .as_b64_url(),
        ))
        .header(Accept::DNS)
        .uri(base);

    let timer = connector.get_sleep_capability();

    let res: HttpRes = unbounded_sender
        .send(request)
        .with_timeout(timer, DNS_TCP_QUERY)
        .await
        .map_err(InternalError::resolve)??
        .into();

    trace!("received response {:?}", res);
    Ok(vec![Message::from_bytes(res.body()).map_err(|err| {
        InternalError::Irrecoverable(ErrorKind::resolve(err))
    })?])
}

async fn query<
    Connector: ConnectTransport<ProtonRequest, ProtonResponse, Sender = S>,
    S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
>(
    connector: &Connector,
    upgrader: &OtherUpgrader,
    service: &[DohService],
    msg: Message,
) -> Result<Vec<Message>, InternalError> {
    trace!("performing DNS-over-HTTPS query ");

    service
        .iter()
        .map(|service| {
            Box::pin(async {
                match query_service(connector, &upgrader, service, &msg).await {
                    Ok(res) => {
                        trace!("received DNS-over-HTTPS response");
                        Ok(res)
                    }

                    Err(err) => {
                        error!(%err, "failed to perform DNS-over-HTTPS query");
                        Err(err)?
                    }
                }
            })
        })
        .try_race()
        .await
}

fn new_message(query: Query) -> Message {
    Message::new()
        .add_query(query)
        .set_recursion_desired(true)
        .to_owned()
}

fn get_answers(msg: Message) -> Vec<RData> {
    msg.into_parts()
        .answers
        .into_iter()
        .map(Record::into_data)
        .collect::<Vec<_>>()
}

/// Format a DNS query for debugging.
fn fmt_msg(msg: &Message) -> String {
    let mut parts = Vec::new();

    match msg.queries().iter().map(|q| q.name()).join(", ") {
        s if !s.is_empty() => parts.push(format!("q: [{s}]")),
        _ => (),
    };

    match msg.answers().iter().map(|a| a.name()).join(", ") {
        s if !s.is_empty() => parts.push(format!("a: [{s}]")),
        _ => (),
    };

    parts.join(", ")
}

#[cfg(test)]
#[cfg(not(ci))]
mod tests {
    use crate::doh::{DohService, lookup_addr};
    use crate::rand::DeriveRng;
    use crate::tests::util::TokioTime;
    use crate::tls::upgrader::OtherUpgrader;
    use crate::transport::http::reqwest::ReqwestConnector;
    use crate::util::IntoIterExt as _;
    use rand_chacha::ChaCha20Rng;

    #[tokio::test]
    async fn test_doh_client_direct() {
        let name = "www.google.com".to_owned();

        let time = TokioTime::default();

        let connector = ReqwestConnector(time.clone(), rand::rng().derive::<ChaCha20Rng>().into());

        let have = lookup_addr(
            &name.parse().unwrap(),
            &connector,
            &OtherUpgrader::default(),
            &[DohService::GOOGLE, DohService::QUAD9],
        )
        .await
        .unwrap();

        assert!(!have.into_set().is_empty());
    }
}
