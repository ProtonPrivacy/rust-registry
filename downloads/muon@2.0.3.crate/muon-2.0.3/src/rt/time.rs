pub use proton_os_interface::time::*;

/// Trait alias grouping time capabilities
pub trait TimeCapabilities:
    Sleep
    + Send
    + Sync
    + Clone
    + InstantFactory<Instant = MuonInstant>
    + SystemTimeFactory<SystemTime = MuonSystemTime>
    + 'static
{
}

impl<
    This: Sleep
        + Send
        + Sync
        + InstantFactory<Instant = MuonInstant>
        + SystemTimeFactory<SystemTime = MuonSystemTime>
        + 'static,
> TimeCapabilities for This
{
}

/// A monotonically increasing time point
pub type MuonInstant = Instant;

/// A timestamp since UNIX epoch expressed in nanosec
pub type MuonSystemTime = SystemTime;
