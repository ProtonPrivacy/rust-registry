//! ## Spawner
//!
//! This module defines the [`Spawner`] trait and related types.
//! A spawner is a type that can spawn a future for background execution.
//! The `muon` client uses a spawner to drive any asynchronous tasks that it
//! needs to perform.

/// A wrapper around a local !Send executor
#[derive(Debug, Clone)]
pub struct LocalExecutor<S>(pub(crate) S);

/// A wrapper around a non-local Send executor
#[derive(Debug, Clone)]
pub struct SendExecutor<S>(pub(crate) S);

/// re-export futures for upstream crates
pub use futures::task::{FutureObj, LocalFutureObj, LocalSpawn, Spawn, SpawnError};

/// A type capable of spawning a future.
pub trait Spawner: futures::task::Spawn + Clone + Send + Sync + Unpin + 'static {}
impl<S: futures::task::Spawn + Clone + Send + Sync + Unpin + 'static> Spawner for S {}

/// A type capable of spawning a future.
pub trait LocalSpawner: futures::task::LocalSpawn + Clone + Unpin + 'static {}
impl<S: futures::task::LocalSpawn + Clone + Unpin + 'static> LocalSpawner for S {}

#[cfg(test)]
mod test {
    use crate::rt::{LocalExecutor, LocalSpawner, SendExecutor};
    use crate::tests::util::TokioExecutor;
    use futures::executor::LocalSpawner as FutureSpawner;
    use futures::future::LocalBoxFuture;
    use futures::task::{LocalSpawnExt, SpawnExt};
    use std::time::Duration;

    #[tokio::test]
    async fn test_send_executor() {
        let ex = SendExecutor(TokioExecutor);
        let _ = tokio::spawn(async move {
            ex.0.spawn(tokio::time::sleep(Duration::from_secs(1)))
                .unwrap();
            assert!(true)
        })
        .await;
    }

    #[test]
    fn test_local_executor() {
        async fn shout() {
            println!("booh")
        }

        let mut pool = futures::executor::LocalPool::new();
        let spawner = pool.spawner();

        let ex = LocalExecutor(spawner.clone());

        let _ = spawner.spawn_local(async move {
            ex.0.spawn_local(shout()).unwrap();
            assert!(true)
        });

        pool.run_until_stalled();
    }

    mod generic {
        use super::*;
        use crate::rt::Spawner;
        use futures::future::BoxFuture;
        const EXPECTED_STR: &str = "ayo";

        trait SomeFunc {
            type Fut: Future<Output = String>;
            fn get_string(&self) -> Self::Fut;
        }

        struct Holder<Ex>(Ex);

        impl<Ex> SomeFunc for Holder<LocalExecutor<Ex>>
        where
            Ex: LocalSpawner,
        {
            type Fut = LocalBoxFuture<'static, String>;

            fn get_string(&self) -> Self::Fut {
                Box::pin(
                    // nosemgrep
                    self.0
                        .0
                        .spawn_local_with_handle(async move { EXPECTED_STR.to_owned() })
                        .unwrap(),
                )
            }
        }

        impl<Ex> SomeFunc for Holder<SendExecutor<Ex>>
        where
            Ex: Spawner,
        {
            type Fut = BoxFuture<'static, String>;

            fn get_string(&self) -> Self::Fut {
                Box::pin(
                    // nosemgrep
                    self.0
                        .0
                        .spawn_with_handle(async move { EXPECTED_STR.to_owned() })
                        .unwrap(),
                )
            }
        }

        struct Consumer<T: SomeFunc>(T);
        impl<T: SomeFunc> Consumer<T> {
            pub async fn consume(&self) -> String {
                self.0.get_string().await
            }
        }

        async fn use_executor_holder(holder: impl SomeFunc) -> String {
            holder.get_string().await
        }

        #[test]
        fn test_local_generic_executor() {
            let pool = futures::executor::LocalPool::new();
            let spawner = pool.spawner();

            let ex = LocalExecutor(spawner.clone());
            let holder: Holder<LocalExecutor<FutureSpawner>> = Holder(ex);

            let _ = spawner.spawn_local(async move {
                assert_eq!(use_executor_holder(holder).await, EXPECTED_STR);
            });

            struct WrappingStruct<T: SomeFunc>(T);
            impl<T: SomeFunc> WrappingStruct<T> {
                pub async fn test(&self) -> String {
                    self.0.get_string().await
                }
            }

            let ex = LocalExecutor(spawner.clone());
            let holder: Holder<LocalExecutor<FutureSpawner>> = Holder(ex);
            let wrapper = WrappingStruct(holder);

            let _ = spawner.spawn_local(async move {
                assert_eq!(wrapper.test().await, EXPECTED_STR);
            });
        }

        #[tokio::test]
        async fn test_send_generic_executor() {
            const THE_STRING: &str = "ayo";

            let ex = SendExecutor(TokioExecutor);
            let holder = Holder(ex);

            let _ = tokio::spawn(async move {
                assert_eq!(use_executor_holder(holder).await, THE_STRING);
            });

            let ex = SendExecutor(TokioExecutor);
            let holder = Holder(ex);
            let wrapper = Consumer(holder);

            let _ = tokio::spawn(async move {
                assert_eq!(wrapper.consume().await, THE_STRING);
            });
        }
    }
}
