//! ## Runtime
//!
//! This module provides implementations of runtime-dependent components, such
//! as the resolver, dialer and executor.
/// re-export futures::AsyncRead/AsyncWrite
pub use futures::{AsyncRead, AsyncWrite};
/// re-export os-interfance relevant error types
pub use proton_os_interface::error::{IntoSystemError, SystemError};
/// re-export os-interface relevant IO traits
pub use proton_os_interface::io::{Socket, TcpConnect};

mod resolver;
pub use resolver::*;

mod spawner;
pub use spawner::*;

mod time;
use std::fmt::Debug;
pub use time::*;

pub trait OperatingSystem: Send + Sync + Clone + Debug {
    type Time: TimeCapabilities + Debug;
    fn get_time_capabilities(&self) -> &Self::Time;

    type TcpConnector: TcpConnect + Debug;
    fn get_tcp_connector(&self) -> &Self::TcpConnector;

    type Resolver: Resolve + Debug;
    fn get_resolver(&self) -> &Self::Resolver;
}

mod internal {
    /// A type that can provide a prng
    pub trait HasRandCapabilities {
        type Rng: crate::rand::CryptoRng + 'static;
        fn get_prng(&self) -> Self::Rng;
    }

    use crate::rt::time::{InstantFactory, Sleep};
    /// A type that can provide something to sleep
    pub trait HasSleepCapabilities {
        type Sleeper: InstantFactory + Sleep + 'static;
        fn get_sleep_capability(&self) -> &Self::Sleeper;
    }
}

pub use internal::*;
#[allow(unused)]
pub(crate) type OsTime<OS> = <OS as OperatingSystem>::Time;
#[allow(unused)]
pub(crate) type OsSleepFut<'a, OS> = <OsTime<OS> as Sleep>::Sleep<'a>;
#[allow(unused)]
pub(crate) type OsSocket<OS> = <<OS as OperatingSystem>::TcpConnector as TcpConnect>::Socket;
