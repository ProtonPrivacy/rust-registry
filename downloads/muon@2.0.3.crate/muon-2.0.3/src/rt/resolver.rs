//! ## Resolver
//!
//! This module defines the [`Resolver`] trait and related types.

use crate::{ErrorKind, Result};
use itertools::chain;
pub use proton_os_interface::resolve::*;
use std::collections::HashSet;
use std::hash::Hash;
use std::iter::once;
use thiserror::Error;

/// An error indicating that no addresses could be resolved for a host.
#[derive(Debug, Error)]
#[error("no addresses could be resolved for host")]
pub struct ResolveErr;

/// The result of resolving a host.
///
/// If a resolver is unable to resolve a host, for example because it does not
/// support indirect resolution, it can return a [`ResolveRes::None`] result.
/// This is not considered an error, and the client will attempt to resolve the
/// host using the next resolver in the chain.
#[derive(Debug)]
pub enum ResolveRes<Addr> {
    /// The host was resolved to one or more addresses.
    Some(Addr, Vec<Addr>),

    /// The host should be resolved by another resolver.
    None,
}

impl<Addr: Eq + Hash> ResolveRes<Addr> {
    /// Consumes the result, converting it to a vector of resolved addresses.
    #[must_use]
    pub fn into_set(self) -> HashSet<Addr> {
        if let ResolveRes::Some(head, tail) = self {
            chain!(once(head), tail).collect()
        } else {
            HashSet::new()
        }
    }

    /// Consumes the result, converting it to `Result<HashSet<Addr>>`.
    ///
    /// This is a convenience method to help with type inference.
    ///
    /// # Errors
    ///
    /// Returns an error if no addresses were resolved.
    pub fn into_res(self) -> Result<HashSet<Addr>> {
        self.into()
    }
}

impl<Addr: Eq + Hash> From<ResolveRes<Addr>> for Result<HashSet<Addr>> {
    fn from(res: ResolveRes<Addr>) -> Self {
        match res.into_set() {
            addr if !addr.is_empty() => Ok(addr),
            _ => Err(ErrorKind::resolve(ResolveErr)),
        }
    }
}
