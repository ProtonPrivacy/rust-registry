//! ## Env
//!
//! This module defines types representing an API environment. An environment
//! defines the servers the client should use, for a given platform and product.
//! The client uses the environment to determine the API endpoints to connect
//! to and how to verify their TLS certificates.
//!
//! All types related to the Proton environment.
//!
//! ### Examples (atlas)
//! ```
//! # tokio_test::block_on(async {
//! use muon::Environment;
//! use muon::{App, Client, GET};
//! let app = App::new("windows-vpn@1.0.0")?;
//! let atlas = Environment::new_atlas();
//! let session = Client::builder(app, atlas);
//! /// ...
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ### NB
//! By default, environments can not be extended unless the `unsealed` feature
//! is activated.

use crate::Sealed;
use crate::app::AppVersion;
use crate::common::Server;
use crate::tls::pins::TlsPinSet;
use crate::util::IntoIterExt as _;
use derive_more::{Debug, From};
use std::sync::Arc;
use thiserror::Error;

mod atlas;

mod prod;
pub use atlas::{AtlasScientist, AtlasStandard};
pub use prod::Prod;

/// An API environment.
///
/// This provides information about the environment in which the client
/// operates, such as the API endpoints and their TLS pins.
///
/// This is a sealed trait; it cannot be implemented outside of this crate.
/// However, it can be implemented by enabling the `unsealed` feature.
pub trait Env: Sealed + Send + Sync + 'static {
    /// Get the servers available for the given app version.
    fn servers(&self, version: &AppVersion) -> Vec<Server>;

    /// Get the TLS pins for a given server, if any.
    fn pins(&self, srv: &Server) -> Option<&TlsPinSet> {
        if srv.host().is_direct() {
            self.api_pins()
        } else {
            self.ar_pins()
        }
    }

    fn ar_pins(&self) -> Option<&TlsPinSet>;

    fn api_pins(&self) -> Option<&TlsPinSet>;
}

/// An extension trait for [`Env`]s.
pub trait EnvExt: Env {
    /// Get the servers available for the given app.
    fn servers_for(&self, app: impl AsRef<AppVersion>) -> Vec<Server> {
        self.servers(app.as_ref())
    }
}

#[derive(Debug, Clone, From)]
pub enum Environment {
    /// The production environment.
    ///
    /// This refers to the [`Prod`] environment.
    Prod(Prod),

    /// The Atlas environment.
    ///
    /// This refers to the [`AtlasScientist`] environment.
    Scientist(AtlasScientist),

    /// The Atlas environment.
    ///
    /// This refers to the [`AtlasStandard`] environment.
    Atlas(AtlasStandard),

    /// A custom environment.
    ///
    /// This provides a user-defined [`Env`] implementation.
    /// Such environments are not supported by default; the [`Env`] trait is
    /// sealed and cannot be implemented outside of this crate. However, this
    /// restriction can be lifted by enabling the `unsealed` feature.
    Custom(#[debug(skip)] Arc<dyn Env>),
}

impl Environment {
    /// Create a new prod environment identifier.
    pub fn new_prod() -> Self {
        Self::Prod(Prod::default())
    }

    /// Create a new atlas environment identifier.
    pub fn new_atlas() -> Self {
        Self::Atlas(AtlasStandard::default())
    }

    /// Create a new atlas environment identifier with the given scientist name.
    pub fn new_atlas_name(name: impl AsRef<str>) -> Self {
        Self::Scientist(AtlasScientist::new(name))
    }

    /// Create a new custom environment identifier.
    #[cfg(feature = "unsealed")]
    pub fn new_custom(env: impl Env) -> Self {
        Self::Custom(Arc::new(env))
    }
}

impl Env for Environment {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        match self {
            Environment::Prod(env) => env.servers(version),
            Environment::Scientist(env) => env.servers(version),
            Environment::Atlas(env) => env.servers(version),
            Environment::Custom(env) => env.servers(version),
        }
    }

    fn ar_pins(&self) -> Option<&TlsPinSet> {
        match self {
            Environment::Prod(env) => env.ar_pins(),
            Environment::Scientist(env) => env.ar_pins(),
            Environment::Atlas(env) => env.ar_pins(),
            Environment::Custom(env) => env.ar_pins(),
        }
    }

    fn api_pins(&self) -> Option<&TlsPinSet> {
        match self {
            Environment::Prod(env) => env.api_pins(),
            Environment::Scientist(env) => env.api_pins(),
            Environment::Atlas(env) => env.api_pins(),
            Environment::Custom(env) => env.api_pins(),
        }
    }
}

#[cfg(not(feature = "unsealed"))]
impl Sealed for Environment {}

/// An error that can occur when parsing an environment identifier.
#[derive(Debug, Error)]
#[error("invalid environment identifier: {0}")]
pub struct ParseEnvIdErr(String);

impl std::str::FromStr for Environment {
    type Err = ParseEnvIdErr;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.split(':').into_vec().as_slice() {
            ["prod"] => Ok(Self::new_prod()),
            ["atlas"] => Ok(Self::new_atlas()),
            ["atlas", name] => Ok(Self::new_atlas_name(name)),

            _ => Err(ParseEnvIdErr(s.to_owned()))?,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_env_id() {
        let env: Environment = "prod".parse().unwrap();
        assert!(matches!(env, Environment::Prod(_)));

        let env: Environment = "atlas".parse().unwrap();
        assert!(matches!(env, Environment::Atlas(_)));

        let env: Environment = "atlas:scientist".parse().unwrap();
        assert!(matches!(env, Environment::Scientist(name) if name.0.0 == "scientist"));
    }
}
