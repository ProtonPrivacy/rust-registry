//! This module provides the [`Prod`] environment.

use crate::app::{AppVersion, Platform, Product};
use crate::common::{Host, Name, ParseNameErr};
use crate::env::{Env, Server};
use crate::tls::pins::TlsPinSet;

const API_PINS: &[&str] = &[
    "CT56BhOTmj5ZIPgb/xD5mH8rY3BLo/MlhP7oPyJUEDo=",
    "35Dx28/uzN3LeltkCBQ8RHK0tlNSa2kCpCRGNp34Gxc=",
    "qYIukVc63DEITct8sFT7ebIq5qsWmuscaIKeJx+5J5A=",
];

const AR_PINS: &[&str] = &[
    "EU6TS9MO0L/GsDHvVc9D5fChYLNy5JdGYpJw0ccgetM=",
    "iKPIHPnDNqdkvOnTClQ8zQAIKG0XavaPkcEo0LBAABA=",
    "MSlVrBCdL0hKyczvgYVSRNm88RicyY04Q2y5qrBt0xA=",
    "C2UxW0T1Ckl9s+8cXfjXxlEqwAfPM4HiW2y3UdtBeCw=",
];

/// The production API environment.
///
/// This environment represents the production Proton API, used by default.
/// Clients using this environment will connect to `https://*.proton.me/`.
#[derive(Debug, Clone)]
pub struct Prod {
    api_pins: TlsPinSet,
    ar_pins: TlsPinSet,
}

impl Default for Prod {
    fn default() -> Self {
        Self {
            api_pins: TlsPinSet::from_b64(API_PINS).expect("failed to read pins"),
            ar_pins: TlsPinSet::from_b64(AR_PINS).expect("failed to read pins"),
        }
    }
}

impl Env for Prod {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        let (plat, prod) = if let Some(name) = version.name() {
            (name.platform(), name.product())
        } else {
            (&Platform::Web, &Product::Mail)
        };

        let (host, path) = if let Platform::Web = plat {
            (format!("{prod}.proton.me"), "/api")
        } else {
            (format!("{prod}-api.proton.me"), "/")
        };
        let host: Name = host.parse().expect("wrong api url");
        servers(&host, &host.into_alt(), path).unwrap()
    }

    fn ar_pins(&self) -> Option<&TlsPinSet> {
        assert!(!self.api_pins.is_empty());
        Some(&self.ar_pins)
    }

    fn api_pins(&self) -> Option<&TlsPinSet> {
        assert!(!self.api_pins.is_empty());
        Some(&self.api_pins)
    }
}

#[cfg(not(feature = "unsealed"))]
impl crate::Sealed for Prod {}

fn servers(dir: &str, alt: &str, path: &str) -> Result<Vec<Server>, ParseNameErr> {
    Ok(vec![
        Server::https(Host::direct(dir)?, path),
        #[cfg(feature = "alternative-routing")]
        Server::https(Host::indirect(alt)?, path),
    ])
}
