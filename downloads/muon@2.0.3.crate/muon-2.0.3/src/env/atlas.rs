//! This module provides the [`Atlas`] environment.

use crate::app::{AppVersion, Platform};
use crate::common::{Host, Server};
use crate::env::Env;
use crate::tls::pins::TlsPinSet;
use derive_more::From;

#[derive(Debug, Clone, Default)]
pub struct Standard;

#[derive(Debug, Clone, Default)]
pub struct Scientist(pub(crate) String);

/// An atlas API environment.
///
/// This environment is used for internal testing.
/// Clients using this environment will connect to `https://*.proton.black/`.
#[must_use]
#[derive(Debug, Default, From, Clone, Copy)]
pub struct Atlas<T>(pub(crate) T);

/// The standard Atlas environment, with no scientist name.
///
/// Clients using this will send requests to `https://proton.black/api`.
pub type AtlasStandard = Atlas<Standard>;

/// An Atlas environment with a specific scientist name.
///
/// Clients using this will send requests to `https://foo.proton.black/api`,
/// where `foo` is the scientist name provided.
pub type AtlasScientist = Atlas<Scientist>;

impl AtlasScientist {
    pub(crate) fn new(name: impl AsRef<str>) -> Self {
        Self(Scientist(name.as_ref().to_owned()))
    }
}

const PROTON_BLACK: &str = "proton.black";

impl Env for Atlas<Standard> {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        let base = String::from(PROTON_BLACK);

        let (host, path) = if let Some(name) = version.name() {
            let (plat, prod) = (name.platform(), name.product());
            match plat {
                // Specific to Web
                Platform::Web => (format!("{prod}.{base}"), "/api"),

                // Other platforms
                _ => (format!("{prod}-api.{base}"), "/"),
            }
        } else {
            (base, "/api")
        };

        into_servers(&host, path)
    }

    fn api_pins(&self) -> Option<&TlsPinSet> {
        None
    }

    fn ar_pins(&self) -> Option<&TlsPinSet> {
        None
    }
}

impl Env for Atlas<Scientist> {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        let base = String::from(PROTON_BLACK);

        let Atlas(Scientist(name)) = self;
        let (host, path) = if let Some(app_name) = version.name() {
            let (plat, prod) = (app_name.platform(), app_name.product());
            match plat {
                // Specific to Web
                Platform::Web => (format!("{prod}.{name}.{base}"), "/api"),
                // Other platforms
                _ => (format!("{prod}-api.{name}.{base}"), "/"),
            }
        } else {
            (format!("{name}.{base}"), "/api")
        };

        into_servers(&host, path)
    }

    fn api_pins(&self) -> Option<&TlsPinSet> {
        None
    }

    fn ar_pins(&self) -> Option<&TlsPinSet> {
        None
    }
}

fn into_servers(host: &str, path: &str) -> Vec<Server> {
    if let Ok(host) = Host::direct(host) {
        vec![Server::https(host, path)]
    } else {
        panic!("invalid atlas host: {host}");
    }
}

#[cfg(not(feature = "unsealed"))]
impl<T> crate::Sealed for Atlas<T> {}
