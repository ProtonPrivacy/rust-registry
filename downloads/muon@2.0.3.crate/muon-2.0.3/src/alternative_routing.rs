use crate::common::{Addr, ConnectTransport, Name, SendRequest};
use crate::doh::{DohService, lookup_addr, lookup_name};
use crate::tls::upgrader::OtherUpgrader;
use crate::{InternalError, ProtonRequest, ProtonResponse, Result};
use tracing::debug;

pub(crate) async fn resolve_indirect<
    Connector: ConnectTransport<ProtonRequest, ProtonResponse, Sender = S>,
    S: SendRequest<ProtonRequest, ProtonResponse, Err = InternalError>,
>(
    name: &Name,
    connector: &Connector,
    upgrader: &OtherUpgrader,
    service: &[DohService],
) -> Result<Vec<Addr>, InternalError> {
    debug!(%name, "resolving name via indirect lookup");
    let mut res = Vec::new();

    for name in lookup_name(&name, connector, &upgrader, service).await? {
        debug!(?name, "found");

        res.extend(lookup_addr(&name, connector, &upgrader, service).await?);
    }

    debug!(?res, "addresses found");

    Ok(res
        .into_iter()
        .map(|ip| Addr::new(name.to_owned(), ip))
        .collect())
}

#[cfg(test)]
#[cfg(not(ci))]
mod tests {
    use crate::Environment;
    use crate::alternative_routing::resolve_indirect;
    use crate::doh::DohService;
    use crate::rt::SendExecutor;
    use crate::tests::util::{MyOperatingSystem, TokioExecutor};
    use crate::tls::certs::TlsCertDer;
    use crate::tls::upgrader::OtherUpgrader;
    use crate::tls::verifier::ProtonApiVerifier;
    use crate::transport::http::hyper::connector::HyperConnector;
    use crate::util::{ByteSliceExt as _, IntoIterExt as _};
    use std::sync::Arc;

    #[tokio::test]
    async fn test_doh_client_indirect() {
        let dir = "api.protonmail.ch".as_b32();
        let alt = format!("d{dir}.protonpro.xyz").parse().unwrap();
        let doh_services = &[DohService::GOOGLE, DohService::QUAD9];
        let roots: Option<Vec<&TlsCertDer>> = None;
        let proton_api_verifier = ProtonApiVerifier::new(Environment::new_atlas().into(), roots);

        let connector = HyperConnector::new(
            Arc::new(MyOperatingSystem::default()),
            crate::common::Proxy::NoProxy,
            rand::rng(),
            doh_services.to_vec(),
            SendExecutor(TokioExecutor),
            proton_api_verifier,
            OtherUpgrader::default(),
        );

        let have = resolve_indirect(&alt, &connector, &OtherUpgrader::default(), doh_services)
            .await
            .unwrap();

        assert!(!have.into_set().is_empty());
    }
}
