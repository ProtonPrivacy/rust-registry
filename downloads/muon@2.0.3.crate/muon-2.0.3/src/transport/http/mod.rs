#[cfg(all(target_family = "wasm", feature = "transport-hyper"))]
compile_error!("features 'transport-hyper' can not be used in WASM targets");

mod body;
pub use body::*;

mod req;
pub use req::*;

mod res;
pub use res::*;

mod macros;
pub use macros::*;

mod util;

#[cfg(feature = "transport-hyper")]
pub mod hyper;

#[cfg(any(
    feature = "transport-reqwest-rustls",
    feature = "transport-reqwest-wasm"
))]
pub mod reqwest;

use crate::{ErrorKind, InternalError};

impl From<http::Error> for InternalError {
    fn from(src: http::Error) -> Self {
        InternalError::Irrecoverable(ErrorKind::req(src))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::error::Error;

    #[test]
    fn http_error_into_internal() {
        let inner = http::StatusCode::from_u16(0).unwrap_err();
        let err = InternalError::from(http::Error::from(inner));
        let _ = err.source().unwrap().downcast_ref::<http::Error>().unwrap();
        assert!(matches!(err, InternalError::Irrecoverable(err) if err.kind() == ErrorKind::Req));
    }
}
