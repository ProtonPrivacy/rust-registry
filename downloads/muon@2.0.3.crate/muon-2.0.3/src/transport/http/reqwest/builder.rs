use crate::client::builder::{BaseBuilder, BuildTransport};
use crate::rand::{CryptoRng, DeriveRng};
use crate::rt::{HasSleepCapabilities, InstantFactory, Sleep};
use crate::transport::http::reqwest::ReqwestConnector;
use crate::{App, ProtonRequest, ProtonResponse, Result};
use rand_chacha::ChaCha20Rng;
use std::sync::Arc;

/// A [`BaseBuilder`] for configuring a [`Reqwest`] transport.
pub type ReqwestBuilder<Sleeper = ()> = BaseBuilder<Reqwest<Sleeper>>;

/// A [`Transport`] that builds a [`reqwest`]-based connector.
#[derive(Debug)]
pub struct Reqwest<Sleeper = ()>(Sleeper, Option<ChaCha20Rng>);

impl ReqwestBuilder {
    pub fn with_operating_system<Sleeper: Sleep>(
        self,
        sleeper: Sleeper,
        mut prng: impl CryptoRng,
    ) -> ReqwestBuilder<Sleeper> {
        self.transform_inner(|_| Reqwest(sleeper, Some(prng.derive::<ChaCha20Rng>())))
    }
}

impl Default for Reqwest {
    fn default() -> Self {
        Self((), None)
    }
}

impl<S: InstantFactory + Sleep + 'static> BuildTransport<ProtonRequest, ProtonResponse>
    for Reqwest<S>
{
    type Connector = ReqwestConnector<S>;

    fn build(self, _: &App, _: Arc<crate::Environment>) -> Result<Self::Connector> {
        Ok(ReqwestConnector(
            self.0,
            self.1
                .ok_or(crate::error::Error::other("missing crypto safe prng"))?
                .into(),
        ))
    }
}

impl<S: InstantFactory + Sleep + Clone + 'static> HasSleepCapabilities for Reqwest<S> {
    type Sleeper = S;

    fn get_sleep_capability(&self) -> &Self::Sleeper {
        &self.0
    }
}

#[cfg(not(feature = "unsealed"))]
impl crate::Sealed for Reqwest {}
