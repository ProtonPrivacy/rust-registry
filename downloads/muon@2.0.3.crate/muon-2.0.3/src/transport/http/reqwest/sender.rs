use super::reqwest;
use crate::common::{BoundSender, SendRequest};
use crate::http::{BuildRequestUri, HttpReq, HttpRes, Version};
use crate::{ErrorKind, InternalError, Result};
use bytes::Bytes;
use derive_more::Debug;
use http::HeaderMap;
use http::response::Builder;
use std::borrow::Borrow;
use url::Url;
pub fn new_sender(base: Url) -> BoundSender<ReqwestSender> {
    let client = reqwest::Client::new();

    BoundSender::new(ReqwestSender { client }, base)
}

#[derive(Debug, Clone)]
pub struct ReqwestSender {
    client: reqwest::Client,
}

impl ReqwestSender {
    async fn send(&self, req: HttpReq) -> Result<HttpRes, InternalError> {
        // Build the request.
        let (head, body) = req
            .build::<Self>(Version::HTTP_2)
            .map_err(ErrorKind::send)?
            .into_parts();

        // Send the request.
        let res = (self.client)
            .request(head.method, head.uri.to_string())
            .headers(head.headers)
            .body(Bytes::from(body))
            .send()
            .await?;

        // Build the response.
        Ok(http::Response::builder()
            .status(res.status())
            .headers(res.headers())
            .body(res.bytes().await?.to_vec())?
            .into())
    }
}

impl BuildRequestUri for ReqwestSender {
    fn build_req_uri(_: Version, uri: Url) -> (String, Option<String>) {
        // we wont ever be proxied
        (uri.to_string(), None)
    }
}

impl SendRequest<HttpReq, HttpRes> for ReqwestSender {
    async fn send(&self, req: HttpReq) -> Result<HttpRes, Self::Err> {
        self.send(req).await
    }

    type Err = InternalError;
}

trait BuilderExt: Into<Builder> + Sized {
    fn headers(self, headers: impl Borrow<HeaderMap>) -> Builder {
        let mut this = self.into();

        for (k, v) in headers.borrow().iter() {
            this = this.header(k, v);
        }

        this
    }
}

impl<This: Into<Builder> + Sized> BuilderExt for This {}

impl From<reqwest::Error> for InternalError {
    fn from(value: reqwest::Error) -> Self {
        Self::Irrecoverable(ErrorKind::send(value))
    }
}
