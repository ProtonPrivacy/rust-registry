use super::sender::{ReqwestSender, new_sender};
use crate::common::{BoundSender, ConnectTransport, ProtonConnectTransport, Server};
use crate::http::{HttpReq, HttpRes};
use crate::rand::DeriveRng;
use crate::rt::{HasRandCapabilities, HasSleepCapabilities, InstantFactory, Sleep};
use crate::tls::upgrader::MuonUpgrader;
use crate::{ErrorKind, InternalError, Result};
use derive_more::Debug;
use rand_chacha::ChaCha20Rng;
use spin::Mutex;
/// An HTTP connector using reqwest.
#[derive(Debug)]
pub struct ReqwestConnector<Sleeper>(pub Sleeper, #[debug(skip)] pub Mutex<ChaCha20Rng>);

impl<Sleeper: Clone> ReqwestConnector<Sleeper> {
    async fn connect(&self, server: &Server) -> Result<BoundSender<ReqwestSender>, InternalError> {
        let name = server.name();
        let base = server.base(name).map_err(ErrorKind::connect)?;
        Ok(new_sender(base))
    }
}

impl<Sleeper: InstantFactory + Sleep + 'static> ProtonConnectTransport<HttpReq, HttpRes>
    for ReqwestConnector<Sleeper>
{
    async fn connect(&self, server: &Server) -> Result<BoundSender<Self::Sender>, InternalError> {
        self.connect(server).await
    }
}

impl<Sleeper: InstantFactory + Sleep + 'static> ConnectTransport<HttpReq, HttpRes>
    for ReqwestConnector<Sleeper>
{
    type Sender = ReqwestSender;

    async fn connect(
        &self,
        server: &Server,
        _: MuonUpgrader<'_>,
    ) -> Result<BoundSender<Self::Sender>, InternalError> {
        self.connect(server).await
    }
}

impl<Sleeper: InstantFactory + Sleep + 'static> HasSleepCapabilities for ReqwestConnector<Sleeper> {
    type Sleeper = Sleeper;

    fn get_sleep_capability(&self) -> &Self::Sleeper {
        &self.0
    }
}

impl<Sleeper> HasRandCapabilities for ReqwestConnector<Sleeper> {
    type Rng = ChaCha20Rng;

    fn get_prng(&self) -> Self::Rng {
        self.1.lock().derive()
    }
}
