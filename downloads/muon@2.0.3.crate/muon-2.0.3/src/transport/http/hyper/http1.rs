/// This module contains all HTTP1 connectors
use crate::Result;
use crate::error::InternalError;
use crate::http::{Body, Collect as _};
use crate::rt::{LocalExecutor, LocalSpawner, SendExecutor, Socket, Spawner};
use crate::transport::http::hyper::compat::HyperIo;
use crate::transport::http::hyper::sender::{HyperConnect, HyperSender};
use async_lock::Mutex;
use futures::FutureExt as _;
use futures::future::{BoxFuture, LocalBoxFuture};
use http::Request;
use hyper::client::conn::http1::handshake;
use hyper::rt::Executor;
use tracing::trace;

/// A type that can perform a http1 "handshake"
#[derive(Debug, Clone)]
pub struct HTTP1Connector<S>(pub S);

impl<S: LocalSpawner> HyperConnect for HTTP1Connector<LocalExecutor<S>>
where
    LocalExecutor<S>: Clone,
{
    type Fut = LocalBoxFuture<'static, Result<HyperSender<Body>, InternalError>>;

    fn connect<IO: Socket>(&self, io: IO) -> Self::Fut {
        let spawner = self.0.clone();
        Box::pin(async move {
            let io = HyperIo(io);

            let (sender, driver) = handshake(io).await?;

            spawner.execute(driver.with_upgrades().map(|_| ()));

            Ok(HTTP1Sender(sender.into()).into())
        })
    }
}

impl<S: Spawner> HyperConnect for HTTP1Connector<SendExecutor<S>>
where
    SendExecutor<S>: Clone,
{
    type Fut = BoxFuture<'static, Result<HyperSender<Body>, InternalError>>;

    fn connect<IO: Socket>(&self, io: IO) -> Self::Fut {
        let spawner = self.0.clone();

        Box::pin(async move {
            let io = HyperIo(io);

            let (sender, driver) = handshake(io).await?;

            spawner.execute(driver.with_upgrades().map(|_| ()));

            Ok(HTTP1Sender(sender.into()).into())
        })
    }
}

/// A type that can send HTTP1 requests
#[derive(Debug)]
pub(super) struct HTTP1Sender<B>(Mutex<hyper::client::conn::http1::SendRequest<B>>);

impl<B: http_body::Body + Send + 'static> HTTP1Sender<B> {
    pub async fn ready_send(
        &self,
        req: Request<B>,
    ) -> Result<hyper::Response<Vec<u8>>, InternalError> {
        trace!("sending request with HTTP/1.1 sender");
        let mut this = self.0.lock().await;

        trace!("waiting for HTTP/1.1 sender to be ready");
        this.ready().await?;

        trace!("HTTP/1.1 sender is ready, sending request");
        Ok(this.send_request(req).await?.collect().await?)
    }
}

#[cfg(test)]
#[cfg(not(ci))]
mod test {
    use super::*;
    use crate::rt::{LocalExecutor, SendExecutor};
    use crate::tests::util::TokioExecutor;
    use crate::transport::http::hyper::sender::HyperConnect;
    use async_compat::Compat;
    use futures::executor::LocalPool;
    use futures::task::LocalSpawnExt;
    use http::{Method, Response, StatusCode, Version};
    use std::time::Duration;

    #[tokio::test]
    async fn send_executor() {
        let connector = HTTP1Connector(SendExecutor(TokioExecutor));
        let _ = tokio::spawn(
            connector.connect(Compat::new(
                tokio::net::TcpStream::connect("142.250.178.228:80")
                    .await
                    .unwrap(),
            )),
        )
        .await;
    }

    #[test]
    fn local_executor() {
        let mut pool = LocalPool::new();
        let spawner = pool.spawner();
        let connector = HTTP1Connector(LocalExecutor(spawner.clone()));
        let io = std::net::TcpStream::connect("188.184.77.250:80").unwrap();

        let io = async_io::Async::new(io).unwrap();
        let (s, r) = std::sync::mpsc::channel();

        let _ = spawner
            .spawn_local(async move {
                let c = connector.connect(io).await.unwrap();
                let response = c
                    .raw_send(
                        hyper::Request::builder()
                            .version(Version::HTTP_11)
                            .uri("http://www.cern.ch")
                            .method(Method::GET)
                            .body(crate::http::Body::default())
                            .unwrap(),
                    )
                    .await
                    .unwrap();
                assert_eq!(response.status(), StatusCode::NOT_FOUND);
                s.send(1).unwrap();
            })
            .unwrap();

        for _ in 1..500 {
            pool.run_until_stalled();
            std::thread::sleep(Duration::from_millis(10));
            if let Ok(1) = r.recv_timeout(Duration::from_millis(5)) {
                return;
            }
        }

        assert!(false);
    }

    #[tokio::test]
    async fn generic_executor() {
        trait SomeTest {
            async fn test(&self) -> Response<Vec<u8>>;
        }

        struct Wrapper<S>(S)
        where
            S: HyperConnect;

        impl<S> SomeTest for Wrapper<S>
        where
            S: HyperConnect,
        {
            async fn test(&self) -> Response<Vec<u8>> {
                let c = self
                    .0
                    .connect(Compat::new(
                        tokio::net::TcpStream::connect("142.250.178.228:80")
                            .await
                            .unwrap(),
                    ))
                    .await
                    .unwrap();

                let response = c
                    .raw_send(
                        hyper::Request::builder()
                            .version(Version::HTTP_11)
                            .uri("http://www.cern.ch")
                            .method(Method::GET)
                            .body(crate::http::Body::default())
                            .unwrap(),
                    )
                    .await
                    .unwrap();
                response
            }
        }

        let wrapper = Wrapper(HTTP1Connector(SendExecutor(TokioExecutor)));

        let _ = tokio::spawn(async move {
            eprintln!("{:?}", wrapper.test().await);
        })
        .await;
    }
}
