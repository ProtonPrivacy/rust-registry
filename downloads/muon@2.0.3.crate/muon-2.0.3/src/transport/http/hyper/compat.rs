use crate::rt::{LocalExecutor, LocalSpawner, SendExecutor, Sleep, Spawner};
use futures::task::{LocalSpawnExt, SpawnExt};
use futures::{AsyncRead, AsyncWrite};
use hyper::rt::{Read, ReadBuf, ReadBufCursor as Cursor, Write};
use pin_project::pin_project;
use std::io::Result as IoResult;
use std::pin::Pin;
use std::task::{Context, Poll, ready};

impl<S: futures::task::LocalSpawn, F> hyper::rt::Executor<F> for LocalExecutor<S>
where
    F: std::future::Future<Output = ()> + 'static,
{
    fn execute(&self, fut: F) {
        self.0.spawn_local(fut).unwrap()
    }
}

impl<S: futures::task::Spawn, F> hyper::rt::Executor<F> for SendExecutor<S>
where
    F: std::future::Future<Output = ()> + Send + 'static,
{
    fn execute(&self, fut: F) {
        self.0.spawn(fut).unwrap()
    }
}

pub trait ExecutorScope {}

impl<S: LocalSpawner> ExecutorScope for LocalExecutor<S> {}
impl<S: Spawner> ExecutorScope for SendExecutor<S> {}

/// A timer that can be injected into Hyper
pub(crate) struct HyperTimer<T>(pub(crate) T);

#[pin_project]
struct HyperSleep<F>(#[pin] F);

impl<F: Future> Future for HyperSleep<F> {
    type Output = ();

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        self.project().0.poll(cx).map(|_| ())
    }
}

impl<F: Future + Send + Sync> hyper::rt::Sleep for HyperSleep<F> {}

impl<T: Sleep + Send + Sync + Clone + 'static> hyper::rt::Timer for HyperTimer<T>
where
    for<'a> T::Sleep<'a>: Send + Sync,
{
    fn sleep(&self, duration: std::time::Duration) -> std::pin::Pin<Box<dyn hyper::rt::Sleep>> {
        let sleep = self.0.clone();
        Box::pin(HyperSleep(async move { sleep.sleep(duration).await }))
    }

    fn sleep_until(
        &self,
        deadline: std::time::Instant,
    ) -> std::pin::Pin<Box<dyn hyper::rt::Sleep>> {
        self.sleep(deadline - std::time::Instant::now())
    }
}

/// An adapter that converts between `futures` and `hyper` I/O traits.
#[pin_project]
#[derive(Debug)]
pub struct HyperIo<S>(#[pin] pub S);

impl<S: AsyncRead> Read for HyperIo<S> {
    fn poll_read(self: Pin<&mut Self>, cx: &mut Context, mut cur: Cursor) -> Poll<IoResult<()>> {
        let this = self.project().0;

        let buf = cur.as_slice_mut();
        let num = ready!(this.poll_read(cx, buf))?;
        unsafe { cur.advance(num) }; // nosemgrep

        Poll::Ready(Ok(()))
    }
}

impl<S: Read> AsyncRead for HyperIo<S> {
    fn poll_read(self: Pin<&mut Self>, cx: &mut Context, buf: &mut [u8]) -> Poll<IoResult<usize>> {
        let this = self.project().0;

        let mut buf = ReadBuf::new(buf);
        ready!(this.poll_read(cx, buf.unfilled()))?;
        let num = buf.filled().len();

        Poll::Ready(Ok(num))
    }
}

impl<S: Write> AsyncWrite for HyperIo<S> {
    fn poll_write(self: Pin<&mut Self>, cx: &mut Context, buf: &[u8]) -> Poll<IoResult<usize>> {
        self.project().0.poll_write(cx, buf)
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context) -> Poll<IoResult<()>> {
        self.project().0.poll_flush(cx)
    }

    fn poll_close(self: Pin<&mut Self>, cx: &mut Context) -> Poll<IoResult<()>> {
        self.project().0.poll_shutdown(cx)
    }
}

impl<S: AsyncWrite> Write for HyperIo<S> {
    fn poll_write(self: Pin<&mut Self>, cx: &mut Context, buf: &[u8]) -> Poll<IoResult<usize>> {
        self.project().0.poll_write(cx, buf)
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context) -> Poll<IoResult<()>> {
        self.project().0.poll_flush(cx)
    }

    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context) -> Poll<IoResult<()>> {
        self.project().0.poll_close(cx)
    }
}

trait AsSliceMut {
    fn as_slice_mut(&mut self) -> &mut [u8];
}

impl AsSliceMut for Cursor<'_> {
    fn as_slice_mut(&mut self) -> &mut [u8] {
        // nosemgrep
        unsafe {
            let this = self.as_mut();
            let this = std::ptr::from_mut(this);
            let this = this as *mut [u8];

            &mut *this
        }
    }
}
