use crate::transport::http::hyper::compat::HyperIo;
use futures::{AsyncRead, AsyncWrite};
use futures_rustls::TlsStream;
use hyper::upgrade::Upgraded;
use pin_project::pin_project;
use std::pin::Pin;
use std::task::{Context, Poll};

/// An abstraction over a socket.
/// - Socket that is in a TLS tunnel
/// - A plain TCP socket
/// - A Socket going through an HTTP Proxy
#[pin_project(project = AnySocketProj)]
pub(crate) enum AnySocket<IO> {
    Tls(#[pin] TlsStream<IO>),
    Plain(#[pin] IO),
    Proxied(#[pin] Box<AnySocket<HyperIo<Upgraded>>>),
}

impl<T: AsyncRead + AsyncWrite + Unpin> AsyncRead for AnySocket<T> {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context,
        buf: &mut [u8],
    ) -> Poll<std::io::Result<usize>> {
        match self.project() {
            AnySocketProj::Tls(mut pin) => pin.as_mut().poll_read(cx, buf),
            AnySocketProj::Plain(mut pin) => pin.as_mut().poll_read(cx, buf),
            AnySocketProj::Proxied(mut pin) => pin.as_mut().poll_read(cx, buf),
        }
    }
}

impl<T: AsyncRead + AsyncWrite + Unpin> AsyncWrite for AnySocket<T> {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context,
        buf: &[u8],
    ) -> Poll<std::io::Result<usize>> {
        match self.project() {
            AnySocketProj::Tls(mut pin) => pin.as_mut().poll_write(cx, buf),
            AnySocketProj::Plain(mut pin) => pin.as_mut().poll_write(cx, buf),
            AnySocketProj::Proxied(mut pin) => pin.as_mut().poll_write(cx, buf),
        }
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context) -> Poll<std::io::Result<()>> {
        match self.project() {
            AnySocketProj::Tls(mut pin) => pin.as_mut().poll_flush(cx),
            AnySocketProj::Plain(mut pin) => pin.as_mut().poll_flush(cx),
            AnySocketProj::Proxied(mut pin) => pin.as_mut().poll_flush(cx),
        }
    }

    fn poll_close(self: Pin<&mut Self>, cx: &mut Context) -> Poll<std::io::Result<()>> {
        match self.project() {
            AnySocketProj::Tls(mut pin) => pin.as_mut().poll_close(cx),
            AnySocketProj::Plain(mut pin) => pin.as_mut().poll_close(cx),
            AnySocketProj::Proxied(mut pin) => pin.as_mut().poll_close(cx),
        }
    }
}
