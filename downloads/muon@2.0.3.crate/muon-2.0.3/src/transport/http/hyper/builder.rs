use super::compat::ExecutorScope;
use super::connector::HyperConnector;
use super::sender::HyperConnect;
use crate::client::builder::{BaseBuilder, BuildTransport};
use crate::common::Proxy;
use crate::doh::{BUILTIN_DOH_SERVICES, DohService};
use crate::env::Environment;
use crate::fingerprint::NoInfo;
use crate::rand::{CryptoRng, DeriveRng};
use crate::rt::{
    HasSleepCapabilities, LocalExecutor, LocalSpawner, OperatingSystem, OsSleepFut, OsTime,
    SendExecutor, Spawner,
};
use crate::tls::certs::TlsCertDer;
use crate::tls::upgrader::OtherUpgrader;
use crate::tls::verifier::ProtonApiVerifier;
use crate::transport::http::hyper::http1::HTTP1Connector;
use crate::transport::http::hyper::http2::HTTP2Connector;
use crate::{ProtonRequest, ProtonResponse};
use rand_chacha::ChaCha20Rng;
use std::marker::PhantomData;
use std::sync::Arc;
pub struct MissingOs;
pub struct NoDanger;
pub struct Dangerous;

pub struct UnknownExecutor;

pub type HyperBuilder<
    OperatingSystem = MissingOs,
    Executor = UnknownExecutor,
    MaybeDanger = NoDanger,
    Storage = (),
    SessionKey = (),
    InfoProvider = NoInfo,
> = BaseBuilder<Hyper<OperatingSystem, Executor, MaybeDanger>, Storage, SessionKey, InfoProvider>;

pub struct Hyper<OperatingSystem = MissingOs, Executor = UnknownExecutor, MaybeDanger = NoDanger> {
    os: OperatingSystem,

    prng: Option<ChaCha20Rng>,

    spawner: Executor,

    // --- tls
    roots: Option<Vec<TlsCertDer>>,

    proxy: Proxy,

    // --- DNS ---
    doh: Vec<DohService>,

    marker: PhantomData<MaybeDanger>,
}

impl Default for Hyper {
    fn default() -> Self {
        Self {
            os: MissingOs,
            prng: None,
            roots: None,
            proxy: Proxy::NoProxy,
            doh: BUILTIN_DOH_SERVICES.to_vec(),
            marker: PhantomData,
            spawner: UnknownExecutor,
        }
    }
}

impl HyperBuilder {
    pub fn with_operating_system<OS: OperatingSystem>(
        self,
        os: OS,
        mut prng: impl CryptoRng,
    ) -> HyperBuilder<OS>
    where
        for<'a> OsSleepFut<'a, OS>: Send + Sync,
    {
        self.transform_inner(|inner| Hyper {
            roots: inner.roots,
            proxy: inner.proxy,
            doh: inner.doh,
            marker: inner.marker,
            os,
            spawner: inner.spawner,
            prng: Some(prng.derive()),
        })
    }
}

impl<OS: OperatingSystem> HyperBuilder<OS> {
    pub fn with_local_executor<Ex: LocalSpawner>(
        self,
        ex: Ex,
    ) -> HyperBuilder<OS, LocalExecutor<Ex>> {
        self.transform_inner(|inner| Hyper {
            roots: inner.roots,
            proxy: inner.proxy,
            doh: inner.doh,
            marker: inner.marker,
            os: inner.os,
            prng: inner.prng,
            spawner: LocalExecutor(ex),
        })
    }

    pub fn with_multi_thread_executor<Ex: Spawner>(
        self,
        ex: Ex,
    ) -> HyperBuilder<OS, SendExecutor<Ex>> {
        self.transform_inner(|inner| Hyper {
            roots: inner.roots,
            proxy: inner.proxy,
            doh: inner.doh,
            marker: inner.marker,
            os: inner.os,
            prng: inner.prng,
            spawner: SendExecutor(ex),
        })
    }
}

impl<OS: OperatingSystem, Ex: ExecutorScope> HyperBuilder<OS, Ex, NoDanger> {
    /// Enable the dangerous build features. Use this *only* in tests
    ///
    /// Note: dangerous features are all behind a feature flag
    #[cfg(feature = "dangerous")]
    pub fn dangerous(self) -> HyperBuilder<OS, Ex, Dangerous> {
        self.transform_inner(|inner| Hyper {
            roots: inner.roots,
            proxy: inner.proxy,
            doh: inner.doh,
            marker: PhantomData,
            os: inner.os,
            prng: inner.prng,
            spawner: inner.spawner,
        })
    }
}

impl<OS: OperatingSystem, Ex: ExecutorScope> HyperBuilder<OS, Ex, Dangerous> {
    /// Add additional trusted roots
    pub fn with_additional_roots(mut self, roots: impl IntoIterator<Item = TlsCertDer>) -> Self {
        self.inner.roots = Some(roots.into_iter().collect());
        self
    }
}

impl<OS, Ex> HyperBuilder<OS, Ex> {}

impl<OS: OperatingSystem, Ex, Danger> HasSleepCapabilities for Hyper<OS, Ex, Danger> {
    type Sleeper = OsTime<OS>;

    fn get_sleep_capability(&self) -> &Self::Sleeper {
        self.os.get_time_capabilities()
    }
}

impl<OS: OperatingSystem, Ex: Clone, MaybeDanger> BuildTransport<ProtonRequest, ProtonResponse>
    for Hyper<OS, Ex, MaybeDanger>
where
    for<'a> OsSleepFut<'a, OS>: Send + Sync,
    HTTP1Connector<Ex>: HyperConnect,
    HTTP2Connector<Ex, OS::Time>: HyperConnect,
{
    type Connector = HyperConnector<OS, Ex>;

    fn build(self, _: &crate::app::App, env: Arc<Environment>) -> crate::Result<Self::Connector> {
        let os = Arc::new(self.os);
        let proton_api_verifier = ProtonApiVerifier::new(env.clone(), self.roots.as_ref());

        Ok(HyperConnector::new(
            os,
            self.proxy,
            self.prng
                .ok_or(crate::Error::other("missing crypto safe prng"))?,
            self.doh,
            self.spawner.clone(),
            proton_api_verifier,
            OtherUpgrader::new_with_additional_roots(self.roots.unwrap_or_default()),
        ))
    }
}

impl<OS: OperatingSystem, Ex: Clone, MaybeDanger> HyperBuilder<OS, Ex, MaybeDanger>
where
    for<'a> OsSleepFut<'a, OS>: Send + Sync,
    HTTP1Connector<Ex>: HyperConnect,
    HTTP2Connector<Ex, OS::Time>: HyperConnect,
{
    /// Add DNS-over-HTTPS services to this client.
    pub fn doh(mut self, doh: impl IntoIterator<Item = DohService>) -> Self {
        let doh = doh.into_iter();
        self.inner.doh.extend(doh);
        self
    }

    /// Adds a proxy provider to this client.
    #[cfg(ci)]
    pub fn proxy(mut self, proxy: Proxy) -> Self {
        self.inner.proxy = proxy;
        self
    }
}
