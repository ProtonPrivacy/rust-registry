use crate::rt::SystemError;
use crate::{ErrorKind, InternalError};
use itertools::Itertools as _;
use std::error::Error;
use tracing::warn;

pub mod builder;
pub mod connector;
pub mod sender;

mod compat;
mod http1;
mod http2;
mod socket;

impl From<hyper::Error> for InternalError {
    fn from(err: hyper::Error) -> Self {
        if let Some(e) = err.source().and_then(|e| e.downcast_ref::<h2::Error>()) {
            warn!("h2 error: {}", error_stack(e));

            if e.is_remote() {
                if e.is_go_away() && e.reason() == Some(h2::Reason::NO_ERROR) {
                    return InternalError::TcpSend(SystemError::ConnectionReset);
                }

                if e.is_reset() && e.reason() == Some(h2::Reason::REFUSED_STREAM) {
                    return InternalError::TcpSend(SystemError::ConnectionReset);
                }
            }
        }

        if err.is_closed() || err.is_shutdown() {
            warn!("sender channel was closed");
            return InternalError::TcpSend(SystemError::BrokenPipe);
        }

        if err.is_timeout() {
            warn!("network operation timed out");
            return InternalError::TcpSend(SystemError::Timeout);
        }

        if err.is_canceled() || err.is_body_write_aborted() {
            return InternalError::TcpSend(SystemError::Interrupted);
        }

        InternalError::Irrecoverable(ErrorKind::send(err))
    }
}

fn error_stack(err: &(dyn Error + 'static)) -> String {
    let mut stack = Vec::new();
    let mut cause = Some(err);

    while let Some(e) = cause {
        stack.push(e);
        cause = e.source();
    }

    stack.into_iter().join(": ")
}
