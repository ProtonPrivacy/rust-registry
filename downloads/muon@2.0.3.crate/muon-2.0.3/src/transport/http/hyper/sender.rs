use crate::common::SendRequest;
use crate::http::{Body, BuildRequestUri, Version, trim_base};
use crate::rt::Socket;
use crate::transport::http::hyper::http1::HTTP1Sender;
use crate::transport::http::hyper::http2::HTTP2Sender;
use crate::{InternalError, ProtonRequest, ProtonResponse, Result};
use derive_more::From;
use futures::TryFutureExt as _;
use http::{Request, Response};
use std::sync::Arc;
use tracing::{debug, error, warn};

/// An abstraction over the capability to connect "http" over a socket
pub trait HyperConnect: 'static {
    type Fut: Future<Output = Result<HyperSender<Body>, InternalError>> + 'static;

    fn connect<IO: Socket>(&self, io: IO) -> Self::Fut;
}

/// A http request sender based on Hyper (either an HTTP1 or HTTP2)
#[derive(Debug)]
pub struct HyperSender<Body>(Arc<HyperSenderInner<Body>>);

impl<B> From<HTTP1Sender<B>> for HyperSender<B> {
    fn from(sender: HTTP1Sender<B>) -> Self {
        Self(Arc::new(HyperSenderInner::H1(sender)))
    }
}

impl<B> From<HTTP2Sender<B>> for HyperSender<B> {
    fn from(sender: HTTP2Sender<B>) -> Self {
        Self(Arc::new(HyperSenderInner::H2(sender)))
    }
}

impl HyperSender<Body> {
    pub async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, InternalError> {
        let req = match self.0.as_ref() {
            HyperSenderInner::H1(_) => req.build::<Self>(Version::HTTP_11)?,

            HyperSenderInner::H2(_) => req.build::<Self>(Version::HTTP_2)?,
        };
        debug!(?req, "sending request with hyper");

        self.raw_send(req)
            .await
            .inspect_err(|e| warn!("network error: {e:?}"))
            .map(Into::into)
            .map_err(InternalError::from)
    }
}

impl<B> BuildRequestUri for HyperSender<B> {
    fn build_req_uri(version: Version, uri: url::Url) -> (String, Option<String>) {
        if version == Version::HTTP_11 {
            (trim_base(&uri), uri.host_str().map(String::from))
        } else {
            (uri.to_string(), None)
        }
    }
}

impl<Body: http_body::Body + Send + 'static> HyperSender<Body> {
    pub(crate) async fn raw_send(
        &self,
        req: Request<Body>,
    ) -> Result<hyper::Response<Vec<u8>>, InternalError> {
        match self.0.as_ref() {
            HyperSenderInner::H1(sender) => sender
                .ready_send(req)
                .inspect_err(|e| error!(%e, "failed to send HTTP/1.1 request"))
                .await
                .map_err(InternalError::from),
            HyperSenderInner::H2(sender) => {
                sender
                    .ready_send(req)
                    .inspect_err(|e| error!(%e, "failed to send HTTP/2 request"))
                    .await
            }
        }
        .map_err(InternalError::from)
    }
}

impl<Body: http_body::Body + Send + std::fmt::Debug + 'static>
    SendRequest<Request<Body>, Response<Vec<u8>>> for HyperSender<Body>
{
    async fn send(&self, req: Request<Body>) -> Result<hyper::Response<Vec<u8>>, InternalError> {
        debug_assert!(match (self.0.as_ref(), req.version()) {
            (HyperSenderInner::H1(_), Version::HTTP_11) => true,

            (HyperSenderInner::H2(_), Version::HTTP_2) => true,

            _ => false,
        });

        self.raw_send(req).await.map_err(InternalError::from)
    }

    type Err = InternalError;
}

impl SendRequest<ProtonRequest, ProtonResponse> for HyperSender<Body> {
    async fn send(&self, req: ProtonRequest) -> Result<ProtonResponse, Self::Err> {
        self.send(req).await
    }

    type Err = InternalError;
}

impl<B> Clone for HyperSender<B> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}

#[derive(Debug, From)]
enum HyperSenderInner<Body> {
    H1(HTTP1Sender<Body>),
    H2(HTTP2Sender<Body>),
}

pub fn fmt_req<B>(req: &Request<B>) -> String {
    format!("{} {}", req.method(), req.uri())
}
