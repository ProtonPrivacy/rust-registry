//! An HTTP connector, responsible for returning a sender for a given server.

use super::compat::HyperIo;
use super::sender::{HyperConnect, HyperSender};
use crate::alternative_routing::resolve_indirect;
use crate::common::Scheme::*;
use crate::common::{
    Addr, BoundSender, ConnectTransport, DNS_UDP_QUERY, Endpoint, Host, Name,
    PROXY_TUNNEL_HTTP_CONNECT_TIMEOUT, ProtonConnectTransport, Proxy, Server, TCP_CONNECT_TIMEOUT,
    TLS_HANDSHAKE_TIMEOUT, WithTimeout as _,
};
use crate::doh::DohService;
use crate::http::Body;
use crate::rand::{CryptoRng, DeriveRng};
use crate::rt::{
    HasRandCapabilities, HasSleepCapabilities, IntoSystemError, OperatingSystem, OsSocket, OsTime,
    Resolve as _, Sleep, Socket, TcpConnect,
};
use crate::tls::alpn::{Alpn, H1, H2};
use crate::tls::upgrader::{MuonUpgrader, OtherUpgrader, ProtonApiTlsUpgrader};
use crate::tls::verifier::ProtonApiVerifier;
use crate::transport::http::hyper::http1::HTTP1Connector;
use crate::transport::http::hyper::http2::HTTP2Connector;
use crate::transport::http::hyper::socket::AnySocket;
use crate::util::TryRace;
use crate::{ErrorKind, InternalError, ProtonRequest, ProtonResponse, Result};
use derive_more::Debug;
use futures::TryFutureExt;
use http::Version;
use hyper::upgrade::{self, Upgraded};
use proton_os_interface::error::SystemError;
use rand_chacha::ChaCha20Rng;
use std::net::SocketAddr;
use std::sync::Arc;
use tracing::{debug, error, trace, warn};

// The ALPN protocols supported by the client.
#[cfg(feature = "http2")]
pub(crate) const SUPPORTED_HTTP_VERSIONS: &[Alpn] = &[H1, H2];

#[cfg(not(feature = "http2"))]
pub(crate) const SUPPORTED_HTTP_VERSIONS: &[Alpn] = &[H1];

#[allow(unused)]
#[derive(Debug, thiserror::Error)]
#[error("unsupported ALPN returned by server: {0:?}")]
pub struct AlpnErr(pub Alpn);

/// An HTTP connector using Hyper, responsible for returning a sender for a
/// given [`Server`].
///
/// This performs alternative routing in case of an [`Host::Indirect`]
#[derive(Debug)]
pub struct HyperConnector<OS: OperatingSystem, Ex> {
    os: Arc<OS>,
    proxy: Proxy,
    prng: spin::Mutex<ChaCha20Rng>,
    doh_services: Vec<DohService>,
    #[debug(skip)]
    http_connector: HttpConnector<Ex, OS::Time>,
    proton_api_verifier: ProtonApiVerifier,
    other_upgrader: OtherUpgrader,
}

impl<OS: OperatingSystem, Ex: Clone> HyperConnector<OS, Ex>
where
    HTTP1Connector<Ex>: HyperConnect,
    HTTP2Connector<Ex, OS::Time>: HyperConnect,
{
    /// Create a new HTTP connector.
    pub(crate) fn new(
        os: Arc<OS>,
        proxy: Proxy,
        mut prng: impl CryptoRng,
        doh_services: Vec<DohService>,
        executor: Ex,
        proton_api_verifier: ProtonApiVerifier,
        other_upgrader: OtherUpgrader,
    ) -> Self {
        Self {
            http_connector: HttpConnector::new(executor, os.get_time_capabilities().to_owned()),
            os,
            proton_api_verifier,
            other_upgrader,
            doh_services,
            prng: prng.derive::<ChaCha20Rng>().into(),
            proxy,
        }
    }

    async fn connect(
        &self,
        server: &Server,
        upgrader: MuonUpgrader<'_>,
    ) -> Result<BoundSender<HyperSender<Body>>, InternalError> {
        debug!("resolving server {server:?}");

        let srv_addr = match self.resolve(server.host()).await {
            Ok(addr) if !addr.is_empty() => {
                debug!("resolved {} server address(es)", addr.len());
                addr
            }
            // resolved but without address ?
            Ok(_) => {
                warn!("DNS resolution succeeded but returned no address");
                return Err(InternalError::TcpConnect(SystemError::InvalidData));
            }
            // bail out the error
            Err(err) => {
                error!(%err, "failed to resolve {}", server.host());
                return Err(err);
            }
        };

        let proxy = self.get_proxy_addresses_for(&server).await?;

        let (socket, name, alpn) = match self
            .dial(&server.endpoint, &srv_addr, &proxy, upgrader)
            .await
        {
            Ok((sock, name, alpn)) => {
                debug!(%name, "socket connected to server");
                (sock, name, alpn)
            }

            Err(err) => {
                debug!(%err, "failed to dial server");
                return Err(err);
            }
        };
        let base = server.base(name).map_err(ErrorKind::connect)?;

        self.http_connector
            .connect_with(socket, alpn)
            .await
            .map(|sender| BoundSender::new(sender, base))
            .map_err(InternalError::from)
    }

    async fn get_proxy_addresses_for(
        &self,
        server: &Server,
    ) -> Result<Option<(Endpoint, Vec<Addr>)>, InternalError> {
        if let Some(proxy) = self.proxy.proxy(&server.endpoint) {
            let proxy_addr = self
                .resolve(proxy.host())
                .await
                .inspect_err(|err| error!(%err, "failed to resolve {}", proxy.host()))?;
            debug!("resolved {} proxy server address(es)", proxy_addr.len());
            Ok(Some((proxy, proxy_addr)))
        } else {
            Ok(None)
        }
    }

    async fn resolve(&self, host: &Host) -> Result<Vec<Addr>, InternalError> {
        match host {
            Host::Direct(name) => Ok(self
                .os
                .get_resolver()
                .resolve(name)
                .with_timeout(self.os.get_time_capabilities(), DNS_UDP_QUERY)
                .await
                .map_err(InternalError::resolve)?
                .map_err(InternalError::resolve)?
                .into_iter()
                .map(|ip| Addr::new(name.to_owned(), ip))
                .collect()),

            Host::Indirect(name) => {
                Ok(resolve_indirect(name, self, &self.other_upgrader, &self.doh_services).await?)
            }
        }
    }

    async fn dial<'a>(
        &self,
        srv: &Endpoint,
        srv_addr: &'a [Addr],
        prx: &Option<(Endpoint, Vec<Addr>)>,
        upgrader: MuonUpgrader<'_>,
    ) -> Result<(AnySocket<OsSocket<OS>>, &'a Name, Option<Alpn>), InternalError> {
        let tcp_connector = self.os.get_tcp_connector();
        srv_addr
            .iter()
            .map(|addr| Box::pin(self.dial_addr(srv, addr, prx, tcp_connector, upgrader.clone())))
            .try_race()
            .await
    }

    async fn dial_addr<'a, Connector: TcpConnect>(
        &self,
        srv: &Endpoint,
        srv_addr: &'a Addr,
        prx: &Option<(Endpoint, Vec<Addr>)>,
        tcp_connector: &Connector,
        upgrader: MuonUpgrader<'_>,
    ) -> Result<(AnySocket<Connector::Socket>, &'a Name, Option<Alpn>), InternalError> {
        if let Some((prx, prx_addr)) = &prx {
            debug!("connecting to {srv_addr} via proxy");
            self.dial_addr_proxy(srv, srv_addr, prx, prx_addr, tcp_connector, upgrader)
                .map_ok(|(sock, alpn)| (sock, &srv_addr.name, alpn))
                .await
        } else {
            debug!("connecting to {srv_addr} directly");
            self.dial_addr_direct(
                srv,
                srv_addr,
                SUPPORTED_HTTP_VERSIONS,
                tcp_connector,
                upgrader,
            )
            .map_ok(|(sock, alpn)| (sock, &srv_addr.name, alpn))
            .await
        }
    }

    async fn dial_addr_direct<Connector: TcpConnect>(
        &self,
        srv: &Endpoint,
        addr: &Addr,
        alpn: &[Alpn],
        tcp_connector: &Connector,
        upgrader: MuonUpgrader<'_>,
    ) -> Result<(AnySocket<Connector::Socket>, Option<Alpn>), InternalError> {
        trace!("dialing {addr} directly");

        let sock = std::pin::pin!(tcp_connector.tcp_connect_split(addr.ip, srv.port()))
            .with_timeout(self.os.get_time_capabilities(), TCP_CONNECT_TIMEOUT)
            .await
            .map_err(|err| InternalError::connect(IntoSystemError::into_system_error(err)))?
            .map_err(|err| InternalError::connect(IntoSystemError::into_system_error(err)))?;

        if let Https = srv.scheme() {
            trace!("upgrading to TLS");
            let (sock, alpn) = std::pin::pin!(upgrader.upgrade(sock, &addr.name, alpn))
                .with_timeout(self.os.get_time_capabilities(), TLS_HANDSHAKE_TIMEOUT)
                .await
                .map_err(|err| {
                    InternalError::TcpConnect(IntoSystemError::into_system_error(err))
                })??;
            Ok((AnySocket::Tls(sock), alpn))
        } else {
            trace!("not upgrading to TLS");
            Ok((AnySocket::Plain(sock), None))
        }
    }

    async fn dial_addr_proxy_single<Connector: TcpConnect>(
        &self,
        srv: &Endpoint,
        srv_addr: &Addr,
        prx: &Endpoint,
        prx_addr: &Addr,
        tcp_connector: &Connector,
        upgrader: MuonUpgrader<'_>,
    ) -> Result<(AnySocket<Connector::Socket>, Option<Alpn>), InternalError> {
        let name = &srv_addr.name;
        debug!("attempting proxy connection on {prx_addr}");

        const TUNNEL_ALPN: [Alpn; 1] = [H1];

        let (sock, alpn) = self
            .dial_addr_direct(
                prx,
                prx_addr,
                &TUNNEL_ALPN,
                tcp_connector,
                MuonUpgrader::Other(&self.other_upgrader),
            )
            .await
            .inspect(|_| trace!("socket connected to {prx_addr}"))?;

        trace!("attempting HTTP tunneling");

        let sock = tunnel(
            sock,
            &self.http_connector,
            self.os.get_time_capabilities(),
            SocketAddr::new(srv_addr.ip, srv.port()),
            alpn,
        )
        .await
        .inspect(|_| trace!("socket tunneled to {srv_addr}"))?;

        let sock = HyperIo(sock);
        let (sock, alpn) = if let Https = srv.scheme() {
            trace!("upgrading to TLS");
            let (sock, alpn) = upgrader
                .upgrade(sock, name, SUPPORTED_HTTP_VERSIONS)
                .await?;
            (AnySocket::Tls(sock), alpn)
        } else {
            trace!("not upgrading to TLS");
            (AnySocket::Plain(sock), None)
        };

        return Ok((AnySocket::Proxied(sock.into()), alpn));
    }

    async fn dial_addr_proxy<Connector: TcpConnect>(
        &self,
        srv: &Endpoint,
        srv_addr: &Addr,
        prx: &Endpoint,
        prx_addr: &[Addr],
        tcp_connector: &Connector,
        upgrader: MuonUpgrader<'_>,
    ) -> Result<(AnySocket<Connector::Socket>, Option<Alpn>), InternalError> {
        for proxy in prx_addr {
            if let res @ Ok(_) = self
                .dial_addr_proxy_single(srv, srv_addr, prx, proxy, tcp_connector, upgrader.clone())
                .await
            {
                return res;
            }
        }

        Err(InternalError::Irrecoverable(ErrorKind::connect(
            "failing to connect to proxy",
        )))
    }
}

impl<OS: OperatingSystem, Ex> HasSleepCapabilities for HyperConnector<OS, Ex> {
    type Sleeper = OsTime<OS>;

    fn get_sleep_capability(&self) -> &Self::Sleeper {
        self.os.get_time_capabilities()
    }
}

impl<OS: OperatingSystem, Ex> HasRandCapabilities for HyperConnector<OS, Ex> {
    type Rng = ChaCha20Rng;

    fn get_prng(&self) -> Self::Rng {
        self.prng.lock().derive()
    }
}

impl<OS: OperatingSystem, Ex: Clone> ProtonConnectTransport<ProtonRequest, ProtonResponse>
    for HyperConnector<OS, Ex>
where
    HTTP1Connector<Ex>: HyperConnect,
    HTTP2Connector<Ex, OS::Time>: HyperConnect,
{
    async fn connect(
        &self,
        server: &Server,
    ) -> crate::Result<BoundSender<Self::Sender>, InternalError> {
        let proton_upgrader = ProtonApiTlsUpgrader::new(
            server.host().is_direct(),
            self.proton_api_verifier.clone(),
            self.os.get_time_capabilities().to_owned(),
        );
        let upgrader = MuonUpgrader::Proton(&proton_upgrader);

        <Self as ConnectTransport<ProtonRequest, ProtonResponse>>::connect(self, server, upgrader)
            .await
    }
}

impl<OS: OperatingSystem, Ex: Clone> ConnectTransport<ProtonRequest, ProtonResponse>
    for HyperConnector<OS, Ex>
where
    HTTP1Connector<Ex>: HyperConnect,
    HTTP2Connector<Ex, OS::Time>: HyperConnect,
{
    type Sender = HyperSender<Body>;

    async fn connect(
        &self,
        server: &Server,
        upgrader: MuonUpgrader<'_>,
    ) -> crate::Result<BoundSender<Self::Sender>, InternalError> {
        self.connect(server, upgrader).await
    }
}

/// A connector using hyper that allows to connect on either H1 or H2
#[derive(Debug, Clone)]
pub(crate) struct HttpConnector<S, Timer> {
    h1_connector: HTTP1Connector<S>,
    h2_connector: HTTP2Connector<S, Timer>,
}

impl<Ex: Clone, Timer> HttpConnector<Ex, Timer>
where
    HTTP1Connector<Ex>: HyperConnect,
    HTTP2Connector<Ex, Timer>: HyperConnect,
{
    pub fn new(ex: Ex, timer: Timer) -> Self {
        Self {
            h1_connector: HTTP1Connector(ex.clone()),
            h2_connector: HTTP2Connector::new(ex, timer),
        }
    }
}

impl<S, Timer: Sleep + Send + Sync> HttpConnector<S, Timer>
where
    HTTP1Connector<S>: HyperConnect,
    HTTP2Connector<S, Timer>: HyperConnect,
{
    async fn connect_with<IO: Socket>(
        &self,
        io: IO,
        alpn: Option<Alpn>,
    ) -> Result<HyperSender<Body>, InternalError> {
        match alpn {
            None => {
                trace!("defaulting to HTTP/1.1");
                self.h1_connector.connect(io).await
            }

            Some(H2) => {
                trace!("connecting to server using HTTP/2");
                self.h2_connector.connect(io).await
            }

            Some(H1) => {
                trace!("connecting to server using HTTP/1.1");
                self.h1_connector.connect(io).await
            }

            Some(alpn) => {
                error!(%alpn, "unsupported ALPN returned by server");
                return Err(ErrorKind::connect(AlpnErr(alpn)).into());
            }
        }
    }
}

/// Tunnel a `socket` going through an HTTP proxy
async fn tunnel<IO: Socket, Sleeper: Sleep + Send + Sync + Clone, S>(
    socket: IO,
    connector: &HttpConnector<S, Sleeper>,
    time: &Sleeper,
    addr: SocketAddr,
    alpn: Option<Alpn>,
) -> Result<Upgraded, InternalError>
where
    HTTP1Connector<S>: HyperConnect,
    HTTP2Connector<S, Sleeper>: HyperConnect,
{
    let conn = connector.connect_with(socket, alpn).await?;

    let req = http::Request::connect(addr.to_string())
        .version(Version::HTTP_11)
        .body(Body::default())?;

    let res: http::Response<Vec<u8>> = conn
        .raw_send(req)
        .with_timeout(time, PROXY_TUNNEL_HTTP_CONNECT_TIMEOUT)
        .await
        .map_err(|err| InternalError::TcpSend(err))??;

    Ok(upgrade::on(res).await.map_err(ErrorKind::connect)?)
}

#[cfg(test)]
#[cfg(not(ci))]
mod test {
    use super::*;
    use crate::rt::{LocalExecutor, SendExecutor};
    use crate::tests::util::{TokioExecutor, TokioTime};
    use crate::tls::alpn::H1;
    use async_compat::Compat;
    use futures::executor::LocalPool;
    use futures::task::LocalSpawnExt;
    use http::{Method, Response, StatusCode, Version};
    use std::time::Duration;

    #[tokio::test]
    async fn send_executor() {
        let connector: HttpConnector<SendExecutor<TokioExecutor>, TokioTime> = HttpConnector {
            h1_connector: HTTP1Connector(SendExecutor(TokioExecutor)),
            h2_connector: HTTP2Connector::new(SendExecutor(TokioExecutor), TokioTime::default()),
        };

        let sender = tokio::spawn(async move {
            connector
                .connect_with(
                    Compat::new(
                        tokio::net::TcpStream::connect("www.cern.ch:80")
                            .await
                            .unwrap(),
                    ),
                    Some(H1),
                )
                .await
                .unwrap()
        })
        .await
        .unwrap();

        let req = hyper::Request::builder()
            .uri("http://www.cern.ch")
            .method(Method::GET)
            .body(crate::http::Body::default())
            .unwrap();

        assert_eq!(
            tokio::spawn(async move { sender.raw_send(req).await })
                .await
                .unwrap()
                .unwrap()
                .status(),
            StatusCode::NOT_FOUND
        );
    }

    #[test]
    fn local_executor() {
        let mut pool = LocalPool::new();
        let spawner = pool.spawner();
        let connector = HTTP1Connector(LocalExecutor(spawner.clone()));
        let io = std::net::TcpStream::connect("www.cern.ch:80").unwrap();
        let io = async_io::Async::new(io).unwrap();
        let (s, r) = std::sync::mpsc::channel();

        let req = hyper::Request::builder()
            .version(Version::HTTP_11)
            .uri("http://www.cern.ch")
            .method(Method::GET)
            .body(crate::http::Body::default())
            .unwrap();

        let _ = spawner
            .spawn_local(async move {
                let c = connector.connect(io).await.unwrap();
                let response: Response<Vec<u8>> = c.raw_send(req).await.unwrap();
                assert_eq!(response.status(), StatusCode::NOT_FOUND);
                s.send(true).unwrap();
            })
            .unwrap();

        for _ in 1..5000 {
            pool.run_until_stalled();
            std::thread::sleep(Duration::from_millis(10));
            if let Ok(_) = r.recv_timeout(Duration::from_millis(5)) {
                return;
            }
        }

        assert!(false);
    }
}
