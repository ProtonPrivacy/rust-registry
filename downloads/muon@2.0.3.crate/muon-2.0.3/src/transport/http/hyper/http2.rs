///! This module contains all HTTP2 specific structures
use crate::common::{HTTP2_KEEP_ALIVE_INTERVAL, HTTP2_KEEP_ALIVE_TIMEOUT};
use crate::http::{Body, Collect};
use crate::rt::{LocalExecutor, SendExecutor, Sleep, Spawner};
use crate::transport::http::hyper::compat::{HyperIo, HyperTimer};
use crate::transport::http::hyper::sender::{HyperConnect, HyperSender};
use crate::{InternalError, Result};
use futures::FutureExt;
use futures::future::{BoxFuture, LocalBoxFuture};
use http::Request;
use hyper::client::conn::http2::{self, Builder, SendRequest};
use hyper::rt::Executor;
use tracing::trace;

/// A type that can perform a h2 handshake
#[derive(Debug, Clone)]
pub struct HTTP2Connector<S, Time> {
    spawner: S,
    time: Time,
}

impl<S, T> HTTP2Connector<S, T> {
    pub fn new(spawner: S, time: T) -> Self {
        Self { spawner, time }
    }
}

fn set_http2_params<Ex: Clone>(
    mut builder: http2::Builder<Ex>,
    time: impl hyper::rt::Timer + Send + Sync + 'static,
) -> Builder<Ex> {
    builder
        .timer(time)
        // Note: this is required to detect that the socket is always alive while the
        // stream is open (e.g., socket can die on hibernate or any network
        // glitch). Otherwise, the socket can stay open despite being dead under
        // the hood.
        .keep_alive_timeout(HTTP2_KEEP_ALIVE_TIMEOUT)
        // fixme(aboulmier): we might want to disable this to optimize for battery
        // consumption.
        .keep_alive_interval(HTTP2_KEEP_ALIVE_INTERVAL)
        // note(aboulmier): this *ensures* that we send keep alive *only* while the
        // stream is open, limiting the impact on battery. The behavior has been
        // verified by a packet capture. It is critical not to send keep-alive
        // while being idle!
        .keep_alive_while_idle(false)
        .to_owned()
}

impl<S: futures::task::LocalSpawn + Unpin + 'static, Time: Sleep + Send + Sync + Clone + 'static>
    HyperConnect for HTTP2Connector<LocalExecutor<S>, Time>
where
    LocalExecutor<S>: Clone,
    for<'a> Time::Sleep<'a>: Send + Sync,
{
    type Fut = LocalBoxFuture<'static, Result<HyperSender<Body>, InternalError>>;

    fn connect<IO: crate::rt::Socket>(&self, io: IO) -> Self::Fut {
        let spawner = self.spawner.clone();
        let time = self.time.clone();
        Box::pin(async move {
            let io = HyperIo(io);

            let (sender, driver) = set_http2_params(
                http2::Builder::new(spawner.clone()),
                HyperTimer(time.clone()),
            )
            .handshake(io)
            .await?;

            spawner.execute(driver.map(|_| ()));

            Ok(HTTP2Sender(sender).into())
        })
    }
}

impl<S: Spawner, Time: Sleep + Clone + Send + Sync + 'static> HyperConnect
    for HTTP2Connector<SendExecutor<S>, Time>
where
    SendExecutor<S>: Clone,
    for<'a> Time::Sleep<'a>: Send + Sync,
{
    type Fut = BoxFuture<'static, Result<HyperSender<Body>, InternalError>>;

    fn connect<IO: crate::rt::Socket>(&self, io: IO) -> Self::Fut {
        let spawner = self.spawner.clone();
        let time = self.time.clone();
        Box::pin(async move {
            let io = HyperIo(io);

            let (sender, driver) = set_http2_params(
                http2::Builder::new(spawner.clone()),
                HyperTimer(time.clone()),
            )
            .handshake(io)
            .await?;

            spawner.execute(driver.map(|_| ()));

            Ok(HTTP2Sender(sender).into())
        })
    }
}

/// A type that can send HTTP2 requests
#[derive(Debug)]
pub(super) struct HTTP2Sender<B>(SendRequest<B>);

impl<B: http_body::Body + Send + 'static> HTTP2Sender<B> {
    pub(super) async fn ready_send(
        &self,
        req: Request<B>,
    ) -> Result<hyper::Response<Vec<u8>>, InternalError> {
        trace!("sending request with HTTP/2 sender");
        let mut this = self.0.clone();

        trace!("waiting for HTTP/2 sender to be ready");
        this.ready().await?;

        trace!("HTTP/2 sender is ready, sending request");
        Ok(this.send_request(req).await?.collect().await?)
    }
}

#[cfg(test)]
#[cfg(not(ci))]
mod test {
    use super::*;
    use crate::rt::{LocalExecutor, SendExecutor};
    use crate::tests::util::local::TimerManager;
    use crate::tests::util::{TokioExecutor, TokioTime};
    use async_compat::Compat;
    use futures::executor::LocalPool;
    use futures::task::LocalSpawnExt;
    use std::time::Duration;

    #[tokio::test]
    async fn send_executor() {
        let connector = HTTP2Connector::new(SendExecutor(TokioExecutor), TokioTime::default());
        let _ = tokio::spawn(
            connector.connect(Compat::new(
                tokio::net::TcpStream::connect("142.250.178.228:80")
                    .await
                    .unwrap(),
            )),
        )
        .await;
    }

    #[test]
    fn local_executor() {
        let mut pool = LocalPool::new();
        let spawner = pool.spawner();
        let time = TimerManager::default();
        let connector = HTTP2Connector::new(LocalExecutor(spawner.clone()), time.clone());
        let io = std::net::TcpStream::connect("www.cern.ch:80").unwrap();

        let io = async_io::Async::new(io).unwrap();
        let (s, r) = std::sync::mpsc::channel();

        let _ = spawner
            .spawn_local(async move {
                let _ = connector.connect(io).await.unwrap();
                s.send(1).unwrap();
            })
            .unwrap();

        for _ in 1..50 {
            pool.run_until_stalled();
            std::thread::sleep(Duration::from_millis(100));
            time.advance_to_now();
            if let Ok(1) = r.recv_timeout(Duration::from_millis(100)) {
                return;
            }
        }

        assert!(false);
    }
}
