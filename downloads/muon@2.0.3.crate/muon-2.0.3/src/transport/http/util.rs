use crate::http::HttpReq;
use derive_more::{AsRef, Debug, Deref, Display, From, Into};
use itertools::Itertools as _;
use std::any::{Any, TypeId, type_name};
use std::collections::HashMap;
/// A tag applied to every request by the `Tagger` layer.
#[derive(Debug, Display, AsRef, Deref, Clone, Copy)]
#[derive(PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Tag(usize);

impl Tag {
    /// Get the tag of a request, if one is present.
    #[must_use]
    pub fn get(req: &HttpReq) -> Option<&Self> {
        req.get_extension()
    }
}

/// A type map: enables storing and retrieving types by type.
///
/// This is useful for storing types that are not known at compile time,
/// such as metadata for a request/response as it passes through layers.
#[derive(Debug, Display, Default, From, Into, Clone)]
#[debug("{:?}", map.keys())]
#[display("[{}]", map.keys().join(", "))]
pub struct TypeMap {
    map: HashMap<TypeName, BoxObj>,
}

impl TypeMap {
    /// Insert a type into this type map.
    /// If a type of this type already existed, it will be returned.
    pub fn insert<T: Clone + Send + Sync + 'static>(&mut self, val: T) -> Option<T> {
        let k = TypeName::of::<T>();
        let v = Box::new(val);

        if let Some(t) = self.map.insert(k, v) {
            t.into_any().downcast().ok().map(|t| *t)
        } else {
            None
        }
    }

    /// Get a reference to a type previously inserted on this type map.
    /// If the type was not found, `None` is returned.
    #[must_use]
    pub fn get<T: 'static>(&self) -> Option<&T> {
        let k = TypeName::of::<T>();
        let t = self.map.get(&k);

        if let Some(t) = t {
            t.as_ref().as_any().downcast_ref()
        } else {
            None
        }
    }

    /// Get a mutable reference to a type previously inserted on this type map.
    /// If the type was not found, `None` is returned.
    pub fn get_mut<T: 'static>(&mut self) -> Option<&mut T> {
        let k = TypeName::of::<T>();
        let t = self.map.get_mut(&k);

        if let Some(t) = t {
            t.as_mut().as_any_mut().downcast_mut()
        } else {
            None
        }
    }

    /// Remove a type from this type map.
    /// If the type was found, it is returned.
    pub fn remove<T: 'static>(&mut self) -> Option<T> {
        let k = TypeName::of::<T>();
        let t = self.map.remove(&k);

        if let Some(t) = t {
            t.into_any().downcast().ok().map(|t| *t)
        } else {
            None
        }
    }
}

/// `TypeName` is like `TypeId` but records the name of the type as well.
#[derive(Debug, Display, Clone, Copy)]
#[debug("{name}")]
#[display("{name}")]
struct TypeName {
    id: TypeId,
    name: &'static str,
}

impl TypeName {
    fn of<T: 'static>() -> Self {
        Self {
            id: TypeId::of::<T>(),
            name: type_name::<T>(),
        }
    }
}

impl PartialEq for TypeName {
    fn eq(&self, other: &Self) -> bool {
        self.id == other.id
    }
}

impl Eq for TypeName {
    // ...
}

impl core::hash::Hash for TypeName {
    fn hash<H: core::hash::Hasher>(&self, state: &mut H) {
        self.id.hash(state);
    }
}

/// A boxed object.
type BoxObj = Box<dyn Obj + Send + Sync>;

/// `Obj` is like `Any` but better.
trait Obj: Any {
    /// `self` can be anything; return a clone of it as a boxed `Obj`.
    fn clone(&self) -> BoxObj;

    /// Return a reference to the `Any` trait object.
    fn as_any(&self) -> &dyn Any;

    /// Return a mutable reference to the `Any` trait object.
    fn as_any_mut(&mut self) -> &mut dyn Any;

    /// Convert `self` (a boxei concrete type) into a boxed `Any` trait object.
    fn into_any(self: Box<Self>) -> BoxAny;
}

impl<T: Clone + Any + Send + Sync> Obj for T {
    fn clone(&self) -> BoxObj {
        Box::new(Clone::clone(self))
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn Any {
        self
    }

    fn into_any(self: Box<Self>) -> BoxAny {
        self
    }
}

impl Clone for BoxObj {
    fn clone(&self) -> Self {
        // Get the trait object.
        let this: &dyn Obj = &**self;

        // Clone the trait object into a boxed trait object.
        let this: BoxObj = Obj::clone(this);

        // Return the cloned trait object.
        this
    }
}

impl std::fmt::Debug for BoxObj {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "{:?}", self.as_any())
    }
}

/// A boxed any.
type BoxAny = Box<dyn Any>;

#[cfg(test)]
mod tests_typemap {
    use super::*;

    #[test]
    fn crud() {
        let mut tm = TypeMap::default();
        let abc = "abc".to_string();
        let def = "def".to_string();
        assert_eq!(tm.insert(Clone::clone(&abc)), None);
        assert_eq!(tm.insert(Clone::clone(&def)), Some(abc));
        assert_eq!(tm.get::<String>(), Some(&def));

        let onetwothree = 123;
        assert_eq!(tm.insert(onetwothree), None);
        assert_eq!(tm.remove::<String>(), Some(def));
    }
}

#[cfg(test)]
mod tests_obj {
    use super::*;

    #[test]
    fn crud() {
        let v = 123;
        let mut obj1 = Box::new(v) as BoxObj;
        let mut obj2 = Obj::clone(&obj1);
        assert_eq!(
            obj1.as_any().downcast_ref::<i32>(),
            obj2.as_any().downcast_ref::<i32>()
        );
        assert_eq!(
            obj1.as_any_mut().downcast_ref::<i32>(),
            obj2.as_any_mut().downcast_ref::<i32>()
        );
    }
}
