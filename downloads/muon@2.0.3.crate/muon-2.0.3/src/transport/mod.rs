/// Defines how to transport API requests via the HTTP protocol
pub mod http;
