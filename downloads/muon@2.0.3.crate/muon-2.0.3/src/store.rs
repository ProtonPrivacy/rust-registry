use crate::auth::Auth;
use crate::sessions::SessionKeyable;
use async_lock::RwLock;
use derive_more::Display;
use std::collections::HashMap;
use std::marker::PhantomData;
use std::sync::Arc;
use tracing::{debug, error, info, warn};

/// A trait defining the contract for persistent session storage.
///
/// This is the core abstraction that decouples the client from any specific
/// storage backend (e.g., in-memory, file system, database). By implementing
/// this trait, applications provide their own logic for how and where session
/// data ([`Auth`]) is saved.
///
/// The trait is generic over a [`SessionKeyable`] type, which allows it to
/// support both single-session and multi-session applications seamlessly.
///
/// # Important
/// This trait is on-purpose _NOT_ async. From the point of view of Muon,
/// storing auth is a "fire-and-forget" approach. Muon does not care if it
/// succeed or not. For loading, this is done _once_ on loading and it is
/// expected to be a blocking operation for Muon (as the engine can not start
/// without it). !! If your persistence storage implementation is slow, you
/// should pre-load it asynchronously _BEFORE_ feeding it to your Muon client.
/// !!
pub trait Store: std::fmt::Debug {
    /// The session key type
    type Key: SessionKeyable;

    /// Sets or updates the authentication state for a given session key.
    ///
    /// # important
    /// A good implementation of this function should not block.Use a thread or
    /// an async task to perform the real operation
    ///
    /// # Note
    /// If the key already exists, its value is updated. If it does not exist, a
    /// new entry is created.
    ///
    /// The provided `auth` state must not be [`Auth::None`]. To clear a
    /// session, [`remove_auth`](Store::remove_auth) must be used instead.
    fn set_auth(&mut self, key: Self::Key, auth: Auth);

    /// Removes a session key and its associated authentication state from the
    /// store.
    ///
    /// # important
    /// A good implementation of this function should not block. Use a thread or
    /// an async task to perform the real operation
    fn remove_auth(&mut self, key: &Self::Key);

    /// Retrieves a map of all persisted session keys and their authentication
    /// states.
    ///
    /// # important
    /// A good implementation of this function should not block. Preloading
    /// should be considered.
    ///
    /// # Note
    /// The returned map must not contain any entries where the value is
    /// [`Auth::None`].
    fn get_all_auth(&self) -> HashMap<Self::Key, Auth>;

    /// Replaces all authentication states in the store with the provided map.
    ///
    /// # important
    /// A good implementation of this function should not block. Use a thread or
    /// an async task to perform the real operation
    ///
    /// This is a destructive operation that completely overwrites the existing
    /// stored data. Any keys not present in the new `auth` map will be removed.
    /// The provided map is not expected to contain any [`Auth::None`]
    /// values.
    fn set_all_auth(&mut self, auth: HashMap<Self::Key, Auth>) {
        auth.into_iter()
            .for_each(|(key, auth)| self.set_auth(key, auth))
    }

    /// Removes all authentication states from the store.
    ///
    /// # important
    /// A good implementation of this function should not block. Use a thread or
    /// an async task to perform the real operation
    ///
    /// After this operation, a call to [`get_all_auth`](Store::get_all_auth)
    /// should return an empty map.
    fn remove_all_auth(&mut self) {
        self.get_all_auth()
            .into_iter()
            .for_each(|(key, _)| self.remove_auth(&key));
    }
}

/// We inserted a uid twice in Muon.
/// This is forbidden.
#[derive(Debug, thiserror::Error)]
#[error("{0}")]
pub struct DuplicateUidError(String);

impl DuplicateUidError {
    pub fn new(key1: impl std::fmt::Debug, key2: impl std::fmt::Debug, uid: Option<&str>) -> Self {
        let err = format!(
            "Inserting SessionKey = {0:?}, Existing SessionKey = {1:?}, both have the same UID {2:?}",
            key1, key2, uid
        );
        Self(err)
    }
}

#[derive(Debug)]
struct AuthStorage<PersistentStorage>
where
    PersistentStorage: Store,
{
    /// The local in-memory store
    local_store: HashMap<PersistentStorage::Key, Auth>,
    /// The persistence storage, to disable SSO, [`WithoutPersistence`] is used
    /// as a blackhole.
    persistent_store: PersistentStorage,
}

impl<S: Store> AuthStorage<S> {
    fn new(persistent_store: S) -> Self {
        Self {
            local_store: persistent_store.get_all_auth(),
            persistent_store,
        }
    }

    fn remove_all_auth(&mut self) {
        self.local_store.clear();
        self.persistent_store.remove_all_auth();
    }

    fn remove_auth(&mut self, key: &S::Key) -> Option<Auth> {
        self.persistent_store.remove_auth(key);
        self.local_store.remove(key)
    }

    pub(crate) fn set_auth(&mut self, key: S::Key, auth: Auth) -> Result<(), DuplicateUidError> {
        // We check no other session exist with the same UID
        let existing_sessions = self.get_all_auth();

        // Don't include an existing session with the same key
        // since it will get overriden in the check
        let existing_sessions = existing_sessions.filter(|(stored_key, _)| &key != *stored_key);

        for (stored_key, stored_auth) in existing_sessions {
            if stored_auth.uid() == auth.uid() {
                return Err(DuplicateUidError::new(key, stored_key.clone(), auth.uid()));
            }
        }

        self.local_store.insert(key.clone(), auth.clone());
        self.persistent_store.set_auth(key, auth);
        Ok(())
    }

    fn get_all_auth(&self) -> impl Iterator<Item = (&S::Key, &Auth)> {
        self.local_store.iter()
    }
}

#[derive(Debug)]
pub(crate) struct Versioned<AuthStore: Store> {
    store: AuthStorage<AuthStore>,
    version: HashMap<AuthStore::Key, AuthVersion>,
}

impl<S: Store> Versioned<S> {
    pub(crate) fn new(store: S) -> Self {
        let store = AuthStorage::new(store);
        debug!("loading the persistence storage");
        let version = store
            .get_all_auth()
            .map(|(key, _)| (key.clone(), AuthVersion::default()))
            .collect();
        Self { store, version }
    }

    pub(crate) fn get_all_auth(&self) -> HashMap<S::Key, (Auth, AuthVersion)> {
        self.store
            .get_all_auth()
            .zip(self.version.iter())
            .map(|((key, auth), (_, version))| (key.clone(), (auth.clone(), *version)))
            .collect()
    }

    pub(crate) fn get_auth(&self, session_key: &S::Key) -> (Auth, AuthVersion) {
        let version = self.version.get(session_key).copied().unwrap_or_default();
        let auth = self
            .store
            .local_store
            .get(session_key)
            .cloned()
            .unwrap_or(Auth::None);
        info!("Getting from the store `{session_key:?}` -> `{auth:?}`");
        (auth, version)
    }

    pub(crate) fn set_auth(
        &mut self,
        key: S::Key,
        auth: Auth,
    ) -> Result<AuthVersion, DuplicateUidError> {
        info!("Setting to the store `{key:?}` -> `{auth:?}`");

        // The store assumes it will never have anything asked to be set to None
        // Setting to None should call remove
        if auth == Auth::None {
            warn!("Can't set the store key `{key:?}` to `None`, using remove fallback.");
            self.store.remove_auth(&key);
            return Ok(AuthVersion::default());
        }

        self.store.set_auth(key.clone(), auth)?;

        Ok(*self
            .version
            .entry(key)
            .and_modify(|version| version.upgrade())
            .or_default())
    }

    pub(crate) fn remove_auth(&mut self, key: &S::Key) -> (Option<Auth>, AuthVersion) {
        info!("Removing from the store {key:?}");
        let auth = self.store.remove_auth(key);
        let version = self.version.remove(key).unwrap_or_default();
        (auth, version)
    }

    pub(crate) fn remove_all_auth(&mut self) {
        let count = self.version.len();
        info!(count, "Removing from all the sessions from Muon");
        self.store.remove_all_auth();
        self.version.clear();
    }

    pub(crate) fn sync_stores(&mut self) {
        self.store
            .persistent_store
            .set_all_auth(self.store.local_store.clone());
    }
}

#[derive(Debug)]
pub(crate) struct SharedVersionedStorage<S: Store>(Arc<RwLock<Versioned<S>>>);

impl<S: Store> SharedVersionedStorage<S> {
    pub fn new(storage: S) -> Self {
        Self(Arc::new(RwLock::new(Versioned::new(storage))))
    }
}

impl<S: Store> Clone for SharedVersionedStorage<S> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}

impl<S: Store> SharedVersionedStorage<S> {
    pub async fn read(&self) -> impl std::ops::Deref<Target = Versioned<S>> {
        self.0.read().await
    }

    pub async fn write(&self) -> impl std::ops::DerefMut<Target = Versioned<S>> {
        self.0.write().await
    }
}

/// An auth version.
///
/// This is used to track changes to the auth data.
/// Each time the auth data is updated, the version is incremented.
#[derive(Debug, Display, Default, Clone, Copy, PartialEq, Eq)]
pub struct AuthVersion(usize);

impl AuthVersion {
    fn upgrade(&mut self) {
        self.0 += 1;
    }
}

#[derive(Debug)]
pub struct WithoutPersistence<T: 'static>(PhantomData<T>);

impl<T> Default for WithoutPersistence<T> {
    fn default() -> Self {
        Self(Default::default())
    }
}

impl<T: SessionKeyable> Store for WithoutPersistence<T> {
    type Key = T;

    fn set_auth(&mut self, _: Self::Key, _: Auth) {}

    fn remove_auth(&mut self, _: &Self::Key) {}

    fn get_all_auth(&self) -> HashMap<Self::Key, Auth> {
        HashMap::with_capacity(0)
    }
}

#[cfg(test)]
mod tests {
    use crate::auth::Scopes;
    use crate::store::{Versioned, WithoutPersistence};

    #[test]
    fn duplicate_key() {
        let mut store = Versioned::new(WithoutPersistence::<String>::default());
        const UID: &str = "abc";
        store
            .set_auth(
                "key1".to_owned(),
                crate::auth::Auth::Internal {
                    user_id: UID.to_owned(),
                    uid: UID.to_owned(),
                    tok: crate::auth::Tokens::Access {
                        acc_tok: "".to_owned(),
                        ref_tok: "".to_owned(),
                        scopes: Scopes::default(),
                    },
                },
            )
            .expect("first is fine");

        store
            .set_auth(
                "key2".to_owned(),
                crate::auth::Auth::Internal {
                    user_id: UID.to_owned(),
                    uid: UID.to_owned(),
                    tok: crate::auth::Tokens::Access {
                        acc_tok: "".to_owned(),
                        ref_tok: "".to_owned(),
                        scopes: Scopes::default(),
                    },
                },
            )
            .unwrap_err();
    }
}
