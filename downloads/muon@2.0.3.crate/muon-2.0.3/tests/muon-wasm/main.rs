//! # Muon WebAssembly Tests
#![cfg(target_family = "wasm")]
/// Tests against the CI atlas server.
mod atlas;
