use crate::os::{TestBuilder, TestClient, TestOs};
use muon::client::builder::Hyper;
use muon::env::Env;
use muon::tls::pins::{TlsPin, TlsPinSet};
use muon::{App, Client, Environment, SessionKeyable};
use muon_test_server::os::{StdTime, TokioExecutor, TokioResolver, TokioTcpConnector};
use muon_test_server::server::env::TestEnv;
use muon_test_server::server::{HTTP, Server};
use serde_json::{Value, json};
use std::sync::Arc;
use std::time::Duration;

/// Very simple ping tests.
mod ping;

/// Auth (SRP) tests.
mod auth;

/// Request building and sending tests.
mod request;

/// Retry handling tests.
mod retries;

/// Timeout tests.
mod timeout;

/// Drop tests.
mod drop;

/// Session tests.
mod session;

struct SessionDetails<'a> {
    uid: &'a str,
    user_id: Option<&'a str>,
    access_token: &'a str,
    refresh_token: &'a str,
}

const SESSION: SessionDetails = SessionDetails {
    uid: "a50e8400-e29b-41d4-a716-446655440000",
    user_id: Some("b50e8400-e29b-41d4-a716-446655440001"),
    access_token: "c50e8400-e29b-41d4-a716-446655440002",
    refresh_token: "d50e8400-e29b-41d4-a716-446655440003",
};

const SESSION_TWO: SessionDetails = SessionDetails {
    uid: "a90e8400-e29b-41d4-a716-446655440000",
    user_id: Some("b90e8400-e29b-41d4-a716-446655440001"),
    access_token: "c90e8400-e29b-41d4-a716-446655440002",
    refresh_token: "d90e8400-e29b-41d4-a716-446655440003",
};

const UNAUTH_SESSION: SessionDetails = SessionDetails {
    uid: "ffffffff-e29b-41d4-a716-446655440000",
    user_id: None,
    access_token: "ffffffff-e29b-41d4-a716-446655440002",
    refresh_token: "ffffffff-e29b-41d4-a716-446655440003",
};

fn session_json() -> Value {
    json!({
        "UID": SESSION.uid,
        "UserID": SESSION.user_id,
        "AccessToken": SESSION.access_token,
        "RefreshToken": SESSION.refresh_token,
        "Scopes": [],
    })
}

fn session_two_json() -> Value {
    json!({
        "UID": SESSION_TWO.uid,
        "UserID": SESSION_TWO.user_id,
        "AccessToken": SESSION_TWO.access_token,
        "RefreshToken": SESSION_TWO.refresh_token,
        "Scopes": [],
    })
}

fn unauth_session_json() -> Value {
    json!({
        "UID": UNAUTH_SESSION.uid,
        "UserID": UNAUTH_SESSION.user_id,
        "AccessToken": UNAUTH_SESSION.access_token,
        "RefreshToken": UNAUTH_SESSION.refresh_token,
        "Scopes": [],
    })
}

#[derive(Debug, Clone)]
struct MuonTestEnv {
    servers: Vec<muon::common::Server>,
    api_pins: Option<TlsPinSet>,
}

impl From<TestEnv> for MuonTestEnv {
    fn from(env: TestEnv) -> Self {
        MuonTestEnv {
            servers: env
                .servers
                .iter()
                .filter_map(|srv_url| srv_url.parse().ok())
                .collect(),

            api_pins: env
                .api_pins
                .map(|pins| TlsPinSet::new(pins.into_iter().map(TlsPin::new))),
        }
    }
}

impl Env for MuonTestEnv {
    fn servers(&self, _: &muon::app::AppVersion) -> Vec<muon::common::Server> {
        self.servers.clone()
    }

    fn ar_pins(&self) -> Option<&muon::tls::pins::TlsPinSet> {
        None
    }

    fn api_pins(&self) -> Option<&muon::tls::pins::TlsPinSet> {
        self.api_pins.as_ref()
    }
}

trait ServerExt {
    fn default() -> Arc<Self>;
    /// Create a new muon client for this server.
    ///
    /// This is a convenience function that automatically configures the
    /// client's environment to target this server.
    ///
    /// # Panics
    ///
    /// Panics if the client cannot be built.
    fn client<Key: SessionKeyable + 'static>(self: &Arc<Self>) -> TestClient<Key> {
        self.client_for(App::default())
    }

    /// Create a new muon client for this server for the given app.
    fn client_for<Key: SessionKeyable + 'static>(self: &Arc<Self>, app: App) -> TestClient<Key> {
        self.builder_for(app)
            .build()
            .expect("test configuration should be valid")
    }

    /// Create a new muon client builder for this server.
    ///
    /// This is a convenience function that automatically configures the
    /// client's environment to target this server.
    ///
    /// # Panics
    ///
    /// Panics if the client builder cannot be built.
    fn builder<Key: SessionKeyable + 'static>(self: &Arc<Self>) -> TestBuilder<Key> {
        self.builder_for(App::default())
    }

    /// Create a new muon client builder for this server for the given app.
    fn builder_for<Key: SessionKeyable + 'static>(self: &Arc<Self>, app: App) -> TestBuilder<Key>;
}

impl ServerExt for Server {
    /// Create a new muon client builder for this server for the given app.
    fn builder_for<Key: SessionKeyable + 'static>(self: &Arc<Self>, app: App) -> TestBuilder<Key> {
        let env = Environment::new_custom(MuonTestEnv::from(self.env()));

        let os = TestOs {
            time: StdTime::default().into(),
            tcp_connector: TokioTcpConnector::default().into(),
            resolver: TokioResolver::default().into(),
        };

        Client::builder_with_transport::<Hyper>(app, env)
            .with_operating_system(os, rand::rng())
            .with_multi_thread_executor(TokioExecutor)
            .dangerous()
            .with_additional_roots(Some(self.ca_der()))
            .without_persistence::<Key>()
    }

    fn default() -> Arc<Self> {
        let rt = tokio::runtime::Handle::current();
        let s = Server::new(&rt, &HTTP).expect("failed to create local server");
        tokio::time::sleep(Duration::from_millis(5));
        s
    }
}
