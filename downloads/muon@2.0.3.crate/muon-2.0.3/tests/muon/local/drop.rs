use crate::local::ServerExt as _;
use anyhow::Result;
use muon::GET;
use muon_test_server::server::{HTTP, Server};
use std::sync::Arc;

#[tokio::test]
async fn test_dropout() -> Result<()> {
    let s = Server::default();

    let c = s.client();
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // Send a request to establish a connection.
    unauth_session.send(GET!("/tests/ping")).await?.ok()?;

    // Forcibly close all connections server-side.
    // TODO: How to do this with axum?

    // Send a request to ensure the client reconnects.
    unauth_session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
