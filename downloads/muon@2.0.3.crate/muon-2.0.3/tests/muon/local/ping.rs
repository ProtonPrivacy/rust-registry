use crate::local::ServerExt as _;
use anyhow::Result;
use muon::GET;
use muon_test_server::server::{HTTP, HTTPS, Server};
use std::sync::Arc;
#[tokio::test]
async fn test_ping_http() -> Result<()> {
    let rt = tokio::runtime::Handle::current();
    let s = Server::new(&rt, &HTTP)?;
    s.client()
        .new_session_without_credentials("unauth".to_string())
        .await?
        .send(GET!("/tests/ping"))
        .await?
        .ok()?;

    Ok(())
}

#[tokio::test]
async fn test_ping_https() -> Result<()> {
    let rt = tokio::runtime::Handle::current();
    let s = Server::new(&rt, &HTTPS)?;
    let c = s.client();

    let s = c
        .new_session_without_credentials("unauth".to_string())
        .await?;

    s.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
