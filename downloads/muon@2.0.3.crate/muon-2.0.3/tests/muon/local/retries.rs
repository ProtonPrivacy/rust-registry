use crate::local::ServerExt;
use anyhow::Result;
use muon::GET;
use muon::common::RetryPolicy;
use muon_test_server::server::{Response, Server};
use std::sync::Arc;

#[tokio::test]
async fn test_handle_429_once() -> Result<()> {
    let s = Server::default();
    let p = RetryPolicy::default().max_count(2);
    let c = s.client();
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // Succeeds on third request (second retry).
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(429)));
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(429)));
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(200)));
    assert!(
        unauth_session
            .send(GET!("/foo").retry_policy(p))
            .await?
            .ok()
            .is_ok()
    );

    Ok(())
}

#[tokio::test]
async fn test_handle_429() -> Result<()> {
    let s = Server::default();
    let p = RetryPolicy::default().max_count(1);
    let r = s.new_recorder();
    let c = s.client();
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // Succeeds on second request (first retry).
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(429)));
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(200)));
    assert!(
        unauth_session
            .send(GET!("/foo").retry_policy(p))
            .await?
            .ok()
            .is_ok()
    );

    // Should have made three requests (unauth session + original + retry).
    assert_eq!(r.take().len(), 3);

    // Would succeed on third request (second retry), but fails due to retry limit.
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(429)));
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(429)));
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(200)));
    assert!(
        unauth_session
            .send(GET!("/foo").retry_policy(p))
            .await?
            .ok()
            .is_err()
    );

    // Should have made two requests (original + retry).
    // Unauth session request is made for the first request only.
    assert_eq!(r.take().len(), 2);

    Ok(())
}

#[tokio::test]
async fn test_handle_5xx() -> Result<()> {
    let s = Server::default();
    let p = RetryPolicy::default().max_count(1);
    let r = s.new_recorder();
    let c = s.client();
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // Succeeds on second request (first retry).
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(503)));
    s.add_handler(|req| (req.uri().path() == "/foo").then_some(new_res(200)));
    assert!(
        unauth_session
            .send(GET!("/foo").retry_policy(p))
            .await?
            .ok()
            .is_ok()
    );

    // Should have made three requests (unauth session + original + retry).
    assert_eq!(r.take().len(), 3);

    Ok(())
}

/// Makes a response with the given status code.
fn new_res<B: Default>(status: u16) -> Response<B> {
    Response::builder()
        .status(status)
        .body(B::default())
        .unwrap()
}
