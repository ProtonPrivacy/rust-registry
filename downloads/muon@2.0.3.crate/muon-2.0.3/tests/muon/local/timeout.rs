use crate::local::ServerExt;
use anyhow::Result;
use muon::GET;
use muon::util::DurationExt;
use muon_test_server::server::Server;
use std::sync::Arc;

#[tokio::test]
async fn test_timeout_total() -> Result<()> {
    let s = Server::default();
    let c = s.client();
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // Set the total timeout to 0 seconds: fail immediately.
    if let Ok(t) = GET!("/tests/ping")
        .allowed_time(0.s())
        .send_with(&unauth_session)
        .await
    {
        panic!("expected error, got: {t:?}");
    }

    // Set the total timeout to 999 seconds: succeed.
    if let Err(e) = GET!("/tests/ping")
        .allowed_time(999.s())
        .send_with(&unauth_session)
        .await
    {
        panic!("expected success, got: {e:?}");
    }

    Ok(())
}
