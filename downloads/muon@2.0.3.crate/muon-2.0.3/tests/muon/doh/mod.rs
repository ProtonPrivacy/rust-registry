use crate::{default_app, new_builder, new_session};
use anyhow::Result;
use muon::app::AppVersion;
use muon::common::Server;
use muon::env::Env;
use muon::tests::util::MyOperatingSystem;
use muon::tls::pins::{TlsPin, TlsPinSet};
use muon::{App, Client, Environment, ErrorKind, GET};
use std::sync::Arc;

#[tokio::test]
async fn test_doh_normal_routing() -> Result<()> {
    // Create the client with the standard environment.
    let unauth_session = new_session().await;

    // Ping should work; we'll use standard routing.
    if let Err(err) = unauth_session.send(GET!("/tests/ping")).await {
        panic!("unexpected error: {err}");
    }

    Ok(())
}

pub struct ArEnv {
    env: Environment,
    api_pins: Option<TlsPinSet>,
    ar_pins: Option<TlsPinSet>,
}

impl ArEnv {
    pub fn good() -> Self {
        let env = Environment::new_prod();
        ArEnv {
            api_pins: Some(TlsPinSet::new([TlsPin::new(rand::random())])),
            ar_pins: env.ar_pins().cloned(),
            env,
        }
    }

    pub fn bad() -> Self {
        let env = Environment::new_prod();
        ArEnv {
            api_pins: Some(TlsPinSet::new([TlsPin::new(rand::random())])),
            ar_pins: Some(TlsPinSet::new([TlsPin::new(rand::random())])),
            env,
        }
    }
}

impl Env for ArEnv {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        self.env
            .servers(version)
            .into_iter()
            .filter(|server| server.is_indirect())
            .collect()
    }

    fn ar_pins(&self) -> Option<&TlsPinSet> {
        self.ar_pins.as_ref()
    }

    fn api_pins(&self) -> Option<&TlsPinSet> {
        self.api_pins.as_ref()
    }
}

#[tokio::test]
#[cfg(not(ci))]
async fn test_doh_alt_routing() -> Result<()> {
    use http::StatusCode;
    // Create a new app.
    use muon::Environment;
    use muon::tests::util::{MyOperatingSystem, TokioExecutor};
    use muon::util::DurationExt;
    use std::sync::Arc;
    use tracing::info;

    let app = App::new("linux-mail@4.1.0")?;
    let env = Environment::Custom(Arc::new(ArEnv::good()));

    // Create the client with the custom environment.
    let client = Client::builder(app, env)
        .with_operating_system(MyOperatingSystem::default(), rand::rng())
        .with_multi_thread_executor(TokioExecutor)
        .without_persistence::<()>()
        .build()?;

    let unauth_session = client.new_session_without_credentials(()).await?;

    // Ping should work; we'll use alternate routing.
    let res = unauth_session
        .send(GET!("/tests/ping").allowed_time(30.s()))
        .await?;

    assert_eq!(res.status(), StatusCode::OK);

    Ok(())
}

#[tokio::test]
async fn test_doh_alt_routing_wrong_pins() -> Result<()> {
    let env = Environment::Custom(Arc::new(ArEnv::bad()));

    // Create the client with the custom environment.
    let unauth_session = new_builder(default_app(), env, MyOperatingSystem::default())
        .build()?
        .new_session_without_credentials(())
        .await?;

    // Ping should fail; we'll use alternate routing, but the pins are wrong.
    let err = unauth_session
        .send(GET!("/tests/ping"))
        .await
        .expect_err("unexpected success");

    assert_eq!(err.kind(), ErrorKind::Connect); // failing at the connect stage

    Ok(())
}
