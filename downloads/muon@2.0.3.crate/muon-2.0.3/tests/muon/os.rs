use async_compat::Compat;
use derive_more::From;
use futures::TryFutureExt as _;
use muon::Client;
use muon::client::builder::{BaseBuilder, Hyper};
use muon::common::GenericContext;
use muon::env::Env;
use muon::http::hyper::builder::Dangerous;
use muon::http::hyper::connector::HyperConnector;
use muon::rt::{
    InstantFactory, Monotonic, MuonInstant, MuonSystemTime, OperatingSystem, Resolve, SendExecutor,
    SinceUnixEpoch as _, SystemTimeFactory, TcpConnect,
};
use muon::store::WithoutPersistence;
use muon::tls::pins::{TlsPin, TlsPinSet};
use muon_test_server::os::{
    SleepFut, Socket, StdTime, TokioExecutor, TokioResolver, TokioTcpConnector,
};
use muon_test_server::server::env::TestEnv;

#[derive(Debug, Default, Clone, From)]
pub struct TestTime(StdTime);

impl muon::rt::Sleep for TestTime {
    type Sleep<'a>
        = SleepFut<'a>
    where
        Self: 'a;

    fn sleep(&self, duration: core::time::Duration) -> Self::Sleep<'_> {
        self.0.sleep(duration)
    }
}

impl InstantFactory for TestTime {
    type Instant = MuonInstant;

    fn now(&self) -> Self::Instant {
        MuonInstant::from_duration(self.0.now_boottime() - self.0.boottime_at_start())
    }
}

unsafe impl Monotonic for TestTime {}

impl SystemTimeFactory for TestTime {
    type SystemTime = MuonSystemTime;

    fn now(&self) -> Self::SystemTime {
        MuonSystemTime::since_unix_epoch(
            self.0
                .now_realtime()
                .duration_since(self.0.realtime_epoch())
                .expect("failed to get time"),
        )
    }
}

#[derive(Debug, Clone, From)]
pub struct TestTcpConnector(TokioTcpConnector);

impl TcpConnect for TestTcpConnector {
    type Err = std::io::Error;

    type Socket = Compat<Socket>;

    fn tcp_connect(
        &self,
        addr: core::net::SocketAddr,
    ) -> impl std::future::Future<Output = Result<Self::Socket, Self::Err>> {
        self.0.tcp_connect(addr).map_ok(Compat::new)
    }
}

#[derive(Debug, Clone, From)]
pub struct TestResolver(TokioResolver);

impl Resolve for TestResolver {
    type Err = std::io::Error;

    fn resolve(
        &self,
        host: &str,
    ) -> impl std::future::Future<Output = Result<Vec<core::net::IpAddr>, Self::Err>> {
        self.0.resolve(host)
    }
}

#[derive(Debug, Clone)]
pub struct TestOs {
    pub time: TestTime,
    pub tcp_connector: TestTcpConnector,
    pub resolver: TestResolver,
}

impl OperatingSystem for TestOs {
    type Time = TestTime;

    fn get_time_capabilities(&self) -> &Self::Time {
        &self.time
    }

    type TcpConnector = TestTcpConnector;

    fn get_tcp_connector(&self) -> &Self::TcpConnector {
        &self.tcp_connector
    }

    type Resolver = TestResolver;

    fn get_resolver(&self) -> &Self::Resolver {
        &self.resolver
    }
}

type Executor = SendExecutor<TokioExecutor>;
type TestHyperConnector = HyperConnector<TestOs, Executor>;
type TestContext<Key> = GenericContext<TestHyperConnector, WithoutPersistence<Key>, muon::NoInfo>;
pub type TestClient<Key> = Client<TestContext<Key>>;

pub type TestBuilder<Key> =
    BaseBuilder<Hyper<TestOs, Executor, Dangerous>, WithoutPersistence<Key>, Key, muon::NoInfo>;
