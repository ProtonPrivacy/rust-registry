#![allow(warnings)]
#![cfg(not(target_family = "wasm"))]
//! # Muon Tests

use muon::client::builder::{BaseBuilder, Hyper};
use muon::rt::{OperatingSystem, SendExecutor};
use muon::store::WithoutPersistence;
use muon::tests::util::{MyOperatingSystem, TokioExecutor};
use muon::{App, Client, Context, Environment, Session, SessionKeyable};

/// Creates a new test session.
async fn new_session() -> Session<impl Context<SessionKey = ()>> {
    default_client::<()>()
        .new_session_without_credentials(())
        .await
        .expect("session should build")
}

fn default_os() -> MyOperatingSystem {
    MyOperatingSystem::default()
}

fn default_app() -> App {
    App::new("android-mail@99.9.40.0-dev")
        .unwrap()
        .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)")
}

fn default_env() -> Environment {
    crate::atlas::new_atlas_env()
}

fn new_builder<SessionKey: SessionKeyable, OS: OperatingSystem>(
    app: App,
    env: Environment,
    os: OS,
) -> BaseBuilder<Hyper<OS, SendExecutor<TokioExecutor>>, WithoutPersistence<SessionKey>, SessionKey>
where
    for<'a> <OS::Time as muon::rt::Sleep>::Sleep<'a>: Send + Sync,
{
    prepare_builder_for_context!(
        muon::Client::builder_with_transport::<Hyper>(app, env)
            .with_operating_system(os, rand::rng())
            .with_multi_thread_executor(TokioExecutor)
    )
    .without_persistence::<SessionKey>()
}

fn default_builder<SessionKey: SessionKeyable>() -> BaseBuilder<
    Hyper<MyOperatingSystem, SendExecutor<TokioExecutor>>,
    WithoutPersistence<SessionKey>,
    SessionKey,
> {
    let app = muon::App::new("android-mail@99.9.40.0-dev")
        .unwrap()
        .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)");

    let env = crate::atlas::new_atlas_env();
    new_builder(app, env, MyOperatingSystem::default())
}

fn default_client<SessionKey: SessionKeyable + 'static>()
-> Client<impl Context<SessionKey = SessionKey>> {
    default_builder().build().unwrap()
}

#[cfg(ci)]
macro_rules! prepare_builder_for_context {
    ($builder: expr) => {
        $builder.proxy(muon::common::EnvProxy::all("http_proxy").into())
    };
}

#[cfg(not(ci))]
macro_rules! prepare_builder_for_context {
    ($builder: expr) => {
        $builder
    };
}

pub(crate) use prepare_builder_for_context;

/// Tests against the atlas API.
mod atlas;

/// DNS-over-HTTPS tests.
mod doh;

/// Initialization.
mod init;

/// Local tests
mod local;

/// Os impl
mod os;
