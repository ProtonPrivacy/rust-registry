use crate::atlas::parallel::MyOperatingSystemWithSlowFastResolver;
use crate::{new_builder, new_session};
use anyhow::Result;
use muon::rt::*;
use muon::tests::util::{MyOperatingSystem, TokioExecutor, TokioResolver, TokioTime};
use muon::util::DurationExt;
use muon::{ErrorKind, GET};
use pin_project::pin_project;
use std::pin::Pin;
use std::task::*;
use tokio::sync::broadcast;

#[tokio::test]
async fn test_timeout_request_total() -> Result<()> {
    let s = new_session().await;

    // Set the total timeout of this request to 0 seconds: fail immediately.
    assert!(
        GET!("/tests/ping")
            .allowed_time(0.s())
            .send_with(&s)
            .await
            .is_err()
    );

    // Set the total timeout of this request to 999 seconds: succeed.
    assert!(
        GET!("/tests/ping")
            .allowed_time(999.s())
            .send_with(&s)
            .await
            .is_ok()
    );

    Ok(())
}

#[pin_project]
struct SocketKiller<T> {
    #[pin]
    socket: Option<T>,

    #[pin]
    rx: broadcast::Receiver<()>,
}

impl<T> SocketKiller<T> {
    fn new(socket: T, rx: broadcast::Receiver<()>) -> Self {
        Self {
            socket: Some(socket),
            rx,
        }
    }
}

impl<T: Socket> AsyncRead for SocketKiller<T> {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context,
        buf: &mut [u8],
    ) -> Poll<std::io::Result<usize>> {
        let mut this = self.project();

        if let Ok(()) = this.rx.try_recv() {
            this.socket.set(None);
        }

        if let Some(socket) = this.socket.as_pin_mut() {
            socket.poll_read(cx, buf)
        } else {
            Poll::Pending
        }
    }
}

impl<T: Socket> AsyncWrite for SocketKiller<T> {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context,
        buf: &[u8],
    ) -> Poll<std::io::Result<usize>> {
        let mut this = self.project();

        if let Ok(()) = this.rx.try_recv() {
            this.socket.set(None);
        }

        if let Some(socket) = this.socket.as_pin_mut() {
            socket.poll_write(cx, buf)
        } else {
            Poll::Pending
        }
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        let mut this = self.project();

        if let Ok(()) = this.rx.try_recv() {
            this.socket.set(None);
        }

        if let Some(socket) = this.socket.as_pin_mut() {
            socket.poll_flush(cx)
        } else {
            Poll::Pending
        }
    }

    fn poll_close(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        let mut this = self.project();

        if let Ok(()) = this.rx.try_recv() {
            this.socket.set(None);
        }

        if let Some(socket) = this.socket.as_pin_mut() {
            socket.poll_close(cx)
        } else {
            Poll::Pending
        }
    }
}

#[derive(Debug)]
struct SocketKillerLayer {
    rx: broadcast::Receiver<()>,
}

impl Clone for SocketKillerLayer {
    fn clone(&self) -> Self {
        Self {
            rx: self.rx.resubscribe(),
        }
    }
}

impl SocketKillerLayer {
    fn new(rx: broadcast::Receiver<()>) -> Self {
        Self { rx }
    }
}

impl TcpConnect for SocketKillerLayer {
    type Err = std::io::Error;

    type Socket = SocketKiller<async_compat::Compat<tokio::net::TcpStream>>;

    async fn tcp_connect(
        &self,
        addr: core::net::SocketAddr,
    ) -> std::result::Result<Self::Socket, Self::Err> {
        let rx = self.rx.resubscribe();

        match tokio::net::TcpStream::connect(addr).await {
            Ok(socket) => Ok(SocketKiller::new(async_compat::Compat::new(socket), rx)),
            Err(e) => Err(e),
        }
    }
}

#[tokio::test]
async fn test_timeout_unpool() -> Result<()> {
    for i in 0..50 {
        let (tx, rx) = broadcast::channel(1);

        let killer = SocketKillerLayer::new(rx);
        let app = muon::App::new("android-mail@99.9.40.0-dev")
            .unwrap()
            .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)");

        let env = crate::atlas::new_atlas_env();
        let os = MyOperatingSystem::new(TokioTime::default(), killer, TokioResolver::default());

        let session = new_builder::<(), _>(app, env, os)
            .without_persistence::<()>()
            .build()?
            .new_session_without_credentials(())
            .await?;

        // First request should succeed; muon connects, sender is pooled.
        match session.send(GET!("/tests/ping")).await {
            Ok(t) => assert!(t.status().is_success()),
            Err(e) => panic!("expected success, got: {e:?}"),
        }

        // Kill the socket.
        tx.send(())?;

        // Second request should fail; sender is unpooled.
        let time = 200.ms();
        match session.send(GET!("/tests/ping").allowed_time(time)).await {
            Ok(t) => panic!("expected error, got: {t:?}"),
            Err(e) => assert_eq!(e.kind(), ErrorKind::Send),
        }

        // Third request should succeed; muon reconnects, sender is pooled.
        match session.send(GET!("/tests/ping")).await {
            Ok(t) => assert!(t.status().is_success()),
            Err(e) => panic!("expected success, got: {e:?}"),
        }
    }

    Ok(())
}
