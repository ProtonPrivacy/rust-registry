use muon::auth::Auth;
use muon::client::builder::{BaseBuilder, Hyper};
use muon::env::Env;
use muon::rt::SendExecutor;
use muon::store::{Store, WithoutPersistence};
use muon::tests::util::{MyOperatingSystem, TokioExecutor};
use muon::{
    Client, Context, Environment, Fingerprint, ProvideInformation, Session, SessionKeyable,
};
use serde_json::json;
use std::collections::HashMap;
use std::sync::{Arc, RwLock};

const USER: &str = "plus";
const PASS: &str = "plus";

const USER_2FA: &str = "twofa";
const PASS_2FA: &str = "a";
const TOTP_2FA: &str = "4R5YJICSS6N72KNN3YRTEGLJCEKIMSKJ";

/// Simple ping tests against the Atlas API.
mod ping;

/// Auth tests.
#[cfg(ci)]
mod auth;

/// Error tests.
mod error;

/// Timeout tests.
mod timeout;

/// Mail tests.
mod mail;

/// Runtime tests.
mod runtime;

/// Parallel tests.
mod parallel;

/// multi-session tests
mod session;

/// Create a new test store for the Atlas environment.
pub fn new_atlas_env() -> Environment {
    if let Ok(name) = std::env::var("ENV_NAME") {
        Environment::new_atlas_name(&name)
    } else {
        Environment::new_atlas()
    }
}

/// Create a new test store for the Atlas environment.
pub fn new_atlas_store() -> TestStore<()> {
    if let Ok(name) = std::env::var("ENV_NAME") {
        TestStore::atlas_name(&name)
    } else {
        TestStore::atlas()
    }
}

/// Creates a valid fingerprint
fn valid_fingerprint() -> Fingerprint {
    json!({
        "mail-android-99.9.40.0-challenge":{
            "appLang":"en",
            "deviceName":"TestDevice",
            "frame":{
                "name":"username"
            },
            "isDarkmodeOn":false,
            "isJailbreak":false,
            "keyboards":[

            ],
            "preferredContentSize":"2.0",
            "regionCode":"CH",
            "storageCapacity":"63.8",
            "timezone":"Europe/Zurich",
            "timezoneOffset":"0",
            "v":"2.0.0"
        }
    })
    .into()
}

/// Creates an invalid fingerprint
fn invalid_fingerprint() -> Fingerprint {
    json!(100).into()
}

/// A simple in-memory store.
#[must_use]
#[derive(Debug, Clone)]
pub struct TestStore<SessionKey: SessionKeyable>(
    Environment,
    Arc<RwLock<HashMap<SessionKey, Auth>>>,
);

impl<SessionKey: SessionKeyable> Default for TestStore<SessionKey> {
    fn default() -> Self {
        Self::prod()
    }
}

impl<SessionKey: SessionKeyable> TestStore<SessionKey> {
    /// Create a new test store for the given environment.
    pub fn new(env: Environment) -> Self {
        Self(env, Arc::new(RwLock::new(HashMap::new())))
    }

    /// Create a new prod store.
    pub fn prod() -> Self {
        Self::new(Environment::new_prod())
    }

    /// Create a new atlas store.
    pub fn atlas() -> Self {
        Self::new(Environment::new_atlas())
    }

    /// Create a new atlas store with the given name.
    pub fn atlas_name(name: impl AsRef<str>) -> Self {
        Self::new(Environment::new_atlas_name(name))
    }

    /// Create a new custom store.
    pub fn custom(env: impl Env) -> Self {
        Self::new(Environment::new_custom(env))
    }

    pub fn get_auth(&self, key: &SessionKey) -> Option<Auth> {
        self.get_all_auth().get(key).cloned()
    }
}

impl<SessionKey: SessionKeyable> Store for TestStore<SessionKey> {
    type Key = SessionKey;

    fn set_auth(&mut self, key: Self::Key, auth: Auth) {
        self.1.write().unwrap().insert(key.clone(), auth);
    }

    fn remove_auth(&mut self, key: &Self::Key) {
        let _ = self.1.write().unwrap().remove(key);
    }

    fn get_all_auth(&self) -> HashMap<Self::Key, Auth> {
        self.1.read().unwrap().clone()
    }
}
