use crate::atlas::TestStore;
use crate::{default_app, default_env, default_os};
use anyhow::{Ok, Result, bail};
use muon::tests::util::new_client;
use muon::{POST, SessionCredentials};
use serde_json::{Value, json};
use std::collections::HashMap;
use std::result::Result::Ok as StdOk;
use std::sync::Arc;

struct SessionDetails<'a> {
    uid: &'a str,
    user_id: Option<&'a str>,
    access_token: &'a str,
    refresh_token: &'a str,
}

const SESSION: SessionDetails = SessionDetails {
    uid: "a50e8400-e29b-41d4-a716-446655440000",
    user_id: Some("b50e8400-e29b-41d4-a716-446655440001"),
    access_token: "c50e8400-e29b-41d4-a716-446655440002",
    refresh_token: "d50e8400-e29b-41d4-a716-446655440003",
};

const SESSION_TWO: SessionDetails = SessionDetails {
    uid: "a90e8400-e29b-41d4-a716-446655440000",
    user_id: Some("b90e8400-e29b-41d4-a716-446655440001"),
    access_token: "c90e8400-e29b-41d4-a716-446655440002",
    refresh_token: "d90e8400-e29b-41d4-a716-446655440003",
};

const UNAUTH_SESSION: SessionDetails = SessionDetails {
    uid: "ffffffff-e29b-41d4-a716-446655440000",
    user_id: None,
    access_token: "ffffffff-e29b-41d4-a716-446655440002",
    refresh_token: "ffffffff-e29b-41d4-a716-446655440003",
};

fn session_json() -> Value {
    json!({
        "UID": SESSION.uid,
        "UserID": SESSION.user_id,
        "AccessToken": SESSION.access_token,
        "RefreshToken": SESSION.refresh_token,
        "Scopes": [],
    })
}

fn session_two_json() -> Value {
    json!({
        "UID": SESSION_TWO.uid,
        "UserID": SESSION_TWO.user_id,
        "AccessToken": SESSION_TWO.access_token,
        "RefreshToken": SESSION_TWO.refresh_token,
        "Scopes": [],
    })
}

fn unauth_session_json() -> Value {
    json!({
        "UID": UNAUTH_SESSION.uid,
        "UserID": UNAUTH_SESSION.user_id,
        "AccessToken": UNAUTH_SESSION.access_token,
        "RefreshToken": UNAUTH_SESSION.refresh_token,
        "Scopes": [],
    })
}

#[tokio::test]
async fn test_auth_session() -> Result<()> {
    let env = default_env();

    let c = new_client();
    let (c, r) = c.testing().get_request_recorder();

    let session_credentials: SessionCredentials =
        serde_json::from_value(session_json()).expect("session credentials json should be valid");

    let session_key = "session_one".to_string();

    let session = c
        .new_session_with_credentials(session_key.clone(), session_credentials)
        .await
        .expect("Session should be created");

    let res = session
        .send(POST!("/core/v4/validate/email").body(r#"{"Email":"einstein@pm.me"}"#))
        .await;

    drop(session);
    drop(c);

    let req = r.recv().unwrap();

    let headers = req
        .get_header()
        .into_iter()
        .cloned()
        .collect::<HashMap<String, String>>();

    let uid_hdr = headers.get("x-pm-uid").unwrap();
    let acc_hdr = headers.get("authorization").unwrap();

    assert_eq!(uid_hdr, &SESSION.uid.to_string());

    assert_eq!(
        acc_hdr,
        &format!("Bearer {}", SESSION.access_token.to_string())
    );

    Ok(())
}

#[tokio::test]
async fn test_auth_session_failure() -> Result<()> {
    let c = new_client();

    let session_credentials: SessionCredentials =
        serde_json::from_value(session_json()).expect("session credentials json should be valid");

    let session_key = "session_one".to_string();

    let session = c
        .new_session_with_credentials(session_key.clone(), session_credentials)
        .await
        .expect("Session should be created");

    let session_credentials: SessionCredentials = serde_json::from_value(session_two_json())
        .expect("session credentials json should be valid");

    assert!(
        c.new_session_with_credentials(session_key.clone(), session_credentials)
            .await
            .is_err()
    );

    Ok(())
}
