use crate::{default_builder, default_client};
use anyhow::Result;
use muon::{Client, Context, GET};

async fn run<C: Context<SessionKey = ()>>(client: Client<C>) {
    // Create a session using the dispatcher.
    let session = client.new_session_without_credentials(()).await.unwrap();
    session
        .send(GET!("/tests/ping"))
        .await
        .unwrap()
        .ok()
        .unwrap();
}

#[tokio::test]
async fn test_runtime_spawn_tokio() -> Result<()> {
    let client = default_builder().build()?;

    let _ = tokio::spawn(run(client)).await;

    Ok(())
}
