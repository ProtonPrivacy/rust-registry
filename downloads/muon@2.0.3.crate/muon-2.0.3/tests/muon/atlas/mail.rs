use crate::atlas::{PASS, USER};
use crate::new_session;
use anyhow::{Result, bail};
use muon::GET;
use muon::auth::LoginFlow;
use serde_json::Value;

#[tokio::test]
async fn test_mail_message_ids() -> Result<()> {
    let session = match new_session().await.auth().login(USER, PASS).await {
        LoginFlow::Ok(s, _) => s,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let req = GET!("/mail/v4/messages/ids").query(("Limit", 1000));
    let res = session.send(req).await?;
    let res: Value = res.ok()?.into_body_json()?;

    println!("message ids: {res:#?}");

    Ok(())
}
