use crate::atlas::{PASS, USER};
use crate::{default_builder, default_client, new_builder, new_session};
use anyhow::{Ok, Result, bail};
use futures::future;
use http::StatusCode;
use muon::auth::LoginFlow;
use muon::common::{Host, RetryPolicy};
use muon::doh::DohService;
use muon::rt::{OperatingSystem, Resolve, ResolveRes};
use muon::tests::util::{MyOperatingSystem, TokioDialer, TokioResolver, TokioTime};
use muon::{Context, GET, Session};
use serde_json::Value;
use std::future::pending;
use std::time::Duration;
use std::usize;
use tracing::info;

#[derive(Debug, Clone)]
pub struct SlowFastResolver<Resolver> {
    inner: Resolver,
    slow: String,
}

impl<Resolver: Resolve> Resolve for SlowFastResolver<Resolver> {
    type Err = Resolver::Err;

    async fn resolve(&self, host: &str) -> Result<Vec<core::net::IpAddr>, Self::Err> {
        if host == &self.slow {
            pending().await // never resolve
        } else {
            self.inner.resolve(host).await
        }
    }
}

#[derive(Debug, Clone)]
pub struct MyOperatingSystemWithSlowFastResolver {
    pub time: TokioTime,
    pub dialer: TokioDialer,
    pub resolver: SlowFastResolver<TokioResolver>,
}

impl OperatingSystem for MyOperatingSystemWithSlowFastResolver {
    type Resolver = SlowFastResolver<TokioResolver>;
    type TcpConnector = TokioDialer;
    type Time = TokioTime;

    fn get_time_capabilities(&self) -> &Self::Time {
        &self.time
    }

    fn get_tcp_connector(&self) -> &Self::TcpConnector {
        &self.dialer
    }

    fn get_resolver(&self) -> &Self::Resolver {
        &self.resolver
    }
}

#[tokio::test]
async fn test_parallel_slow_fast() -> Result<()> {
    let google_host = DohService::GOOGLE.server().host().name().to_string();

    let resolver = SlowFastResolver {
        inner: TokioResolver,
        slow: google_host,
    };

    let os = MyOperatingSystemWithSlowFastResolver {
        time: TokioTime::default(),
        dialer: TokioDialer::default(),
        resolver,
    };
    let app = muon::App::new("android-mail@99.9.40.0-dev")
        .unwrap()
        .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)");
    let env = crate::atlas::new_atlas_env();
    let client = new_builder::<(), _>(app, env, os)
        .without_persistence::<()>()
        .build()
        .unwrap();

    let s = match client
        .new_session_without_credentials(())
        .await?
        .auth()
        .login(USER, PASS)
        .await
    {
        LoginFlow::Ok(s, _) => s,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    let req = GET!("/tests/ping").allowed_time(Duration::from_secs(60));
    let res = s.send(req).await?;
    let _: Value = res.ok()?.into_body_json()?;

    Ok(())
}

#[tokio::test]
async fn test_parallel_ping() -> Result<()> {
    let s = default_builder()
        .build()?
        .new_session_without_credentials(())
        .await?;

    let t = (0..50)
        .map(|_| s.clone())
        .map(|s| work(s))
        .map(|f| tokio::spawn(f))
        .collect::<Vec<_>>();

    for res in future::join_all(t).await {
        res.unwrap();
    }

    Ok(())
}

async fn work<C: Context>(s: Session<C>) {
    let req = GET!("/tests/ping")
        .retry_policy(
            RetryPolicy::default()
                .max_count(usize::MAX)
                .max_delay(Duration::ZERO),
        )
        .allowed_time(std::time::Duration::from_secs(60));
    let res = s.send(req).await.unwrap();
    info!("{}", res.status());
    assert_eq!(res.status(), StatusCode::OK);
    let _: Value = res.ok().unwrap().into_body_json().unwrap();
}
