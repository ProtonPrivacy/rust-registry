#!/usr/bin/env python3
"""
Usage: python3 get_rustflags.py wasm32-unknown-unknown
Extract rustflags for a specific target from .cargo/config.toml
"""

import sys
import tomli
from pathlib import Path


def main():
    if len(sys.argv) < 2:
        print("Usage: {} <target>".format(sys.argv[0]), file=sys.stderr)
        sys.exit(1)

    target = sys.argv[1]
    config_file = Path(".cargo/config.toml")

    if not config_file.exists():
        return

    with open(config_file, 'rb') as f:
        config = tomli.load(f)

    rustflags = config.get('target', {}).get(target, {}).get('rustflags', [])

    if rustflags:
        print(' '.join(rustflags))


if __name__ == "__main__":
    main()