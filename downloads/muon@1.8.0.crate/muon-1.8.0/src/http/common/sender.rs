use crate::common::prelude::*;
use crate::http::common::pool::{Pool, PooledSender, TryGet};
use crate::http::prelude::*;
use crate::util::TryRace;
use crate::{ErrorKind, Result};
use futures::TryFutureExt;
use std::sync::Arc;
use thiserror::Error;

/// Returned if no servers are provided to `HttpSender::sender_for`.
#[derive(Debug, Error)]
#[error("no servers available")]
pub struct NoServers;

/// An HTTP sender.
#[derive(Debug)]
pub struct HttpSender {
    servers: Vec<Server>,
    connector: DynHttpConnector,
    pool: Arc<Pool>,
}

impl HttpSender {
    /// Create a new HTTP sender.
    #[must_use]
    pub fn new<I: IntoDyn<DynHttpConnector>>(connector: I, servers: Vec<Server>) -> Self {
        Self {
            servers,
            connector: connector.into_dyn(),
            pool: Arc::default(),
        }
    }

    #[instrument(level = "debug", skip(self), fields(%req), err)]
    async fn send(&self, req: HttpReq) -> Result<HttpRes> {
        req.audit();

        let timeout = req.get_allowed_time().to_owned();

        let (direct, indirect): (Vec<Server>, Vec<Server>) = self
            .servers
            .clone()
            .into_iter()
            .partition(Server::is_direct);

        self.sender_for(&direct)
            .or_else(|_| self.sender_for(&indirect))
            .and_then(|sender| self.send_with(sender, req))
            .with_timeout(timeout)
            .map_err(ErrorKind::send)
            .await?
    }

    async fn sender_for(&self, servers: &[Server]) -> Result<PooledSender> {
        if servers.is_empty() {
            return Err(ErrorKind::send(NoServers));
        }

        let mut pool = self.pool.lock().await;

        for server in servers {
            pool = match pool.get(&server.endpoint) {
                TryGet::Some(sender) => return Ok(sender),
                TryGet::None(pool) => pool,
            };
        }

        // Will process all connects in parallel and take the fastest one.
        servers
            .iter()
            .map(|server| {
                self.connector
                    .connect(server)
                    .map_ok(move |sender| (&server.endpoint, sender))
            })
            .try_race()
            .map_ok(|(e, s)| pool.insert(e, s))
            .await
    }

    async fn send_with(&self, sender: PooledSender, req: HttpReq) -> Result<HttpRes> {
        match sender.send(req).await {
            Ok(res) => {
                sender.repool().await;
                Ok(res)
            }

            Err(err) => {
                sender.unpool().await;
                Err(err)
            }
        }
    }
}

impl Sender<HttpReq, HttpRes> for HttpSender {
    #[instrument(level = "debug", skip(self), fields(%req))]
    fn send<'a>(&'a self, req: HttpReq) -> BoxFut<'a, Result<HttpRes>> {
        Box::pin(self.send(req))
    }
}
