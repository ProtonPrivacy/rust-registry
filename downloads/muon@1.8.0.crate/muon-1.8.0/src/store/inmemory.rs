//! An in-memory implementation of the `Store` trait.
use std::collections::HashMap;

use crate::auth::Auth;
use crate::env::EnvId;
use crate::store::{Store, StoreError};
use crate::SessionKeyable;
use async_trait::async_trait;

/// An in-memory store for managing `Auth` states, suitable for testing or applications that don't require persistence.
#[derive(Debug)]
pub struct InMemoryStore<SessionKey: SessionKeyable> {
    /// The Proton environment this store is associated with.
    env: EnvId,
    /// A map holding the `Auth` state for each session key.
    credentials: HashMap<SessionKey, Auth>,
}

impl<SessionKey: SessionKeyable> InMemoryStore<SessionKey> {
    /// Creates a new `InMemoryStore` for the given environment, optionally with initial credentials.
    pub fn new(env: EnvId, credentials: Option<HashMap<SessionKey, Auth>>) -> Self {
        let credentials = credentials.unwrap_or_default();

        Self {
            env,
            credentials,
        }
    }
}

#[async_trait]
impl<SessionKey: SessionKeyable> Store<SessionKey> for InMemoryStore<SessionKey> {
    /// Returns the store's environment.
    fn env(&self) -> EnvId {
        self.env.clone()
    }

    /// Retrieves the `Auth` state for a given key, returning None if not found.
    async fn get_auth(&self, key: &SessionKey) -> Result<Auth, StoreError> {
        Ok(self.credentials.get(key).unwrap_or(&Auth::None).clone())
    }

    /// Sets or updates the `Auth` state for a given key.
    async fn set_auth(&mut self, key: &SessionKey, auth: Auth) -> Result<(), StoreError> {
        self.credentials.insert(key.clone(), auth);
        Ok(())
    }

    /// Removes the `Auth` state for a given key, returning Some(Auth) if it existed.
    async fn remove_auth(&mut self, key: &SessionKey) -> Result<Option<Auth>, StoreError> {
        Ok(self.credentials.remove(key))
    }

    /// Retrieves a clone of the entire authentication map.
    async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError> {
        Ok(self.credentials.clone())
    }

    /// Replaces the entire authentication map with the provided one.
    async fn set_all_auth(&mut self, auth: HashMap<SessionKey, Auth>) -> Result<(), StoreError> {
        self.credentials = auth;
        Ok(())
    }

    /// Clears the entire authentication map.
    async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
        self.credentials.clear();
        Ok(())
    }
}
