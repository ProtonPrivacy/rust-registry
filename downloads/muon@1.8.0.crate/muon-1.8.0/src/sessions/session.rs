use crate::common::{BoxFut, Sender};
use crate::env::EnvId;
use crate::flow::{AuthFlow, ForkFlow};
use crate::http::DELETE;
use crate::http::{HttpReq, HttpRes};
use crate::store::AuthVersion;
use crate::{send_expiring_request, Result, SessionCredentials};

use crate::{
    common::SenderExt, middleware::AuthLayer, sessions::SessionKeyable, Auth, Client,
    ProtonRequest, ProtonResponse,
};

/// Represents an active session, providing a handle for sending authenticated
/// requests.
///
/// A `Session` is a lightweight wrapper that associates a `SessionKey` with a
/// shared `Client`, allowing for authenticated communication. It is
/// obtained from a [`crate::Client`] rather than being constructed directly.
///
/// Once obtained, its primary purpose is to send requests via the [`Session::send`] method,
/// which automatically handles the authentication context for the request.
///
/// # Examples
///
/// ```
/// use muon::{App, Client, ProtonRequest, GET, env::EnvId};
///
/// # #[tokio::main]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// // 1. Build the client and obtain a session.
/// let app = App::new("windows-vpn@4.1.0")?;
/// let env = EnvId::new_atlas();
/// let mut client = Client::builder(app, env.into_store()).await.build()?;
///
/// let user_id = "user-123".to_string();
/// let session = client.new_session_without_credentials(user_id).await?;
///
/// // 2. Use the session to send an unauthenticated request.
/// let request = GET!("/v4/ping");
/// let response = session.send(request).await?;
///
/// // Process the response...
/// println!("Successfully sent request for session: {}", session.session_key());
/// # Ok(())
/// # }
/// ```
#[derive(Debug, Clone)]
#[must_use]
pub struct Session<SessionKey: SessionKeyable> {
    /// The shared client for network communication.
    client: Client<SessionKey>,

    /// The unique key identifying this session.
    session_key: SessionKey,
}

impl<SessionKey: SessionKeyable> Session<SessionKey> {
    /// Get the env the [`Session`] is bound to
    pub fn env(&self) -> &EnvId {
        self.client.env()
    }

    /// Creates a new Session from a client and a session key.
    ///
    /// This constructor is only meant to be called from
    /// the [`crate::Client`]
    pub(crate) fn new(client: Client<SessionKey>, session_key: SessionKey) -> Self {
        Self {
            client,
            session_key,
        }
    }

    /// Sends a request using this session's context.
    ///
    /// This method will delegate the call to the underlying shared `client`,
    /// which will use this session's context (e.g., tokens) to authenticate
    /// the request.
    ///
    /// # Arguments
    ///
    /// * `request` - The `ProtonRequest` object to be sent.
    ///
    /// # Returns
    ///
    /// A `Future` that resolves to a `Result` containing the `ProtonResponse` on
    /// success, or an error if the request fails.
    ///
    /// # Examples
    ///
    /// ```
    /// use muon::{App, Client, GET, env::EnvId};
    ///
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let app = App::new("windows-vpn@4.1.0")?;
    /// let env = EnvId::new_atlas();
    /// let mut client = Client::builder(app, env.into_store()).await.build()?;
    /// let session = client.new_session_without_credentials("user-123".to_string()).await?;
    ///
    /// let request = GET!("/v4/ping");
    ///
    /// match session.send(request).await {
    ///     Ok(response) => {
    ///         // Handle successful response
    ///         println!("Received successful response!");
    ///     }
    ///     Err(e) => {
    ///         // Handle error
    ///         eprintln!("Request failed: {:?}", e);
    ///     }
    /// }
    /// # Ok(())
    /// # }
    /// ```
    pub async fn send(&self, request: ProtonRequest) -> Result<ProtonResponse> {
        let layer = AuthLayer::new(self.clone());
        let layer = if let Some(provider) = self.client.provider() {
            layer.with_info_provider(provider.clone())
        } else {
            layer
        };
        let sender = self.client.sender().clone().layer([layer]);
        let expire_in = *request.get_allowed_time();
        // fire the request ensuring it expires after some times.
        send_expiring_request(sender, request, expire_in).await
    }

    /// Returns a reference to the session's unique key.
    ///
    /// This allows inspecting the identifier of the session without transferring
    /// ownership. It's useful for logging or debugging purposes.
    ///
    /// # Examples
    ///
    /// ```
    /// use muon::{App, Client, http::GET, env::EnvId};
    ///
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let app = App::new("windows-vpn@4.1.0").unwrap();
    /// let env = EnvId::new_prod();
    /// let client = Client::new(app, env.into_store()).await.unwrap();
    /// let session1 = client.new_session_without_credentials("session1".to_string()).await?;
    /// assert_eq!(session1.session_key(), "session1");
    /// let session2 = client.new_session_without_credentials("session2".to_string()).await?;
    /// assert_eq!(session2.session_key(), "session2");
    /// # Ok(())
    /// # }
    /// ```
    pub fn session_key(&self) -> &SessionKey {
        &self.session_key
    }

    /// Tells if the session is authenticated or not. This will not check with the backend, it will only check the local store for existence of the session credentials.
    ///
    /// ```
    /// use muon::{App, Client, http::GET, env::EnvId, SessionCredentials};
    /// use serde_json::json;
    ///
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let session_credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    /// let app = App::new("windows-vpn@4.1.0").unwrap();
    /// let env = EnvId::new_prod();
    /// let client = Client::new(app, env.into_store()).await.unwrap();
    /// let session1 = client.new_session_without_credentials("session1".to_string()).await?;
    /// assert!(!session1.is_authenticated().await);
    /// let session2 = client.new_session_with_credentials("session2".to_string(), session_credentials).await?;
    /// assert!(session2.is_authenticated().await);
    /// # Ok(())
    /// # }
    /// ```
    pub async fn is_authenticated(&self) -> bool {
        matches!(
            self.get_auth().await,
            (_, Auth::External { .. } | Auth::Internal { .. })
        )
    }

    /// Begin a logout flow.
    ///
    /// The logout flow deletes the session from the Proton API. It also clears the local store for the session.
    ///
    /// ```
    /// use anyhow::{bail, Result};
    /// use muon::client::flow::LoginFlow;
    /// use muon::{App, Client, GET};
    ///
    /// # #[tokio::main]
    /// # async fn main() -> Result<()> {
    /// // Create a new client.
    /// let app = App::new("windows-vpn@4.1.0")?;
    /// let store = muon::env::EnvId::new_atlas();
    /// // Please check the auth-info-provider.rs example to see how to pass a fingerprint to the muon client.
    /// // The fingerprint is important in combating fraud.
    /// let parent = Client::new(app, store.into_store()).await?
    ///     .new_session_without_credentials(())
    ///     .await?;
    ///
    /// // Authenticate the client.
    /// let session = match parent.auth().login("visionary", "a").await {
    ///     LoginFlow::Ok(session, _) => session,
    ///     LoginFlow::TwoFactor(_, _) => bail!("unexpected 2FA"),
    ///     LoginFlow::Failed { reason, .. } => return Err(reason.into()),
    /// };
    ///
    /// println!("{}", session.send(GET!("/core/v4/users")).await?.ok()?);
    ///
    /// // Now logout.
    /// session.clone().logout().await;
    /// // you can still ping
    /// session.send(GET!("/tests/ping")).await?.ok()?;
    /// // but you can't query authenticated routes
    /// assert!(session.send(GET!("/core/v4/users")).await?.ok().is_err());
    /// # Ok(())
    /// # }
    /// ```
    pub async fn logout(&self) {
        let layer = AuthLayer::new(self.clone());
        let sender = self.client.sender().clone();

        if !self.is_authenticated().await {
            info!("session is already unlogged");
            return;
        }

        debug_assert!(self.is_authenticated().await);

        info!("deleting session");
        let _ = sender.layer([layer]).send(DELETE!("/auth/v4")).await;

        info!("clearing store");
        self.clone().remove_auth().await;

        info!("auth session deleted");

        debug_assert!(!self.is_authenticated().await);
    }

    /// Begin an auth flow.
    ///
    /// The auth flow enables the session to authenticate with the Proton API.
    pub fn auth(&self) -> AuthFlow<SessionKey> {
        AuthFlow::new(self.clone())
    }

    /// Begin a fork flow.
    ///
    /// The fork flow enables the session to fork its auth session to a child.
    pub fn fork(&self, client: impl AsRef<str>) -> ForkFlow<SessionKey> {
        ForkFlow::new(self.clone(), client)
    }

    /// Get the client the session is using
    pub fn client(&self) -> &Client<SessionKey> {
        &self.client
    }

    /// Removes the authentication data for this specific session from the underlying store.
    ///
    /// Note that if you cloned the session, all clones will have to be destroyed and shouldn't be used anymore.
    /// If you don't do that the clones will become unauthenticated sessions. If they continue to be used,
    /// Muon will request unauthenticated credentials from the backend and save them using the session key.
    ///
    /// # Returns
    ///
    /// On success, return the Auth that was removed from the store or None if the session wasn't found,
    /// or didn't contain valid credentials.
    pub async fn remove_auth(self) -> Option<SessionCredentials> {
        self.client
            .stores()
            .remove_auth(&self.session_key)
            .await
            .and_then(|auth| auth.try_into().ok())
    }
}

impl<SessionKey: SessionKeyable> Sender<HttpReq, HttpRes> for Session<SessionKey> {
    fn send<'a>(&'a self, req: HttpReq) -> BoxFut<'a, Result<HttpRes>> {
        Box::pin(self.send(req))
    }
}

#[doc(hidden)]
/// Private mirror for store related calls
/// All those methods are gated to pub(crate) as they are only meant to be used by muon itself.
impl<SessionKey: SessionKeyable> Session<SessionKey> {
    /// Sets the authentication data for this specific session in the underlying store.
    ///
    /// This method updates the [`Auth`] state associated with `self.session_key`. It's typically
    /// used internally during authentication processes like login or token refresh to persist
    /// the new credentials or state.
    ///
    /// # Arguments
    ///
    /// * `auth` - The new [`Auth`] information to store for this session.
    pub(crate) async fn set_auth(&self, auth: Auth) {
        self.client.stores().set_auth(&self.session_key, auth).await
    }

    /// Retrieves the authentication data for this specific session from the underlying store.
    ///
    /// This method fetches the [`Auth`] state associated with `self.session_key`, along with its
    /// current [`AuthVersion`]. The version can be used for cache validation or optimistic concurrency control.
    ///
    /// # Returns
    ///
    /// A result containing the [`AuthVersion`] and [`Auth`] data on success,
    /// or a storage error on failure.
    pub(crate) async fn get_auth(&self) -> (AuthVersion, Auth) {
        self.client.stores().get_auth(&self.session_key).await
    }
}
