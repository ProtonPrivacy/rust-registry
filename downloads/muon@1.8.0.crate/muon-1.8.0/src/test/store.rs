use crate::env::{Env, EnvId};
use crate::store::{Store, StoreError};
use crate::{Auth, SessionKeyable};
use async_trait::async_trait;
use std::collections::HashMap;
use std::sync::{Arc, RwLock};

/// A simple in-memory store.
#[must_use]
#[derive(Debug, Clone)]
pub struct TestStore<SessionKey: SessionKeyable>(EnvId, Arc<RwLock<HashMap<SessionKey, Auth>>>);

impl<SessionKey: SessionKeyable> Default for TestStore<SessionKey> {
    fn default() -> Self {
        Self::prod()
    }
}

impl<SessionKey: SessionKeyable> TestStore<SessionKey> {
    /// Create a new test store for the given environment.
    pub fn new(env: EnvId) -> Self {
        Self(env, Arc::new(RwLock::new(HashMap::new())))
    }

    /// Create a new prod store.
    pub fn prod() -> Self {
        Self::new(EnvId::new_prod())
    }

    /// Create a new atlas store.
    pub fn atlas() -> Self {
        Self::new(EnvId::new_atlas())
    }

    /// Create a new atlas store with the given name.
    pub fn atlas_name(name: impl AsRef<str>) -> Self {
        Self::new(EnvId::new_atlas_name(name))
    }

    /// Create a new custom store.
    pub fn custom(env: impl Env) -> Self {
        Self::new(EnvId::new_custom(env))
    }
}

#[async_trait]
impl<SessionKey: SessionKeyable> Store<SessionKey> for TestStore<SessionKey> {
    /// Returns the store's environment.
    fn env(&self) -> EnvId {
        self.0.clone()
    }

    /// Retrieves the `Auth` state for a given key, returning a default if not found.
    async fn get_auth(&self, key: &SessionKey) -> Result<Auth, StoreError> {
        Ok(self.1.read().unwrap().get(key).cloned().unwrap_or_default())
    }

    /// Sets or updates the `Auth` state for a given key.
    async fn set_auth(&mut self, key: &SessionKey, auth: Auth) -> Result<(), StoreError> {
        self.1.write().unwrap().insert(key.clone(), auth);
        Ok(())
    }

    /// Removes the `Auth` state for a given key, returning Some(Auth) if it existed.
    async fn remove_auth(&mut self, key: &SessionKey) -> Result<Option<Auth>, StoreError> {
        Ok(self.1.write().unwrap().remove(key))
    }

    /// Retrieves a clone of the entire authentication map.
    async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError> {
        Ok(self.1.read().unwrap().clone())
    }

    /// Replaces the entire authentication map with the provided one.
    async fn set_all_auth(&mut self, auth: HashMap<SessionKey, Auth>) -> Result<(), StoreError> {
        let mut lock = self.1.write().unwrap();
        *lock = auth;
        Ok(())
    }

    /// Clears the entire authentication map.
    async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
        self.1.write().unwrap().clear();
        Ok(())
    }
}
