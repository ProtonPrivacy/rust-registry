use crate::app::AppVersion;
use crate::common::Server;
use crate::env::Env;
use crate::tls::TlsPinSet;
use std::collections::HashMap;

/// A custom environment.
#[derive(Debug, Clone)]
pub struct TestEnv(HashMap<Server, Option<TlsPinSet>>);

impl TestEnv {
    /// Create a new test environment.
    pub fn new(servers: impl IntoIterator<Item = (Server, Option<TlsPinSet>)>) -> Self {
        Self(servers.into_iter().collect())
    }
}

impl Env for TestEnv {
    fn servers(&self, _: &AppVersion) -> Vec<Server> {
        self.0.keys().cloned().collect()
    }

    fn pins(&self, server: &Server) -> Option<TlsPinSet> {
        self.0.get(server).cloned().flatten()
    }
}
