/// `/muon/bench`
pub mod bench;
