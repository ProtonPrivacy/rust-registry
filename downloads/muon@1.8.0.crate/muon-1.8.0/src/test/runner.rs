use super::server::{Scheme, Server};
use futures::prelude::*;
use std::sync::Arc;
use tokio::runtime::Runtime;

/// Options for the runners.
#[derive(Debug)]
pub struct Args {
    /// The scheme to use.
    pub scheme: Scheme,

    /// Users to register.
    pub users: Vec<(String, String)>,

    /// Sessions to register.
    /// uid, user_id, access_token, refresh_token
    pub sessions: Vec<(String, Option<String>, String, String)>,
}

impl Default for Args {
    fn default() -> Self {
        Self {
            scheme: Scheme::HTTP,
            users: vec![],
            sessions: vec![],
        }
    }
}

impl Args {
    /// Set the scheme to use.
    #[must_use]
    pub fn scheme(mut self, scheme: Scheme) -> Self {
        self.scheme = scheme;
        self
    }

    /// Register a new user.
    #[must_use]
    pub fn user(mut self, name: &str, pass: &str) -> Self {
        self.users.push((name.to_string(), pass.to_string()));
        self
    }

    /// Register a new sessiom.
    #[must_use]
    pub fn session(mut self, uid: &str, user_id: Option<&str>, access_token: &str, refresh_token: &str) -> Self {
        self.sessions.push((
            uid.to_string(), 
            user_id.map(|u| u.to_string()),
            access_token.to_string(),
            refresh_token.to_string(),
        ));
        self
    }
}

/// Runs the given test as an async block, providing a local server.
///
/// # Panics
///
/// Panics if the runtime or local server cannot be created.
pub fn run<F: Future>(args: Args, test: impl FnOnce(Arc<Server>) -> F) -> F::Output {
    let Ok(runtime) = Runtime::new() else {
        panic!("unable to create runtime")
    };

    let Ok(server) = Server::new(runtime.handle(), &args.scheme) else {
        panic!("unable to create server")
    };

    runtime.block_on(async move {
        for (name, pass) in args.users {
            if let Err(e) = server.new_user(&name, &pass).await {
                panic!("server failed to create user: {e}")
            }
        }

        for (uid, user_id, access_token, refresh_token) in args.sessions {
            if let Err(e) = server.new_session(&uid, user_id.as_deref(), &access_token, &refresh_token).await {
                panic!("server failed to session: {e}")
            }
        }

        let res = test(server.clone()).await;

        match server.stop().await {
            Ok(()) => res,
            Err(e) => panic!("server exited with error: {e}"),
        }
    })
}
