/// Simple ping tests against atlas.
mod ping;
