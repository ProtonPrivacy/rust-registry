use anyhow::Result;
use muon::rt::{AsyncSpawner, PollWith, TokioDialer, TokioResolver, TokioSpawner};
use muon::test::server::Server;
use muon::GET;
use std::sync::Arc;

#[muon::test]
async fn test_runtime_dispatcher(s: Arc<Server>) -> Result<()> {
    // Create a dispatcher and its driver.
    let (dispatcher, driver) = muon::rt::dispatcher();

    // Spawn the driver onto the runtime.
    AsyncSpawner::default().spawn(Box::pin(driver));

    // Create a client using the dispatcher.
    let c = s.builder().await.spawner(dispatcher).build()?;
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // This future will be executed by the dispatcher.
    unauth_session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}

#[muon::test]
async fn test_runtime_dispatcher_poll_with(s: Arc<Server>) -> Result<()> {
    // Create a dispatcher and its driver.
    // We don't spawn the driver onto the runtime here.
    let (dispatcher, driver) = muon::rt::dispatcher();

    // Create a client using the dispatcher.
    let c = s.builder().await.spawner(dispatcher).build()?;
    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    // This future will be executed by the current thread,
    // which will also drive the dispatcher.
    unauth_session
        .send(GET!("/tests/ping"))
        .poll_with(&driver)
        .await?
        .ok()?;

    Ok(())
}

#[muon::test]
async fn test_runtime_tokio(s: Arc<Server>) -> Result<()> {
    // Create a client using the tokio runtime components.
    let c = s
        .builder()
        .await
        .resolver(TokioResolver)
        .dialer(TokioDialer)
        .spawner(TokioSpawner)
        .build()?;

    let unauth_session = c
        .new_session_without_credentials("unauth_session".to_string())
        .await?;

    unauth_session.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
