use crate::atlas::{new_atlas_store, new_session, PASS, USER};
use anyhow::{bail, Result};
use derive_more::Error;
use muon::client::flow::LoginFlow;
use muon::client::middleware::AuthErr;
use muon::client::{Auth, Tokens};
use muon::common::EnvProxy;
use muon::store::Store;
use muon::{App, Client, GET};

#[tokio::test]
async fn test_error_code() -> Result<()> {
    let session = match new_session().await.auth().login(USER, PASS).await {
        LoginFlow::Ok(s, _) => s,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };
    session.logout().await;

    Ok(())
}

#[tokio::test]
async fn test_error_auth_session() -> Result<()> {
    // Create the first session.
    let store1 = new_atlas_store();
    let s1 = match Client::builder(
        App::new("android-mail@99.9.40.0-dev").unwrap(),
        store1.clone(),
    )
    .await
    .proxy(EnvProxy::all("http_proxy"))
    .build()?
    .new_session_without_credentials(())
    .await?
    .auth()
    .login(USER, PASS)
    .await
    {
        LoginFlow::Ok(s, _) => s,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    // Do bad things: duplicate the first session's auth.
    let mut store2 = new_atlas_store();
    let auth = store1.get_auth(&()).await?;
    println!("PT: all auth is {:#?}", store1.get_all_auth().await);
    let _ = store2.set_auth(&(), auth).await?;

    // Create the second session.
    let s2 = Client::builder(App::new("android-mail@99.9.40.0-dev").unwrap(), store2)
        .await
        .proxy(EnvProxy::all("http_proxy"))
        .build()?
        .get_session(())
        .await
        .expect("Session should exist");

    // Log the first session out.
    s1.logout().await;

    // Try to use the second session.
    let Err(err) = s2.send(GET!("/core/v4/users")).await else {
        bail!("unexpected success");
    };

    // Get the source of the error.
    let Some(src) = err.source() else {
        bail!("source should be present: {err}");
    };

    assert!(src.is::<AuthErr>());
    assert!(matches!(src.downcast_ref(), Some(AuthErr::Session)));

    Ok(())
}

#[tokio::test]
async fn test_error_auth_unauthorized() -> Result<()> {
    // Create the first session.
    let store1 = new_atlas_store();
    let _ = match Client::builder(
        App::new("android-mail@99.9.40.0-dev").unwrap(),
        store1.clone(),
    )
    .await
    .proxy(EnvProxy::all("http_proxy"))
    .build()?
    .new_session_without_credentials(())
    .await?
    .auth()
    .login(USER, PASS)
    .await
    {
        LoginFlow::Ok(_, _) => {}
        LoginFlow::TwoFactor(_, _) => bail!("unexpected TFA flow"),
        LoginFlow::Failed { .. } => bail!("unexpected failure"),
    };

    // Do bad things: create a session where the auth token will be refreshed.
    let mut store2 = new_atlas_store();

    if let Ok(Auth::Internal { user_id, uid, tok }) = store1.get_auth(&()).await {
        let tok = Tokens::refresh(tok.ref_tok());
        let _ = store2
            .set_auth(&(), Auth::internal(user_id, uid, tok))
            .await?;
    } else {
        bail!("unexpected auth")
    };

    // Create the second session.
    let s2 = Client::builder(App::new("android-mail@99.9.40.0-dev").unwrap(), store2)
        .await
        .proxy(EnvProxy::all("http_proxy"))
        .build()?
        .get_session(())
        .await
        .expect("Session should exist");

    // Use the second session to trigger an auth refresh.
    let _ = s2.send(GET!("/core/v4/users")).await?.ok()?;

    // Create the third session using the already-refreshed auth.
    let s3 = Client::builder(App::default(), store1.clone())
        .await
        .proxy(EnvProxy::all("http_proxy"))
        .build()?
        .get_session(())
        .await
        .expect("Session should exist");

    // Try to use the third session.
    let Err(err) = s3.send(GET!("/core/v4/users")).await else {
        bail!("unexpected success");
    };

    // Get the source of the error.
    let Some(src) = err.source() else {
        bail!("source should be present: {err}");
    };

    assert!(src.is::<AuthErr>());
    assert!(matches!(src.downcast_ref(), Some(AuthErr::Session)));

    Ok(())
}
