use crate::atlas::new_builder;
use anyhow::Result;
use muon::tls::{RustlsTls, TokioTls};
use muon::GET;

#[tokio::test]
async fn test_tls_rustls() -> Result<()> {
    let s = new_builder()
        .await
        .tls(RustlsTls)
        .build()?
        .new_session_without_credentials(())
        .await?;

    s.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}

#[tokio::test]
async fn test_tls_tokio() -> Result<()> {
    let s = new_builder()
        .await
        .tls(TokioTls)
        .build()?
        .new_session_without_credentials(())
        .await?;

    s.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
