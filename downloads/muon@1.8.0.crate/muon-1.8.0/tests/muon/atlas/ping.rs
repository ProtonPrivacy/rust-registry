use crate::atlas::new_session;
use anyhow::Result;
use muon::GET;

#[tokio::test]
async fn test_ping() -> Result<()> {
    new_session().await.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
