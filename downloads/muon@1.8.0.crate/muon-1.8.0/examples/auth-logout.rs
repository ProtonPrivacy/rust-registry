//! This example demonstrates the basic logout flow for a muon session.

use anyhow::{bail, Result};
use muon::client::flow::LoginFlow;
use muon::{App, Client, GET};

#[tokio::main]
async fn main() -> Result<()> {
    // Create a new session.
    let app = App::new("windows-vpn@4.1.0")?;
    let store = muon::env::EnvId::new_atlas();
    // Please check the auth-info-provider.rs example to see how to pass a fingerprint to the muon client.
    // The fingerprint is important in combating fraud.
    let session = Client::new(app, store.into_store())
        .await?
        .new_session_without_credentials(())
        .await?;

    // Authenticate the session.
    let session = match session.auth().login("visionary", "a").await {
        LoginFlow::Ok(session, _) => session,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected 2FA"),
        LoginFlow::Failed { reason, .. } => return Err(reason.into()),
    };

    println!("{}", session.send(GET!("/core/v4/users")).await?.ok()?);

    // Now logout.
    session.logout().await;
    // you can still ping
    session.send(GET!("/tests/ping")).await?.ok()?;
    // but you can't query authenticated routes
    assert!(session.send(GET!("/core/v4/users")).await?.ok().is_err());

    Ok(())
}
