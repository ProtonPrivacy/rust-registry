//! This example demonstrates how a un-authenticated session sends a request

use anyhow::Result;
use muon::{App, Client, GET};
use tracing::info;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let app = App::new("windows-vpn@4.0.1")?;
    let env = muon::env::EnvId::new_prod();
    let session = Client::new(app, env.into_store())
        .await?
        .new_session_without_credentials(())
        .await?;

    info!("created session with environment {:?}", session.env());

    info!("{}", session.send(GET!("/tests/ping")).await?);

    Ok(())
}
