# Migration Guide: Adopting the New Session-Based API

This document outlines the significant architectural changes introduced with multi session support and provides a step-by-step guide for migrating your application to the new session-based API.

## 1\. Overview of Changes

The core of this update is a fundamental shift from a stateful, single-session `Client` to a more robust, multi-session management model. This change enhances clarity, improves support for multi-account applications, and provides a more ergonomic API.

The key changes are:

1.  **The `Client` is now a Session Factory**: The `Client<SessionKey>` manages the underlying network transport and creates, retrieves, and manages individual `Session` objects.
2.  **Introduction of `Session<SessionKey>`**: All stateful operations, especially sending requests, are now handled by the `Session` object. A `Session` represents a single, specific authenticated (or unauthenticated) state, identified by a `SessionKey`.
3.  **A Redesigned `Store` Trait**: The storage interface has been redesigned to support keyed, multi-session persistence.

-----

## 2\. From Stateful `Client` to `Session` Handles

The primary conceptual change is the separation of concerns between the network client configuration and the session's authentication state.

### Old Model

Previously, the `Client` object was stateful. It was tied to a single `Store` that managed one user's authentication credentials. All operations like `send`, `auth`, and `logout` were performed directly on this single, stateful `Client`.

### New Model

The new model introduces two distinct types:

  * **`Client<SessionKey>`**: This is the main entry point. It's a factory for creating and managing sessions. It is generic over a `SessionKey`, which is a type you choose to uniquely identify each user session (e.g., `String` for usernames, `uuid::Uuid`, or `()` for single-session apps). The `Client` itself is cheap to clone and can be shared across your application.

  * **`Session<SessionKey>`**: This is a lightweight handle to a specific user's session. **All API requests are now sent via a `Session` object**. It holds a reference to the shared `Client` and the unique `SessionKey` for its user. Operations like `send`, `auth`, `logout`, and `fork` are now methods on the `Session`.

This design makes managing multiple accounts trivial and state management much more explicit.

-----

## 3\. API Migration Guide

This section details the specific changes you'll need to make in your code.

### 3.1. Client and Session Instantiation

The `Client` is now generic over the type of the `SessionKey` and is used to get `Session` handles.

**Before:**

```rust
// Client was not generic, store held a single auth state.
let client = Client::builder(app, my_store).build()?;
```

**After:**
You must now specify a `SessionKey` type for your `Client`.

  * For **multi-session** applications, use a key like `String` or `Uuid`.
  * For **single-session** applications, simply use the unit type `()`.

*Note: Any type that implements `Eq + Hash + Clone + Debug + Serialize + DeserializeOwned + Send + Sync` can be used as a `SessionKey`*.

*This means that types like `Option<u32>`, `bool`, ... can be used*

```rust
use muon::{Client, Session};

// For multi-session applications (e.g., keyed by username)
let client: Client<String> = Client::builder(app, my_multi_user_store).await.build()?;

let username = "username_1".to_string();

// Session Credentials can be obtained from the backend by logging in or forking an existing session
let unauthenticated_session = client.new_session_without_credentials("unauth_session".to_string()).await?;
// Use the unauthenticated session to obtain session credentials from the backend
// Note: SessionCredentials should be directly deserialized into from the json received from the `/auth` API call. 
// SessionCredentials are not clonable, and inner values are not mutable, to avoid mistakes. 
// The backend response should be passed to Muon without any changes.
// Also, Muon should be the only place that stores and handles SessionCredentials.
let credentials: SessionCredentials = get_credentials_from_backend(&unauthenticated_session, &username)?; // Placeholder
let user_session: Session<String> = client.new_session_with_credentials(username, credentials).await?;

// For single-session applications
let client: Client<()> = Client::builder(app, my_single_user_store).await.build()?;

// To get the single session handle:
let session: Session<()> = client.new_session_without_credentials(()).await?;
```

### 3.2. Sending Requests

Requests are no longer sent with the `Client`, but with the `Session` that corresponds to the desired user.

**Before:**

```rust
client.send(GET!("/v4/users")).await?;
```

**After:**

```rust
// Get the session for the desired user
let session = client.new_session_with_credentials((), credentials).await?;

// Send the request using the session
session.send(GET!("/v4/users")).await?;
```

### 3.3. Authentication (Login) and Forking

Login and fork operations are now initiated on a `Session` object.

  * **Login**: You start the authentication flow on an unauthenticated session. After a successful login, the `Session` object becomes authenticated.
  * **Fork**: You can only fork an already-authenticated session.

**Before:**

```rust
// Login
let client = match client.auth().login("user", "pass").await { /* ... */ };

// Fork
let ForkFlowResult::Success(client, selector) = client.fork("app-name").send().await else { /* ... */ };
```

**After:**

```rust
// --- Login ---
// 1. Get a session for the user you want to log in.
let user_session = client.new_session_without_credentials("new_user_id".to_string()).await?;

// 2. Initiate the auth flow on that session.
let authenticated_session = match user_session.auth().login("user", "pass").await {
    LoginFlow::Ok(session, _) => session,
    // ... handle other cases
};

// --- Fork ---
// 1. You must have an authenticated session.
let authenticated_session = client.get_session("new_user_id".to_string()).await?.expect("The session shouldn't be None after a login."); // e.g., from login

// 2. Fork from the authenticated session.
let ForkFlowResult::Success(session, selector) = authenticated_session.fork("app-name").send().await else { /* ... */ };
```

### 3.4. Managing Sessions on the Client

The `Client` now has a clear set of methods to manage the lifecycle of sessions in the persistent store.

  * **`client.new_session_with_credentials(key, credentials)`**: Persists the given credentials under the specified `key` and returns a `Session` handle.
  * **`client.new_session_without_credentials(key)`**: Creates a `Session` handle for a new, unauthenticated session (e.g., for a guest). The unauthenticated credentials will be persisted to the store upon the first API call made with this session.
  * **`client.get_session(key)`**: Retrieves a session handle from the store. This accesses storage and returns `Some(Session)` if persisted credentials exist for the given key, and `None` otherwise.
  * **`client.get_all_sessions()`**: Retrieves handles for all sessions that are backed by persisted credentials in the store.
  * **`client.remove_session(&key)`**: Removes the persisted credentials for a single session from the store.
  * **`client.remove_all_sessions()`**: Clears all persisted credentials from the store.

-----

## 4\. Imporant: Pitfalls of the new Session API

WARNING: The new Sessions API comes with a couple of caveats, that can lead to:

1. Mixing data between users: Sending data meant for `user_1` to `user_2`. 
2. Authenticated sessions becoming unauthenticated.

### 4.1\. Mixing data between users
Session objects are clonable and reference session credentials by a session key. Take the following scenario: 

1. There's a `session_user` object with the session key `user`, that the codebase assumes is used to send data for `user_1`.
2. The session credentials for the session key `user` are removed.
3. New session credentials, that belong to `user_2`, are added for the session key `user`.
4. Now the `session_user` object will send data that is associated with `user_2` not `user_1`.
5. This can all happen on a separate thread with no notice of any changes, and can lead to data mixing if not careful.

### 4.2\. Authenticated sessions becoming unauthenticated

Assume there's a `Session` object called `session_one` that uses the session key `user`. For the session key `user` there are authenticated session credentials stored. 

Assume that the session credentials for the session key `user` are removed. Now, if the `Session` object `session_one` is used to send a request this is what happens behind the scenes:

1. Muon will check if there are session credentials saved for the session key `user`
2. Because there are no session credentials, Muon will ask the backend for unauthenticated session credentials
3. Muon will save the unauthenticated session credentials for the session key `user`
4. Muon will use the unauthenticated session credentials to send the request.

If the request needs authenticated session credentials, it will return an error.

### 4.3\. Mitigation plan

The issue is that the credentials that a `Session` object references can change without notice. This can lead to subtle, hard to find bugs. 

To address this we need a way to stop `Session` objects whose credentials have changed from performing actions. 

We have a few ideas on how to do this, and a fix is coming soon. 

-----

## 5\. Migrating the Storage Interface (`Store`)

If you have a custom implementation of the `Store` trait, you **must** update it. The trait has been redesigned to support keyed, multi-session storage.

### Key Changes to `Store`

1.  **Generic Trait**: The trait is now generic: `pub trait Store<SessionKey: SessionKeyable>`.
2.  **Data Model**: The store is expected to manage a map-like collection of `SessionKey` to `Auth` objects. The concept of a single, global `Auth` object is gone.
3.  **Method Signatures**: All methods have changed to operate on this keyed data model. Methods that modify the store now require `&mut self`.

### `Store` Trait Migration

Here is a summary of the required changes:

| Old Method Signature | New Method Signature | Notes |
| --- | --- | --- |
| `async fn get_auth(&self) -> Auth`    | `async fn get_auth(&self, key: &SessionKey) -> Result<Auth, StoreError>` | Now takes a key by reference. **Must** return `Ok(Auth::None)` if the key is not found, and `Err` only on a storage access failure.    |
| `async fn set_auth(&mut self, auth: Auth) -> Result<Auth, StoreError>` | `async fn set_auth(&mut self, key: &SessionKey, auth: Auth) -> Result<(), StoreError>` | Takes a key by reference and the `Auth` object. Now requires `&mut self`. |
| `async fn get_credentials(...)`    | **(Removed)** | Replaced by `get_all_auth`.   |
| `async fn set_credentials(...)`    | **(Removed)** | Replaced by `set_all_auth`.   |
| **(N/A)** | `async fn remove_auth(&mut self, key: &SessionKey) -> Result<bool, StoreError>`  | **(New)** Must remove the entry for the given key. Should return `Ok(true)` on successful removal and `Ok(false)` if the key was not found. Requires `&mut self`. |
| **(N/A)** | `async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError>` | **(New)** Must return the entire map of stored sessions.  |
| **(N/A)** | `async fn set_all_auth(&mut self, auth: HashMap<SessionKey, Auth>) -> Result<(), StoreError>` | **(New)** Must completely replace the stored map with the provided one. Requires `&mut self`.   |
| **(N/A)** | `async fn remove_all_auth(&mut self) -> Result<(), StoreError>`  | **(New)** Must clear all entries from the store. Requires `&mut self`.    |

*Note: The store should never save any `Auth::None` variants*
*Note: You are guaranteed that anything passed to `set_auth` and `set_auth_all` will never contain the `Auth::None` variant*

### Example: Migrating a Simple `Store`

**Before (Single-Session Store):**

```rust
struct MyOldStore {
    auth: Auth,
    // ...
}

#[async_trait]
impl Store for MyOldStore {
    async fn get_auth(&self) -> Auth {
        self.auth.clone()
    }
    async fn set_auth(&mut self, auth: Auth) -> Result<Auth, StoreError> {
        self.auth = auth.clone();
        Ok(auth)
    }
    // ... other methods were needed
}
```

**After (Single-Session Store using `SessionKey = ()`):**

```rust
use muon::{Auth, SessionKeyable};
use muon::env::EnvId;
use muon::store::{Store, StoreError};
use std::collections::HashMap;

struct MySingleSessionStore {
    // For a single session, we only need to store one Auth object.
    auth: Option<Auth>,
    env: EnvId,
}

#[async_trait]
impl Store<()> for MySingleSessionStore {
    fn env(&self) -> EnvId { self.env.clone() }

    async fn get_auth(&self, _key: &()) -> Result<Auth, StoreError> {
        Ok(self.auth.clone().unwrap_or(Auth::None))
    }

    async fn set_auth(&mut self, _key: &(), auth: Auth) -> Result<(), StoreError> {
        self.auth = Some(auth);
        Ok(())
    }

    async fn remove_auth(&mut self, _key: &()) -> Result<Option<Auth>, StoreError> {
        Ok(self.auth.take())
    }

    async fn get_all_auth(&self) -> Result<HashMap<(), Auth>, StoreError> {
        let mut map = HashMap::new();
        if let Some(auth) = self.auth.clone() {
            map.insert((), auth);
        }
        Ok(map)
    }

    async fn set_all_auth(&mut self, mut auth_map: HashMap<(), Auth>) -> Result<(), StoreError> {
        // Take the value for the () key, or default to None if the map is empty.
        self.auth = auth_map.remove(&());
        Ok(())
    }

    async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
        self.auth = None;
        Ok(())
    }
}
```

**After (Generic Multi-Session Store):**

For applications managing multiple user accounts, you can create a generic store that uses a `HashMap` to map each `SessionKey` to its `Auth` state.

```rust
use muon::{Auth, SessionKeyable};
use muon::env::EnvId;
use muon::store::{Store, StoreError};
use std::collections::HashMap;

struct MyMultiSessionStore<SessionKey: SessionKeyable> {
    auth_map: HashMap<SessionKey, Auth>,
    env: EnvId,
}

#[async_trait]
impl<SessionKey: SessionKeyable> Store<SessionKey> for MyMultiSessionStore<SessionKey> {
    fn env(&self) -> EnvId { self.env.clone() }

    async fn get_auth(&self, key: &SessionKey) -> Result<Auth, StoreError> {
        Ok(self.auth_map.get(key).cloned().unwrap_or(Auth::None))
    }

    async fn set_auth(&mut self, key: &SessionKey, auth: Auth) -> Result<(), StoreError> {
        self.auth_map.insert(key.clone(), auth);
        Ok(())
    }

    async fn remove_auth(&mut self, key: &SessionKey) -> Result<Option<Auth>, StoreError> {
        Ok(self.auth_map.remove(key))
    }

    async fn get_all_auth(&self) -> Result<HashMap<SessionKey, Auth>, StoreError> {
        Ok(self.auth_map.clone())
    }

    async fn set_all_auth(&mut self, auth_map: HashMap<SessionKey, Auth>) -> Result<(), StoreError> {
        self.auth_map = auth_map;
        Ok(())
    }

    async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
        self.auth_map.clear();
        Ok(())
    }
}
```