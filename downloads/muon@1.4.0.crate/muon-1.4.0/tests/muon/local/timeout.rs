use anyhow::Result;
use muon::test::server::Server;
use muon::util::{DurationExt, ProtonRequestExt};
use muon::GET;
use std::sync::Arc;

#[muon::test]
async fn test_timeout_total(s: Arc<Server>) -> Result<()> {
    let c = s.client();

    // Set the total timeout to 0 seconds: fail immediately.
    if let Ok(t) = GET!("/tests/ping").allowed_time(0.s()).send_with(&c).await {
        panic!("expected error, got: {t:?}");
    }

    // Set the total timeout to 999 seconds: succeed.
    if let Err(e) = GET!("/tests/ping")
        .allowed_time(999.s())
        .send_with(&c)
        .await
    {
        panic!("expected success, got: {e:?}");
    }

    Ok(())
}
