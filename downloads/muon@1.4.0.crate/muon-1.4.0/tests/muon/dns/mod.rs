use anyhow::Result;
use muon::common::prelude::*;
use muon::dns::{CloudflareDns, DnsClient, DnsResolver, GoogleDns, Quad9Dns};
use muon::rt::{AsyncResolver, AsyncSpawner, Resolver};

#[tokio::test]
#[cfg_attr(ci, ignore = "direct DNS not supported in CI")]
async fn test_dns_client() -> Result<()> {
    let host = Host::direct("ip.me")?;
    let want = AsyncResolver.resolve(&host).await?.into_set();

    let dns = DnsClient::new(GoogleDns, AsyncSpawner::default());
    let have = DnsResolver::new(dns).resolve(&host).await?.into_set();
    assert_eq!(have, want, "{have:?} != {want:?}");

    let dns = DnsClient::new(CloudflareDns, AsyncSpawner::default());
    let have = DnsResolver::new(dns).resolve(&host).await?.into_set();
    assert_eq!(have, want, "{have:?} != {want:?}");

    let dns = DnsClient::new(Quad9Dns, AsyncSpawner::default());
    let have = DnsResolver::new(dns).resolve(&host).await?.into_set();
    assert_eq!(have, want, "{have:?} != {want:?}");

    Ok(())
}
