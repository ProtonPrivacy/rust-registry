use crate::common::prelude::*;
use crate::common::DynSocket;
use crate::http::hyper::compat::{HyperIo, HyperRt, HyperTimer};
use crate::http::hyper::sender::{fmt_req, is_retryable, ReadySend, ReadySendMut, SendWith};
use crate::http::{Body, Collect, HttpReq, HttpRes, Version};
use crate::rt::DynSpawner;
use crate::{ErrorKind, Result};
use async_trait::async_trait;
use futures::TryFutureExt;
use http::{Request, Response};
use hyper::client::conn::http2;
use hyper::client::conn::http2::SendRequest;
use hyper::rt::Executor;
use url::Url;

pub async fn new_http2_sender(
    sock: impl IntoDyn<DynSocket>,
    exec: impl IntoDyn<DynSpawner>,
    base: Url,
) -> Result<H2Sender> {
    let sock = HyperIo(sock.into_dyn());
    let exec = exec.into_dyn();

    H2Sender::connect(sock, HyperRt(exec), base)
        .map_err(ErrorKind::connect)
        .await
}

/// An HTTP/2 sender implementation.
#[derive(Debug)]
pub struct H2Sender<B = Body> {
    sender: SendRequest<B>,
    base: Url,
}

impl H2Sender {
    fn new(sender: SendRequest<Body>, base: Url) -> Self {
        Self { sender, base }
    }

    async fn connect(sock: HyperIo, exec: HyperRt, base: Url) -> hyper::Result<Self> {
        trace!(%base, "performing HTTP/2 handshake");

        let (sender, driver) = http2::Builder::new(exec.clone())
            .timer(HyperTimer)
            // Note: this is required to detect that the socket is always alive while the stream is
            // open (e.g., socket can die on hibernate or any network glitch). Otherwise, the
            // socket can stay open despite being dead under the hood.
            .keep_alive_timeout(HTTP2_KEEP_ALIVE_TIMEOUT)
            // fixme(aboulmier): we might want to disable this to optimize for battery consumption.
            .keep_alive_interval(HTTP2_KEEP_ALIVE_INTERVAL)
            // note(aboulmier): this *ensures* that we send keep alive *only* while the stream is
            // open, limiting the impact on battery. The behavior has been verified by a
            // packet capture. It is critical not to send keep-alive while being idle!
            .keep_alive_while_idle(false)
            .handshake(sock)
            .await?;

        exec.execute(driver);

        Ok(Self::new(sender, base))
    }

    async fn send(&self, req: HttpReq) -> Result<HttpRes> {
        trace!(%req, "sending with HTTP/2 sender");

        HttpReq::build(req, Version::HTTP_2, &self.base)?
            .send_with(&self.sender)
            .ok_into()
            .inspect_err(|e| error!(%e, "failed to send HTTP/2 request"))
            .map_err(|e| {
                if is_retryable(&e) {
                    ErrorKind::send(e).with_retryable(true)
                } else {
                    ErrorKind::send(e)
                }
            })
            .await
    }
}

impl Sender<HttpReq, HttpRes> for H2Sender {
    fn send(&self, req: HttpReq) -> BoxFut<Result<HttpRes>> {
        Box::pin(self.send(req))
    }
}

impl<B> Drop for H2Sender<B> {
    fn drop(&mut self) {
        trace!("dropping H2Sender");
    }
}

#[async_trait]
impl<B: http_body::Body + Send + 'static> ReadySend<B> for SendRequest<B> {
    #[instrument(level = "debug", skip_all, fields(req = %fmt_req(&req)), err)]
    async fn ready_send(&self, req: Request<B>) -> hyper::Result<Response<Vec<u8>>> {
        trace!("sending request with HTTP/2 sender");
        let mut this = self.clone();

        trace!("waiting for HTTP/2 sender to be ready");
        this.ready().await?;

        trace!("HTTP/2 sender is ready, sending request");
        this.send_request(req).await?.collect().await
    }
}

#[async_trait]
impl<B: http_body::Body + Send + 'static> ReadySendMut<B> for SendRequest<B> {
    #[instrument(level = "debug", skip_all, fields(req = %fmt_req(&req)), err)]
    async fn ready_send_mut(&mut self, req: Request<B>) -> hyper::Result<Response<Vec<u8>>> {
        trace!("waiting for HTTP/2 sender to be ready");
        self.ready().await?;

        trace!("HTTP/2 sender is ready, sending request");
        self.send_request(req).await?.collect().await
    }
}
