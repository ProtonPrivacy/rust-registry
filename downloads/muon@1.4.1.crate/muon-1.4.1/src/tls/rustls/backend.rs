use crate::common::prelude::*;
use crate::tls::*;
use crate::{ErrorKind, Result};
use futures_rustls::rustls::crypto;
use rustls_platform_verifier::Verifier;
use std::sync::Arc;

/// A TLS implementation using the `rustls` crate.
#[derive(Debug)]
pub struct RustlsTls;

impl Tls for RustlsTls {
    fn build(&self, anchor: DynTrustAnchor, verifier: DynVerifier) -> Result<DynTlsUpgrader> {
        let pki = new_pki_verifier(&anchor.roots())
            .map_err(ErrorKind::tls)?
            .with_provider(crypto::ring::default_provider().into());

        Ok(RustlsTlsUpgrader::new(Arc::new(pki), verifier).into_dyn())
    }
}

crate::if_sealed! {
    impl crate::Sealed for RustlsTls {}
}

/// Create a new `rustls`-based verifier from the given roots.
///
/// This only works on linux.
#[cfg(target_os = "linux")]
fn new_pki_verifier(roots: &[&TlsCertDer]) -> Result<Verifier, webpki::Error> {
    let mut anchors = Vec::new();

    for root in roots.iter().map(|root| root.as_slice().into()) {
        anchors.push(webpki::anchor_from_trusted_cert(&root)?.to_owned());
    }

    Ok(Verifier::new_with_extra_roots(anchors))
}

/// Create a new `rustls`-based verifier.
#[cfg(not(target_os = "linux"))]
fn new_pki_verifier(_: &[&TlsCertDer]) -> Result<Verifier, webpki::Error> {
    Ok(Verifier::new())
}
