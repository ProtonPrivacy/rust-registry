# muon-proc

[![pipeline status](https://gitlab.protontech.ch/ProtonVPN/rust/muon-proc/badges/master/pipeline.svg)](https://gitlab.protontech.ch/ProtonVPN/rust/muon/-/pipelines)
[![Latest Release](https://gitlab.protontech.ch/ProtonVPN/rust/muon-proc/-/badges/release.svg)](https://gitlab.protontech.ch/ProtonVPN/rust/muon-proc/-/releases)
[![Generated Doc](https://img.shields.io/badge/Doc-Generated-blue)](https://protonvpn.gitlab-pages.protontech.ch/rust/muon-proc/)

Muon (named like the particle) is a client library for the Proton API.

This repository contains the procedural macros used in [muon](https://gitlab.protontech.ch/ProtonVPN/rust/muon).