use crate::atlas::new_builder;
use anyhow::Result;
use muon::rt::{PollWith, TokioDialer, TokioResolver, TokioSpawner};
use muon::GET;

#[tokio::test]
async fn test_runtime_dispatcher() -> Result<()> {
    let builder = new_builder().await;

    // Create a dispatcher and its driver.
    let (dispatcher, driver) = muon::rt::dispatcher();

    // Spawn the driver onto the runtime.
    tokio::spawn(driver);

    // Create a session using the dispatcher.
    let s = builder
        .spawner(dispatcher)
        .build()?
        .new_session_without_credentials(())
        .await?;

    // This future will be executed by the dispatcher.
    s.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}

#[tokio::test]
async fn test_runtime_dispatcher_poll_with() -> Result<()> {
    let builder = new_builder().await;

    // Create a dispatcher and its driver.
    // We don't spawn the driver onto the runtime here.
    let (dispatcher, driver) = muon::rt::dispatcher();

    // Create a session using the dispatcher.
    let s = builder
        .spawner(dispatcher)
        .build()?
        .new_session_without_credentials(())
        .await?;

    // This future will be executed by the current thread,
    // which will also drive the dispatcher.
    s.send(GET!("/tests/ping")).poll_with(&driver).await?.ok()?;

    Ok(())
}

#[tokio::test]
async fn test_runtime_tokio() -> Result<()> {
    let s = new_builder()
        .await
        .resolver(TokioResolver)
        .dialer(TokioDialer)
        .spawner(TokioSpawner)
        .build()?
        .new_session_without_credentials(())
        .await?;

    s.send(GET!("/tests/ping")).await?.ok()?;

    Ok(())
}
