//! This module provides the [`Prod`] environment.

use crate::app::{AppVersion, Platform, Product};
use crate::common::prelude::*;
use crate::env::{Env, Server};
use crate::tls::TlsPinSet;
use crate::util::ByteSliceExt;
use lazy_static::lazy_static;
use muon_proc::autoimpl;

/// The production API environment.
///
/// This environment represents the production Proton API, used by default.
/// Clients using this environment will connect to `https://*.proton.me/`.
#[derive(Debug)]
pub struct Prod;

impl Env for Prod {
    fn servers(&self, version: &AppVersion) -> Vec<Server> {
        let (plat, prod) = if let Some(name) = version.name() {
            (name.platform(), name.product())
        } else {
            (&Platform::Web, &Product::Mail)
        };

        let (host, path) = if let Platform::Web = plat {
            (format!("{prod}.proton.me"), "/api")
        } else {
            (format!("{prod}-api.proton.me"), "/")
        };

        servers(&host, &host.alt(), path).unwrap()
    }

    fn pins(&self, server: &Server) -> Option<TlsPinSet> {
        const DIRECT: &[&str] = &[
            "CT56BhOTmj5ZIPgb/xD5mH8rY3BLo/MlhP7oPyJUEDo=",
            "35Dx28/uzN3LeltkCBQ8RHK0tlNSa2kCpCRGNp34Gxc=",
            "qYIukVc63DEITct8sFT7ebIq5qsWmuscaIKeJx+5J5A=",
        ];

        const INDIRECT: &[&str] = &[
            "EU6TS9MO0L/GsDHvVc9D5fChYLNy5JdGYpJw0ccgetM=",
            "iKPIHPnDNqdkvOnTClQ8zQAIKG0XavaPkcEo0LBAABA=",
            "MSlVrBCdL0hKyczvgYVSRNm88RicyY04Q2y5qrBt0xA=",
            "C2UxW0T1Ckl9s+8cXfjXxlEqwAfPM4HiW2y3UdtBeCw=",
        ];

        if server.host().is_direct() {
            lazy_static! {
                static ref PINS: TlsPinSet = match TlsPinSet::from_b64(DIRECT) {
                    Ok(pins) => pins,
                    Err(err) => panic!("failed to initialize Prod pins: {err}"),
                };
            }

            Some(PINS.clone())
        } else {
            lazy_static! {
                static ref PINS: TlsPinSet = match TlsPinSet::from_b64(INDIRECT) {
                    Ok(pins) => pins,
                    Err(err) => panic!("failed to initialize Prod pins: {err}"),
                };
            }

            Some(PINS.clone())
        }
    }
}

if_sealed! {
    impl crate::Sealed for Prod {}
}

fn servers(dir: &str, alt: &str, path: &str) -> Result<Vec<Server>, ParseNameErr> {
    Ok(vec![
        Server::https(Host::direct(dir)?, path),
        Server::https(Host::indirect(alt)?, path),
    ])
}

#[autoimpl]
trait HostExt: AsRef<str> {
    fn alt(&self) -> String {
        format!("d{}.protonpro.xyz", self.as_ref().as_b32())
    }
}
