use crate::env::EnvId;
use crate::store::{DynStore, Store, StoreError};
use crate::{Auth, SessionKeyable};
use async_lock::{RwLock, RwLockReadGuard, RwLockWriteGuard};
use derive_more::{Deref, DerefMut, Display};
use std::collections::HashMap;
use std::sync::Arc;

/// A wrapper around a store that ensures safe access.
#[derive(Debug, Clone)]
pub struct SafeStore<SessionKey: SessionKeyable> {
    env: EnvId,
    hdl: Arc<RwLock<StoreHandle<SessionKey>>>,
}

impl<SessionKey: SessionKeyable> SafeStore<SessionKey> {
    /// Create a new safe auth store.
    pub fn new(store: impl Store<SessionKey>) -> Self {
        let env = store.env();
        let hdl = Arc::new(RwLock::new(StoreHandle::new(store)));

        Self { env, hdl }
    }

    /// Get the environment to which this store is bound.
    pub fn env(&self) -> &EnvId {
        &self.env
    }

    /// Lock the store for reading.
    pub async fn read<'a>(&'a self) -> StoreReadGuard<'a, SessionKey> {
        trace!("locking store for reading");
        let rg = self.hdl.read().await;
        trace!("store now locked for reading");

        StoreReadGuard(rg)
    }

    /// A convenience method to get the current auth.
    ///
    /// This is equivalent to calling `read().await.get_auth().await`.
    pub async fn get_auth(&self, key: &SessionKey) -> Result<(AuthVersion, Auth), StoreError> {
        self.read().await.get_auth(key).await
    }
    pub async fn set_auth(
        &self,
        key: &SessionKey,
        auth: Auth,
    ) -> Result<AuthVersion, StoreError> {
        self.write().await.set_auth(key, auth).await
    }
    pub async fn remove_auth(
        &self,
        key: &SessionKey,
    ) -> Result<(AuthVersion, Option<Auth>), StoreError> {
        self.write().await.remove_auth(key).await
    }
    pub async fn get_all_auth(
        &self,
    ) -> Result<HashMap<SessionKey, (AuthVersion, Auth)>, StoreError> {
        self.read().await.get_all_auth().await
    }
    pub async fn set_all_auth(
        &self,
        auth: HashMap<SessionKey, Auth>,
    ) -> Result<HashMap<SessionKey, AuthVersion>, StoreError> {
        self.write().await.set_all_auth(auth).await
    }
    pub async fn remove_all_auth(&self) -> Result<(), StoreError> {
        self.write().await.remove_all_auth().await
    }

    /// Lock the store for writing.
    pub async fn write<'a>(&'a self) -> StoreWriteGuard<'a, SessionKey> {
        trace!("locking store for writing");
        let wg = self.hdl.write().await;
        trace!("store now locked for writing");

        StoreWriteGuard(wg)
    }
}

/// A read guard for a safe auth store which adds logging.
#[derive(Debug, Deref)]
pub struct StoreReadGuard<'a, SessionKey: SessionKeyable>(
    RwLockReadGuard<'a, StoreHandle<SessionKey>>,
);

impl<SessionKey: SessionKeyable> Drop for StoreReadGuard<'_, SessionKey> {
    fn drop(&mut self) {
        trace!("releasing read lock on store");
    }
}

/// A write guard for a safe auth store which adds logging.
#[derive(Debug, Deref, DerefMut)]
pub struct StoreWriteGuard<'a, SessionKey: SessionKeyable>(
    RwLockWriteGuard<'a, StoreHandle<SessionKey>>,
);

impl<SessionKey: SessionKeyable> Drop for StoreWriteGuard<'_, SessionKey> {
    fn drop(&mut self) {
        trace!("releasing write lock on store");
    }
}

/// An auth version.
///
/// This is used to track changes to the auth data.
/// Each time the auth data is updated, the version is incremented.
#[derive(Debug, Display, Default, Clone, Copy, PartialEq, Eq)]
pub struct AuthVersion(usize);

impl AuthVersion {
    fn upgrade(&mut self) {
        self.0 += 1;
    }
}

/// A handle to a store.
///
/// This is the type used to actually interact with the foreign store.
/// It tracks changes to the auth data; each write increments the version.
#[derive(Debug)]
pub struct StoreHandle<SessionKey: SessionKeyable> {
    store: DynStore<SessionKey>,
    /// Store the version for each session key
    /// The version is used to track changes to the auth data.
    /// Each time the auth data is updated, the version is incremented.
    /// If the session key is not found, the default version is returned.
    /// When the store is cleared, the version is incremented for each session key.
    versions: HashMap<SessionKey, AuthVersion>,
}

impl<SessionKey: SessionKeyable> StoreHandle<SessionKey> {
    fn new(store: impl Store<SessionKey>) -> Self {
        Self {
            store: Box::new(store),
            versions: HashMap::new(),
        }
    }

    /// Get the version for a given session key.
    fn get_version(&self, key: &SessionKey) -> AuthVersion {
        *self.versions.get(key).unwrap_or(&AuthVersion::default())
    }

    /// Increment the version for a given session key.
    fn increment_version(&mut self, key: &SessionKey) -> AuthVersion {
        let entry = self
            .versions
            .entry(key.clone())
            .or_insert(AuthVersion::default());
        entry.upgrade();
        *entry
    }

    pub async fn get_auth(&self, key: &SessionKey) -> Result<(AuthVersion, Auth), StoreError> {
        let auth = self.store.get_auth(key).await?;
        info!("Getting from the store `{key:?}` -> `{auth:?}`");
        Ok((self.get_version(key), auth))
    }
    pub async fn set_auth(
        &mut self,
        key: &SessionKey,
        auth: Auth,
    ) -> Result<AuthVersion, StoreError> {
        info!("Setting to the store `{key:?}` -> `{auth:?}`");

        // The store assumes it will never have anything asked to be set to None
        // Setting to None should call remove
        if auth == Auth::None {
            warn!("Can't set the store key `{key:?}` to `None`, using remove fallback.");
            self.store.remove_auth(key).await.map(|_| ())?
        } else {
            // We check no other session exist with the same UID
            let existing_sessions = self.store.get_all_auth().await?;

            // Don't include an existing session with the same key
            // since it will get overriden in the check
            let mut existing_sessions = existing_sessions;
            let _ = existing_sessions.remove(key);

            for (stored_key, stored_auth) in existing_sessions {
                if stored_auth.uid() == auth.uid() {
                    error!("set_auth: A session with the same UID is already in the store: Inserting SessionKey = {key:?}, Existing SessionKey = {stored_key:?}, both have the same UID {:?}", stored_auth.uid());
                    return Err(StoreError);
                }
            }
            self.store.set_auth(key, auth).await?
        };
        Ok(self.increment_version(key))
    }
    pub async fn remove_auth(
        &mut self,
        key: &SessionKey,
    ) -> Result<(AuthVersion, Option<Auth>), StoreError> {
        info!("Removing from the store {key:?}");
        let auth = self.store.remove_auth(key).await?;
        let version = self.increment_version(key);
        Ok((version, auth))
    }
    pub async fn get_all_auth(
        &self,
    ) -> Result<HashMap<SessionKey, (AuthVersion, Auth)>, StoreError> {
        let all = self.store.get_all_auth().await?;
        // Get all session can't return a session set to None as it doesn't exist
        let all = all
            .into_iter()
            .filter(|(_, v)| v != &Auth::None)
            .map(|(k, v)| {
                let version = self.get_version(&k);
                (k, (version, v))
            })
            .collect();
        info!("Getting all the store `{all:?}`");
        Ok(all)
    }

    pub async fn set_all_auth(
        &mut self,
        auth: HashMap<SessionKey, Auth>,
    ) -> Result<HashMap<SessionKey, AuthVersion>, StoreError> {
        info!("Setting all the store `{auth:?}`");

        // Removing all Session that are set to Auth::None as they aren't supposed to be stored.
        let auth: HashMap<SessionKey, Auth> =
            auth.into_iter().filter(|(_, v)| v != &Auth::None).collect();

        // We check no other session exist with the same UID
        // I could have used an HashSet but I want better error messages telling which two sessions have the same UID
        let mut uid_map = HashMap::with_capacity(auth.len());
        for (session_id, auth) in &auth {
            let uid = auth.uid();
            if let Some(other_session_id) = uid_map.insert(uid, session_id) {
                error!("set_all_auth: A session with the same UID is already in the store: Inserting SessionKey = {session_id:?}, Existing SessionKey = {other_session_id:?}, both have the same UID {uid:?}");
                return Err(StoreError);
            }
        }
        
        // We also need to increment the version for each session key since the new sessions need to be marked as up to date
        let versions = auth.keys().map(|k| (k.clone(), self.increment_version(k))).collect();

        self.store.set_all_auth(auth).await?;
        Ok(versions)
    }

    pub async fn remove_all_auth(&mut self) -> Result<(), StoreError> {
        info!("Clearing the store");
        self.store.remove_all_auth().await?;
        // Update all versions to the latest since the session were removed
        for (_, version) in &mut self.versions {
            version.upgrade();
        }
        Ok(())
    }
}
