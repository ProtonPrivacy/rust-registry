//! ## Client
//!
//! A client is the main component of `Muon`. It allows to communicate with the
//! Proton API by submitting Proton API queries and receiving Proton API
//! responses, using Sessions.
//!
//! The client:
//! - manages its own authentication, refreshing OAuth tokens if needed
//! - ensures that a query is sent by any possible means within user imposed
//!   constraints and fail only if all possible scenarios have been tried. It
//!   means that the client ensures that the query was retried and tried
//!   multiple path to reach the API if needed.
//! - the sessions are shareable and cheaply clonable. It means that the client handles
//!   concurrent access to its shared resources
//! - the client should be a singleton
//!
//! ## Create a client without persistent storage
//!
//! A client needs at least an [`App`](`crate::App`) and an
//! [`EnvId`](`crate::env::EnvId`).
//!
//! ```
//! use muon::{App, Client, env::EnvId, GET};
//! # use muon::doc::*;
//! # tokio_test::block_on(async {
//! let app = App::new("windows-vpn@4.1.0")?;
//! let env = EnvId::new_prod();
//! let client = Client::new(app, env.into_store()).await?;
//! let session = client.new_session_without_credentials(()).await?;
//! let res = session.send(GET!("/tests/ping")).await?;
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ## Create a client with persistent storage
//! To have a persistent storage, one should provide an implementation of
//! [`Store`](`crate::store::Store`) along with an [`App`](`crate::App`).
//!
//! ### Example
//! ```
//! #
//! # use muon::doc::*;
//! use muon::{App, Client, GET};
//! # tokio_test::block_on(async {
//! let store = MyPersistenceStorage::prod();
//! let app = App::new("windows-vpn@4.1.0")?;
//! let client = Client::new(app, store).await?;
//! let session = client.new_session_without_credentials(()).await?;
//! let res = session.send(GET!("/tests/ping")).await?;
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ## Session interface
//! A [`Session`](`crate::Session`) exposes the interface to:
//! - Authenticate: [`Session::auth`](`crate::Session::auth`) with the associated
//!   flows [`client::flow::AuthFlow`](`crate::client::flow::AuthFlow`). See
//!   [`client::flow`](`crate::client::flow`) for authentication details.
//!
//! ### Login example
//! ```
//! use muon::client::flow::LoginFlow;
//! use muon::client::PasswordMode;
//! use muon::{App, Client, GET};
//! use async_trait::async_trait;
//! use muon::client::{Fingerprint, InfoProvider};
//! use serde_json::json;
//! use std::sync::Arc;
//! # use muon::doc::*;
//! # tokio_test::block_on(async {
//! const USER: &str = "user";
//! const PASS: &str = "pass";
//!
//! // InfoProviderImpl is created by the client apps and passed to muon
//! // It takes care of requesting extra info from the clients on a need basis
//! // Including requesting the fingerprint as you can see below:
//! struct InfoProviderImpl {}
//! #[async_trait]
//! impl InfoProvider for InfoProviderImpl {
//!    async fn fingerprint(&self) -> Option<Fingerprint> {
//!        let fingerprint = json!({
//!            "mail-android-99.9.40.0-challenge":{
//!                "appLang":"en",
//!                "deviceName":"TestDevice",
//!                "frame":{
//!                    "name":"username"
//!                },
//!                "isDarkmodeOn":false,
//!                "isJailbreak":false,
//!                "keyboards":[
//!
//!                ],
//!                "preferredContentSize":"2.0",
//!                "regionCode":"CH",
//!                "storageCapacity":"63.8",
//!                "timezone":"Europe/Zurich",
//!                "timezoneOffset":"0",
//!                "v":"2.0.0"
//!            }
//!        })
//!        .into();
//!        Some(fingerprint)
//!    }
//! }
//!
//! let store = MyPersistenceStorage::prod();
//! let app = App::new("windows-vpn@4.1.0")?;
//! // Create the client with an info_provider. The info_provider requests additional information from the client on demand, including the fingerprint.
//! // The fingerprint is needed, for example, when sending a call to create an unauthenticated session, or during login.
//! let session = Client::new(app, store).await?.with_info_provider(Arc::new(InfoProviderImpl {})).new_session_without_credentials(()).await?;
//!
//! // perform the login flow
//! let (session, data) = match session.auth().login(USER, PASS).await {
//!     LoginFlow::Ok(authenticated_session, data) => {
//!         // show that we successfully logged in
//!         display_authenticated_user_info(&authenticated_session);
//!
//!         // continue with the authenticated_session and the associated data
//!         (authenticated_session, Some(data))
//!     },
//!
//!     // The user needs to provide 2FA
//!     LoginFlow::TwoFactor(session_needs_2fa, data) => {
//!         // show a modal asking for 2fa
//!         let twofa = ask_user_for_2fa();
//!
//!         // provide the 2fa, we either get an authenticated client or not.
//!         (session_needs_2fa.totp(twofa).await?, Some(data))
//!     },
//!
//!     LoginFlow::Failed {session, reason} => {
//!         // handle the error
//!         show_user_cant_login_modal(reason);
//!
//!         // continue with the unauthenticated session
//!         (session, None)
//!     },
//! };
//!
//! // ensure that we have authenticated data
//! let Some(data) = &data else {
//!     anyhow::bail!("authentication failed");
//! };
//!
//! // load the preferences of the user using its user-id
//! load_user_preferences(&data.user_id)?;
//!
//! // get the password for the user's PGP key (if needed)
//! let password = match data.password_mode {
//!     PasswordMode::One => PASS.to_owned(),
//!     PasswordMode::Two => ask_user_for_mbp(),
//! };
//!
//! // unlock the user's PGP key with the correct password
//! unlock_pgp_key(&session, &password);
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! - logout: [`Session::logout`](`crate::Session::logout`) can never fail as the
//!   local state must always be editable. If there is an error during the
//!   logout process, the application should behave as un-authenticated, and
//!   behave as-is until instructed otherwise by the user (i.e., login). In case
//!   of state inconsistency, the best thing to do is to behave normally (we do
//!   not guess the state) and the API will tell us what to do.
//!
//! ### Logout example
//! ```
//! use muon::{App, Client, env::EnvId};
//! # use muon::doc::*;
//! # tokio_test::block_on(async {
//! let env = EnvId::new_atlas();
//! let app = App::new("windows-vpn@4.1.0")?;
//! let client = Client::new(app, env.into_store()).await?;
//! let session = client.new_session_without_credentials(()).await?;
//!
//! // skipping the login part ...
//!
//! session.logout().await;
//!
//! // the session is now un-authenticated
//!
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! - Fork: [`fork`](crate::Session::fork)
//!
//!   see [`flow`] for details forking and import forks.
//!
//! ### Fork a parent session example
//! ```
//! # use muon::doc::*;
//! # fn display_selector() -> String {"".to_owned()}
//! # fn handle_fork_failure(r: impl Into<muon::Error>) {}
//! # async fn send_selector_to_slave(s: String) {}
//! # tokio_test::block_on(async {
//! use muon::client::flow::ForkFlowResult;
//! use muon::{App, Client, GET};
//! let store = MyPersistenceStorage::prod();
//! let app = App::new("windows-vpn@4.1.0")?;
//! let client = Client::new(app, store).await?;
//!
//! // skipping the login part ...
//! let session = match client.new_session_without_credentials(()).await?
//!     .fork("windows-vpn")
//!     .payload(b"hello world")
//!     .send()
//!     .await {
//!     // Client has been forked successfully ...
//!     ForkFlowResult::Success(session, selector) => {
//!         // send the selector to the slave
//!         send_selector_to_slave(selector).await;
//!         // continue normally with the client
//!         session
//!     }
//!     ForkFlowResult::Failure { session, reason } => {
//!         // handle the fork failure; e.g., too many forks or recursive fork
//!         handle_fork_failure(reason);
//!         // continue with the un-forked session
//!         session
//!     },
//!
//! };
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! - Request sending: [`Session::send`](`crate::Session::send`)
//!
//! ### Example
//! ```
//! #
//! # use muon::doc::*;
//! # tokio_test::block_on(async {
//! use muon::{App, Client, GET};
//! let store = MyPersistenceStorage::prod();// aa
//! let app = App::new("windows-vpn@4.1.0")?;
//! let client = Client::new(app, store).await?;
//! let session = client.new_session_without_credentials(()).await?;
//! let res = session.send(GET!("/tests/ping")).await?;
//! # anyhow::Ok(())
//! # });
//! ```
//!
//! ## Session state storage
//! A [`Client`](`crate::Client`) contains an in-memory storage and a user
//! defined persistence storage following the
//! [`store::Store`](`crate::store::Store`) interface. Both storage are
//! infallible, the in-memory storage is the source of truth for the
//! [`Client`](`crate::Client`).
//!
//! In case the persistence storage can not be synchronized
//! with the local one (e.g., due to IO errors), the state IS considered
//! inconsistent and the application is considered on its own. The persistent
//! storage is assumed to handle his errors on its own (see
//! example-fallible-store).
//!
//! ### How to resync an de-synchronized store
//! ```
//! # use muon::doc::*;
//! # fn is_store_unsync() -> bool { true }
//! # fn display_modal_unsync() {}
//! # tokio_test::block_on(async {
//! use std::thread;
//! use std::time::Duration;
//! use muon::{App, Client, GET};
//! use muon::client::flow::LoginFlow;
//! let store = MyPersistenceStorage::prod();
//! let app = App::new("windows-vpn@4.1.0")?;
//! let session = Client::new(app, store).await?.new_session_without_credentials(()).await?;
//! let session = match session.auth().login("user", "password").await {
//!     LoginFlow::Ok(authenticated_session, _) => {
//!         // show that we successfully logged in
//!         display_authenticated_user_info(&authenticated_session);
//!         // continue with the authenticated session
//!         authenticated_session
//!     },
//!     // The user needs to provide 2FA
//!     LoginFlow::TwoFactor(session_needs_2fa, _) => {
//!         // show a modal asking for 2fa
//!         let twofa = ask_user_for_2fa();
//!         // provide the 2fa, we either get an authenticated session or not.
//!         session_needs_2fa.totp(twofa).await?
//!     },
//!     LoginFlow::Failed {session, reason} => {
//!         // handle the error
//!         show_user_cant_login_modal(reason);
//!         // continue with the unauthenticated session
//!         session
//!     },
//! };
//!
//! // check if we have received a signal that we have been unsync
//! if is_store_unsync() {
//!     // show a modal telling the user how to unblock the situation
//!     display_modal_unsync();
//!     // wait for the user to resolve
//!     thread::sleep(Duration::from_secs(5));
//!     // manually try to sync again
//!     session.client().sync_stores().await;
//! }
//!
//! # anyhow::Ok(())
//! # });
//! ```

use crate::app::App;
use crate::common::prelude::*;
use crate::env::EnvId;
use crate::error::{ErrorKind, Result};
use crate::http::{DynHttpSender, HttpReq, HttpRes};
use crate::sessions::{DuplicatedSessionCredentials, SessionAlreadyExists};
use crate::{Session, SessionCredentials, SessionKeyable};
use async_trait::async_trait;
use muon_proc::derive_dyn;
use private::ClientInternalStorage;
use serde_json::Value;
use std::str::FromStr;
use std::sync::Arc;

pub mod flow;
/// todo
pub mod headers;
/// todo
pub mod middleware;
// re-export of auth here
pub use crate::auth::{Auth, PasswordMode, Tokens};
/// Implements a builder for configuring a `muon` client.
mod builder;
pub use builder::Builder;

/// Helper traits for async conversions.
mod helpers;
pub(crate) use helpers::*;

mod private {
    use std::collections::HashMap;

    use super::{AsyncFrom, Auth};
    use crate::env::EnvId;
    use crate::store::{AuthVersion, InMemoryStore, SafeStore, Store};
    use crate::SessionKeyable;
    use async_trait::async_trait;
    /// The stores contained in a [`Client`].
    /// It contains an in-memory store that can never fail and has the local
    /// state of the [`Client`] and a persistent one.
    #[derive(Debug, Clone)]
    pub struct ClientInternalStorage<SessionKey: SessionKeyable> {
        /// The local in-memory store
        local_store: SafeStore<SessionKey>,

        /// An optional persistent store. The local store will always try to
        /// push its state into the persistent store.
        persistent_store: Option<SafeStore<SessionKey>>,
    }

    #[async_trait]
    impl<SessionKey: SessionKeyable, T: Store<SessionKey>> AsyncFrom<T>
        for ClientInternalStorage<SessionKey>
    {
        async fn from(store: T) -> Self {
            let env_id = store.env();
            let auth = store.get_all_auth().await.unwrap_or_default();

            Self {
                local_store: SafeStore::new(InMemoryStore::new(env_id, Some(auth))),
                persistent_store: Some(SafeStore::new(store)),
            }
        }
    }

    impl<SessionKey: SessionKeyable> ClientInternalStorage<SessionKey> {
        /// Get the env the [`Store`] are bound to
        pub(crate) fn env(&self) -> &EnvId {
            self.local_store.env()
        }

        /// Get a reference to the local storage
        pub(crate) fn local(&self) -> &SafeStore<SessionKey> {
            &self.local_store
        }

        /// A convenience function that retrieves the local store's auth state.
        pub(crate) async fn get_auth(&self, session_key: &SessionKey) -> (AuthVersion, Auth) {
            // Panic safety: This is unreachable as memory store can't fail
            self.local_store
                .get_auth(session_key)
                .await
                .expect("Unreachable: Error getting auth from local store")
        }

        /// A convenience function that retrieves the local store's auth state.
        pub(crate) async fn get_all_auth(&self) -> HashMap<SessionKey, (AuthVersion, Auth)> {
            // Panic safety: This is unreachable as memory store can't fail
            self.local_store
                .get_all_auth()
                .await
                .expect("Unreachable: Error getting all auth from local store")
        }

        /// A convenience function that sets the local store's auth state
        /// and attempts to sync the local store with the persistent store.
        pub(crate) async fn set_auth(&self, session_key: &SessionKey, auth: Auth) {
            // set_auth can fail if the session UID is already in the store
            match self.local_store.set_auth(session_key, auth).await {
                Ok(_) => (),
                Err(e) => {
                    error!("Error setting auth in local store: {e:?}");
                }
            }
            self.sync_stores().await;
        }

        /// A convenience function that sets the local store's auth state
        /// and attempts to sync the local store with the persistent store.
        pub(crate) async fn remove_auth(&self, session_key: &SessionKey) -> Option<Auth> {
            // Panic safety: This is unreachable as memory store can't fail
            let (_, result) = self
                .local_store
                .remove_auth(session_key)
                .await
                .expect("Unreachable: Error removing auth from local store");
            self.sync_stores().await;
            result
        }

        /// Removes all sessions from the store.
        pub(crate) async fn remove_all_auth(&self) {
            // Panic safety: This is unreachable as memory store can't fail
            self.local_store
                .remove_all_auth()
                .await
                .expect("Unreachable: Error removing all auth from local store");
            self.sync_stores().await;
        }

        /// Sync the local store with the persistent store
        /// There is no guarantee that the persistent store is accepting the
        /// data from the point of view of this function.
        pub(crate) async fn sync_stores(&self) {
            if let Some(persistent_store) = self.persistent_store.as_ref() {
                info!("pushing from local to persistent storage");

                // Push the auth from the local store to the persistent store;
                // we don't care about the new version.
                let auth_map = self
                    .local_store
                    .get_all_auth()
                    .await
                    .expect("Unreachable: get_all_auth calls can't fail");

                let auth_map = auth_map
                    .into_iter()
                    .map(|(key, (_ver, auth))| (key, auth))
                    .collect();
                if let Err(e) = persistent_store.set_all_auth(auth_map).await {
                    error!("Error setting all auth: {e:?}");
                    return;
                }
            }
        }
    }
}

/// A Proton API client.
///
/// The client is the primary interface for interacting with the Proton API.
/// Internally, the client is simply a wrapper around an HTTP sender and a
/// handle to an auth store.
///
/// The client is designed to be cheaply cloneable and shareable across threads.
#[derive(Debug, Clone)]
pub struct Client<SessionKey: SessionKeyable> {
    sender: DynHttpSender,
    stores: ClientInternalStorage<SessionKey>,
    provider: Option<Arc<dyn InfoProvider>>,
}

impl<SessionKey: SessionKeyable> Client<SessionKey> {
    /// Gets a reference to the client's HTTP sender.
    pub(crate) fn sender(&self) -> &DynHttpSender {
        &self.sender
    }

    /// Gets a reference to the client's stores.
    pub(crate) fn stores(&self) -> &ClientInternalStorage<SessionKey> {
        &self.stores
    }

    /// Gets a reference to the client's provider.
    pub(crate) fn provider(&self) -> Option<&Arc<dyn InfoProvider>> {
        self.provider.as_ref()
    }

    /// Creates a new `muon` client with a default configuration.
    /// The client will be configured for the given `app` and `store`.
    ///
    /// This is a convenience function; non-default configurations can be built
    /// using the [`Client::builder`] method directly.
    ///
    /// # Errors
    ///
    /// Returns an error if the client cannot be built, which can occur if TLS
    /// configuration fails, for example.
    pub async fn new(
        app: App,
        store: impl AsyncInto<ClientInternalStorage<SessionKey>>,
    ) -> Result<Client<SessionKey>> {
        #[allow(deprecated)]
        Self::builder(app, store).await.build()
    }

    /// Creates a new client builder.
    pub async fn builder(
        app: App,
        store: impl AsyncInto<ClientInternalStorage<SessionKey>>,
    ) -> Builder<SessionKey> {
        Builder::builder(app, store).await
    }

    /// Add an info provider to the client. Used by muon to ask for information.
    pub fn with_info_provider(mut self, provider: Arc<dyn InfoProvider>) -> Self {
        self.provider = Some(provider);
        self
    }

    /// Get the environment to which this client is bound.
    pub fn env(&self) -> &EnvId {
        self.stores.env()
    }

    fn from_parts(sender: DynHttpSender, stores: ClientInternalStorage<SessionKey>) -> Self {
        Self {
            sender,
            stores,
            provider: None,
        }
    }
}

/// Manages the creation, retrieval, and storage of `Session` objects.
///
/// # Examples
///
/// A complete lifecycle: building a [`crate::Client`], adding a session, retrieving it,
/// and then removing it.
///
/// ```
/// use muon::{App, Client, env::EnvId, SessionCredentials};
/// use serde_json::json;
///
/// # #[tokio::main]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// #
/// // 1. Configure the application and build the client.
/// let app = App::new("windows-vpn@4.1.0")?;
/// let env = EnvId::new_atlas();
/// let builder = Client::builder(app, env.into_store());
///
/// let client = builder.await.build()?;
///
/// // 2. Add a new session for a user after they log in. This persists the session immediately.
/// let user_id = "user-id-123".to_string();
/// # let creds_json = json!({
/// #     "UserID": "test-user",
/// #     "UID": "test-uid",
/// #     "AccessToken": "test-access",
/// #     "RefreshToken": "test-refresh",
/// #     "Scopes": ["test-scope"],
/// # });
/// # let credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
/// let session = client.new_session_with_credentials(user_id.clone(), credentials).await?;
/// println!("Successfully added session for user: {}", session.session_key());
///
/// // 3. Retrieve all active sessions from storage.
/// for s in client.get_all_sessions().await {
///     println!("Found active session: {}", s.session_key());
/// }
///
/// // 4. Remove all sessions when needed.
/// client.remove_all_sessions().await;
/// println!("All sessions have been removed.");
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// # }
/// ```
/// # Important: Pitfalls of the new Session API
///
/// WARNING: The new Sessions API comes with a couple of caveats, that can lead to:
///
/// 1. Mixing data between users: Sending data meant for `user_1` to `user_2`.
/// 2. Authenticated sessions becoming unauthenticated.
///
/// ## Mixing data between users
/// Session objects are clonable and reference session credentials by a session key. Take the following scenario:
///
/// 1. There's a `session_user` object with the session key `user`, that the codebase assumes is used to send data for `user_1`.
/// 2. The session credentials for the session key `user` are removed.
/// 3. New session credentials, that belong to `user_2`, are added for the session key `user`.
/// 4. Now the `session_user` object will send data that is associated with `user_2` not `user_1`.
/// 5. This can all happen on a separate thread with no notice of any changes, and can lead to data mixing if not careful.
///
/// ## Authenticated sessions becoming unauthenticated
///
/// Assume there's a `Session` object called `session_one` that uses the session key `user`. For the session key `user` there are authenticated session credentials stored.
///
/// Assume that the session credentials for the session key `user` are removed. Now, if the `Session` object `session_one` is used to send a request this is what happens behind the scenes:
///
/// 1. Muon will check if there are session credentials saved for the session key `user`
/// 2. Because there are no session credentials, Muon will ask the backend for unauthenticated session credentials
/// 3. Muon will save the unauthenticated session credentials for the session key `user`
/// 4. Muon will use the unauthenticated session credentials to send the request.
///
/// If the request needs authenticated session credentials, it will return an error.
///
/// ## Mitigation plan
///
/// The issue is that the credentials that a `Session` object references can change without notice. This can lead to subtle, hard to find bugs.
///
/// To address this we need a way to stop `Session` objects whose credentials have changed from performing actions.
///
/// We have a few ideas on how to do this, and a fix is coming soon.
///
impl<SessionKey: SessionKeyable> Client<SessionKey> {
    /// Returns a session only if its credentials have been persisted to storage.
    ///
    /// Note:
    ///
    /// A session created with [`new_session_without_credentials()`](Self::new_session_without_credentials)
    /// is not immediately persisted, because credentials are not yet available.
    /// It is only saved after the first API request is made using that session object.
    /// On the first API call we get unauth credentials, save them, and then send the request.
    /// Therefore, calling `get_session()` immediately after `new_session_without_credentials()`
    /// will return `None`.
    ///
    /// A session created with [`new_session_without_credentials()`](Self::new_session_without_credentials) is immediately persisted
    /// and calling `get_session()` will return Some(session).
    ///
    /// # Examples
    ///
    /// ```
    /// use muon::{App, Client, env::EnvId};
    /// use serde_json::json;
    /// use muon::SessionCredentials;
    ///
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let app = App::new("windows-vpn@4.1.0")?;
    /// let env = EnvId::new_atlas();
    /// let client: Client<String> = Client::builder(app, env.into_store()).await.build()?;
    ///
    /// let session_key = "test-user".to_string();
    ///
    /// // Initially, the session should not exist.
    /// assert!(client.get_session(session_key.clone()).await.is_none());
    ///
    /// // Create a session object. This does NOT save it to storage yet.
    /// let _session = client.new_session_without_credentials(session_key.clone()).await?;
    ///
    /// // The session has not been persisted, so `get_session` will still return `None`.
    /// // A request must be sent with the session object first.
    /// let retrieved_session = client.get_session(session_key.clone()).await;
    /// assert!(retrieved_session.is_none());
    ///
    /// # // Assume we have some SessionCredentials from the backend
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let session_credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    ///
    /// // Create a session object. It is persisted.
    /// let _session = client.new_session_with_credentials(session_key.clone(), session_credentials).await?;
    ///
    /// // The session is persisted, so `get_session` will still return `Some(session)`.
    /// let retrieved_session = client.get_session(session_key.clone()).await;
    /// assert!(retrieved_session.is_some());
    ///
    /// #
    /// # Ok(())
    /// # }
    /// ```
    pub async fn get_session(&self, session_key: SessionKey) -> Option<Session<SessionKey>> {
        let (_, stored_auth) = self.stores.get_auth(&session_key).await;
        match stored_auth {
            Auth::Internal { .. } | Auth::External { .. } | Auth::Anonymous { .. } => {
                Some(Session::new(self.clone(), session_key))
            }
            Auth::None => {
                info!("Session {:?} doesn't exist in `get_session`.", session_key);
                None
            }
        }
    }

    /// Retrieves all sessions with persisted credentials and constructs
    /// `Session` objects for them.
    ///
    /// Note that sessions created via `new_session_without_credentials` will not
    /// appear here until after their first API request has been made, because credentials are not available yet.
    /// Credentials for a session without credentials are requested from the backend during the first API call.
    /// Only after that will the session appear in the result of this function.
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, env::EnvId, SessionCredentials};
    /// # use serde_json::json;
    /// #
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let app = App::new("windows-vpn@4.1.0")?;
    /// let env = EnvId::new_atlas();
    /// let client = Client::builder(app, env.into_store()).await.build()?;
    /// # // Assume we have session credentials from the backend
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    ///
    /// let session_name = "randomuser".to_string();
    ///
    /// let all_sessions = client.get_all_sessions().await;
    /// assert!(all_sessions.is_empty());
    ///
    /// // Use `new_session_with_credentials` to ensure the session is stored immediately.
    /// let _ = client.new_session_with_credentials(session_name.clone(), credentials).await?;
    ///
    /// let all_sessions = client.get_all_sessions().await;
    /// assert_eq!(all_sessions.len(), 1);
    ///
    /// client.remove_all_sessions().await;
    ///
    /// let all_sessions = client.get_all_sessions().await;
    /// assert!(all_sessions.is_empty());
    ///
    /// # Ok(())
    /// # }
    /// ```
    pub async fn get_all_sessions(&self) -> Vec<Session<SessionKey>> {
        let sessions = self.stores.get_all_auth().await;

        sessions
            .into_keys()
            .map(|session_key| Session::new(self.clone(), session_key))
            .collect()
    }

    /// Creates a new session, persists its credentials,
    /// and returns the corresponding [`Session`] object.
    ///
    /// This method immediately saves the session to the persistent store.
    ///
    /// # Arguments
    ///
    /// * `session_key` - The unique identifier for the new session.
    /// * `credentials` - The credentials obtained from a successful login.
    ///
    /// # Errors
    ///
    /// Returns an error if:
    /// 1. a session with the same `session_key` already exists
    /// 2. a session credential with the same `uid` as the `credentials` already exists
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, env::EnvId, SessionCredentials};
    /// # use serde_json::json;
    /// #
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let app = App::new("windows-vpn@4.1.0")?;
    /// # let env = muon::env::EnvId::new_atlas();
    /// # let client: Client<String> = Client::builder(app, env.into_store()).await.build()?;
    /// // In a real application, credentials would be obtained from a login flow.
    /// // For this example, we'll use default credentials.
    /// # let creds_json = json!({
    /// #     "UserID": "test-user",
    /// #     "UID": "test-uid",
    /// #     "AccessToken": "test-access",
    /// #     "RefreshToken": "test-refresh",
    /// #     "Scopes": ["test-scope"],
    /// # });
    /// # let session_credentials: SessionCredentials = serde_json::from_value(creds_json).unwrap();
    /// let session_key = "new-user-456".to_string();
    ///
    /// let session = client.new_session_with_credentials(session_key.clone(), session_credentials).await?;
    /// println!("Created authenticated session for: {}", session.session_key());
    ///
    /// // Verify the session was created and can be retrieved immediately.
    /// let retrieved_session = client.get_session(session_key).await;
    /// assert!(retrieved_session.is_some());
    /// # Ok(())
    /// # }
    /// ```
    pub async fn new_session_with_credentials(
        &self,
        session_key: SessionKey,
        credentials: SessionCredentials,
    ) -> Result<Session<SessionKey>> {
        let stored_auths = self.stores.get_all_auth().await;

        let (_version, stored_auth) = stored_auths.get(&session_key).cloned().unwrap_or_default();

        // Using a match instead of if let to ensure all case are handled
        match stored_auth {
            Auth::Internal { .. } | Auth::External { .. } | Auth::Anonymous { .. } => {
                return Err(ErrorKind::auth(SessionAlreadyExists));
            }
            Auth::None => {}
        }
        // Remove all other anonymous sessions with the same session UID
        let uid = credentials.uid();

        for (stored_key, (_version, stored_auth)) in &stored_auths {
            if let Some(stored_uid) = stored_auth.uid() {
                if stored_uid == uid && matches!(stored_auth, Auth::Anonymous { .. }) {
                    self.stores.remove_auth(stored_key).await;
                } else if stored_uid == uid {
                    return Err(ErrorKind::auth(DuplicatedSessionCredentials));
                }
            }
        }
        // Add the session
        // The store will take care of checking if another session exists with the same UID.
        let auth = credentials.as_auth();
        self.stores.set_auth(&session_key, auth).await;
        Ok(Session::new(self.clone(), session_key))
    }

    /// Creates a new **unauthenticated** session object in memory.
    ///
    /// This function creates a `Session` object but does not immediately persist credentials
    /// to storage, because they don't exist yet. The session credentials are only saved (and anonymous credentials are created
    /// on the backend) when the first API request is made using the returned `Session` object.
    ///
    /// Consequently, calling [`get_session()`](Self::get_session) or [`get_all_sessions()`](Self::get_all_sessions)
    /// immediately after this function will not find this new session, as it does not yet exist
    /// in the store.
    ///
    /// # Arguments
    ///
    /// * `session_key` - The unique identifier for the new unauthenticated session.
    ///
    /// # Errors
    ///
    /// Returns an error if a fully authenticated session already exists with the same key.
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, env::EnvId};
    /// #
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let app = App::new("windows-vpn@4.1.0")?;
    /// # let env = muon::env::EnvId::new_atlas();
    /// # let client: Client<String> = Client::builder(app, env.into_store()).await.build()?;
    ///
    /// // Create a session object for a guest user.
    /// let session_key = "guest-user-54".to_string();
    /// let session = client.new_session_without_credentials(session_key.clone()).await?;
    /// println!("Created unauthenticated session object for guest: {}", session.session_key());
    ///
    /// // The session is not yet persisted to storage, so `get_session` will return `None`.
    /// let retrieved_session = client.get_session(session_key.clone()).await;
    /// assert!(retrieved_session.is_none());
    ///
    /// // After the first API request is made with the `session` object,
    /// // it will be stored, and `get_session` will be able to retrieve it.
    /// # Ok(())
    /// # }
    /// ```
    pub async fn new_session_without_credentials(
        &self,
        session_key: SessionKey,
    ) -> crate::error::Result<Session<SessionKey>> {
        // Checking if an authenticated session is already setup.
        let (_, stored_auth) = self.stores.get_auth(&session_key).await;
        match stored_auth {
            Auth::Internal { .. } | Auth::External { .. } => {
                Err(ErrorKind::auth(SessionAlreadyExists))
            }
            Auth::None | Auth::Anonymous { .. } => Ok(Session::new(self.clone(), session_key)),
        }
    }

    /// Removes **all** sessions from the persistent store.
    ///
    /// This is a destructive operation that clears all session credentials.
    /// This can be useful for cleanup, resetting state, or in tests.
    ///
    /// WARNING: Any Session objects that are left in memory after calling `remove_all_sessions` will become unauthenticated Sessions.
    /// This means that if you use them after calling `remove_all_sessions`, Muon will request unauthenticated credentials from the backend
    /// on the first api call and use those to send the first and all subsequent requests.
    /// The session key of the Session oject will be used to save the unauthenticated credentials, so if you want to provide new credentials for the same key
    /// after that, an error will be thrown by `new_session_with_credentials`, because the session key already has session credentials associated
    /// with it.
    ///
    /// # Examples
    ///
    /// ```
    /// # use muon::{App, Client, env::EnvId, SessionCredentials};
    /// # use serde_json::json;
    /// #
    /// # #[tokio::main]
    /// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let app = App::new("windows-vpn@4.1.0")?;
    /// # let env = muon::env::EnvId::new_atlas();
    /// # let client: Client<String> = Client::builder(app, env.into_store()).await.build()?;
    /// # let dummy_credentials = |x: usize| {
    /// #     let creds_json = json!({
    /// #         "UserID": "test-user",
    /// #         "UID": x.to_string(),
    /// #         "AccessToken": "test-access",
    /// #         "RefreshToken": "test-refresh",
    /// #         "Scopes": ["test-scope"],
    /// #     });
    /// #     serde_json::from_value(creds_json).unwrap()
    /// # };
    /// #
    /// // Create a couple of sessions that are immediately persisted.
    /// client.new_session_with_credentials("user1".to_string(), dummy_credentials(1)).await?;
    /// client.new_session_with_credentials("user2".to_string(), dummy_credentials(2)).await?;
    ///
    /// // Adding another session with different credentials
    /// client.new_session_with_credentials("user3".to_string(), dummy_credentials(3)).await?;
    ///
    /// assert_eq!(client.get_all_sessions().await.len(), 3);
    ///
    /// // This will remove all stored sessions.
    /// client.remove_all_sessions().await;
    ///
    /// println!("All sessions have been removed.");
    ///
    /// // Verifying that no sessions remain.
    /// let remaining_sessions = client.get_all_sessions().await;
    /// assert!(remaining_sessions.is_empty());
    /// # Ok(())
    /// # }
    /// ```
    pub async fn remove_all_sessions(&self) {
        self.stores.remove_all_auth().await
    }

    /// Manually try to synchronize the local store with the persistent
    /// storage(s).
    ///
    /// It will push the local state of the client held in the in-memory storage
    /// into the registered persistent storage(s).
    ///
    /// The sync may or may not fail, but it is the responsibility of the
    /// user-defined [`Store`](crate::store::Store) to handle them.
    /// ```
    /// # use muon::doc::*;
    /// # use std::time::Duration;
    /// # use std::thread;
    /// # fn is_store_unsync() -> bool { true }
    /// # fn display_modal_unsync() {}
    /// # tokio_test::block_on(async {
    /// # use muon::{App, Client, http::GET};
    /// let app = App::new("windows-vpn@4.1.0")?;
    /// let app = app.with_user_agent("Mozilla/5.0");
    /// let store = MyPersistenceStorage::prod();
    /// let client = Client::new(app, store).await?;
    /// let session = client.new_session_without_credentials(()).await?;
    /// // ... skip the login part ...
    /// session.clone().logout().await;
    /// // storage discrepancy detected ... wait until resolved...
    /// if is_store_unsync() {
    ///   thread::sleep(Duration::from_secs(10));
    ///   // try to re-sync manually
    ///   client.sync_stores().await;
    /// }
    /// # anyhow::Ok(())
    /// # });
    /// ```
    pub async fn sync_stores(&self) {
        self.stores.sync_stores().await
    }
}

/// This function sends the [`HttpReq`] ensuring it times out after `expire_in`,
/// regardless of request scenario (503/429/301...).
///
/// This is the main entrypoint for requests sent through Muon.
///
/// # Note
/// The current way of handling requests expiration with [`TimeoutLayer`] is not
/// working properly when handling `429` responses. Hence, this method is
/// supposed to surround the whole request processing stack (including
/// 429/503/301 retry-after etc.).
///
/// # Runtime
/// This function abstracts the runtime used to apply the timeout operation.
pub(crate) async fn send_expiring_request(
    sender: impl Sender<HttpReq, HttpRes>,
    req: HttpReq,
    expire_in: std::time::Duration,
) -> Result<HttpRes, crate::Error> {
    let send_fut = sender.send(req);
    let err = Err(crate::Error::new(ErrorKind::Send, Some(Timeout)));
    if_rt_async! {{
        let delay_fut = futures_timer::Delay::new(expire_in);
        match futures::future::select(send_fut, delay_fut).await {
            futures::future::Either::Left((ret, _)) => ret,
            futures::future::Either::Right((_, _)) => err,
        }
    } else if_rt_tokio! {{
        let delay_fut = tokio::time::sleep(expire_in);
        tokio::select! {
            ret = send_fut => ret,
            _ = delay_fut => err
        }
    } else {
        compile_error!("a runtime must be enabled")
    }}}
}

/// An interface to the info provider. This is used by the muon Client to ask for extra info from the apps that use it.
/// All functions defined by InfoProvider need return optionals. Apps that integrate muon need to be able to choose if they send the info that muon wants to request.
/// Here's an example on how to use InfoProvider
/// ```
/// use muon::{App, Client};
/// use muon::env::EnvId;
/// use muon::client::flow::LoginFlow;
/// use std::sync::Arc;
/// use async_trait::async_trait;
/// use muon::client::{InfoProvider,Fingerprint};
/// use serde_json::json;
///
/// // ExampleInfoProvider shows how to implement the InfoProvider trait a client that uses muon.
/// struct ExampleInfoProvider {}
/// #[async_trait]
/// impl InfoProvider for ExampleInfoProvider {
///     async fn fingerprint(&self) -> Option<Fingerprint> {
///         let fingerprint = json!({
///             "mail-android-99.9.40.0-challenge":{
///                 "appLang":"en",
///                 "deviceName":"TestDevice",
///                 "frame":{
///                     "name":"username"
///                 },
///                 "isDarkmodeOn":false,
///                 "isJailbreak":false,
///                 "keyboards":[
///                 ],
///                 "preferredContentSize":"2.0",
///                 "regionCode":"CH",
///                 "storageCapacity":"63.8",
///                 "timezone":"Europe/Zurich",
///                 "timezoneOffset":"0",
///                 "v":"2.0.0"
///             }
///         })
///         .into();
///         Some(fingerprint)
///     }
/// }
///
/// # #[tokio::main]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// let app = App::new("windows-vpn@4.1.0")?;
/// let store = EnvId::new_atlas();
/// // Please check the auth-info-provider.rs example to see how to pass a fingerprint to the muon client.
/// // The fingerprint is important in combating fraud.
/// let client = Client::new(app, store.into_store()).await?;
/// // Here we pass in the ExampleInfoProvider using with_info_provider.
/// let session = client.with_info_provider(Arc::new(ExampleInfoProvider {})).new_session_without_credentials(()).await?;
/// let session = match session.auth().login("visionary", "a").await {
///     LoginFlow::Ok(session, _) => session,
///     LoginFlow::TwoFactor(_, _) => panic!("Second factor required."),
///     LoginFlow::Failed { reason, .. } => panic!("Login failed: {}.", reason),
/// };
/// assert!(session.is_authenticated().await);
/// session.clone().logout().await;
/// assert!(!session.is_authenticated().await);
/// # Ok(())
/// # }
/// ```
#[async_trait]
#[derive_dyn(Debug)]
pub trait InfoProvider: Send + Sync + 'static {
    /// Function to provide the fingerprint.
    /// The format of the fingerprint is the responability of the clients that implement this trait.
    /// This fingerprint is used for the unauth session api call and the login calls.
    /// This method allows you to generate the fingerpring exactly as you'd like. You can use remote resources, poll you environment, etc. for pulling data in the fingerprint
    /// ATTENTION: The fingerprint call halts requests from reaching the server. If the fingerprint call takes too long the requests will time out. Make sure the fingerprint function returns quickly.
    /// Consider caching the fingerprint and returning it immediately upon request.
    async fn fingerprint(&self) -> Option<Fingerprint>;
}

/// Fingerprint to be used for anti-abuse.
#[must_use]
#[derive(Clone, Debug, Default)]
pub struct Fingerprint(Value);

impl From<Value> for Fingerprint {
    fn from(value: Value) -> Self {
        Fingerprint(value)
    }
}

impl FromStr for Fingerprint {
    type Err = serde_json::Error;

    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        s.parse::<Value>().map(Fingerprint::from)
    }
}

#[cfg(test)]
mod tests {
    use super::{BoxFut, Sender};
    use crate::client::Timeout;
    use crate::http::{HttpReq, HttpRes};
    use crate::ErrorKind;
    use std::time::Duration;

    struct MockedSender;

    impl Sender<HttpReq, HttpRes> for MockedSender {
        fn send<'a>(&'a self, req: HttpReq) -> BoxFut<'a, crate::Result<HttpRes>> {
            Box::pin(async move {
                futures_timer::Delay::new(*req.get_allowed_time()).await;
                Err(crate::Error::new(ErrorKind::Send, Some(Timeout)))
            })
        }
    }

    #[test]
    fn test_request_expiration() {
        let delay_fut = futures_timer::Delay::new(Duration::from_secs(5));
        let req = HttpReq::new(crate::http::Method::GET, "/tests/ping")
            .allowed_time(Duration::from_secs(1));

        futures::executor::block_on(async move {
            match futures::future::select(MockedSender.send(req), delay_fut).await {
                futures::future::Either::Left((_, _)) => {}
                futures::future::Either::Right((_, _)) => panic!("the request should expire first"),
            }
        })
    }

    #[test]
    fn test_request_no_expire() {
        let delay_fut = futures_timer::Delay::new(Duration::from_secs(1));
        let req = HttpReq::new(crate::http::Method::GET, "/tests/ping")
            .allowed_time(Duration::from_secs(5));

        futures::executor::block_on(async move {
            match futures::future::select(MockedSender.send(req), delay_fut).await {
                futures::future::Either::Left((_, _)) => {
                    panic!("the request should not expire first")
                }
                futures::future::Either::Right((_, _)) => {}
            }
        })
    }
}
