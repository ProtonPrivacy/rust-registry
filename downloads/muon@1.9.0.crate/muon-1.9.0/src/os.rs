struct OperatingSystem<Connector, Time> {
    connector: Connector,
    time: Time,
}
