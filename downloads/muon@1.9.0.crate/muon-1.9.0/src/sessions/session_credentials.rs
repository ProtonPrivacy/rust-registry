pub use crate::rest::auth::v4::SessionCredentials;
use crate::{Auth, Tokens};

impl SessionCredentials {
    /// Creates a [`Tokens`] instance from the session credentials.
    ///
    /// This method extracts the access token, refresh token, and scopes from the
    /// current [`SessionCredentials`] to construct a new [`Tokens`] object. It is
    /// useful when only the token-related information is required.
    ///
    /// # Returns
    ///
    /// A new [`Tokens`] instance containing the session's authentication tokens and scopes.
    ///
    /// # Examples
    ///
    /// ```
    /// use muon::SessionCredentials;
    /// use serde_json::json;
    ///
    /// // This is the JSON response from the API.
    /// // DO NOT USE THIS IN YOUR CODE.
    /// let creds = json!({
    ///     "UserID": "user-123",
    ///     "UID": "session-uid-456",
    ///     "AccessToken": "access_token_str",
    ///     "RefreshToken": "refresh_token_str",
    ///     "Scopes": ["read", "write"],
    /// });
    ///
    /// # let creds: SessionCredentials = serde_json::from_value(creds).unwrap();
    ///
    /// let tokens = creds.as_tokens();
    ///
    /// assert_eq!(tokens.ref_tok(), "refresh_token_str");
    /// assert_eq!(tokens.acc_tok(), Some("access_token_str"));
    /// assert_eq!(tokens.scopes(), Some(&*vec!["read".to_string(), "write".to_string()]));
    /// ```
    #[must_use]
    pub fn as_tokens(&self) -> Tokens {
        Tokens::access(self.access_token(), self.refresh_token(), self.scopes())
    }

    /// Converts the session credentials into a generic [`Auth`] representation.
    ///
    /// This method creates an [`Auth`] enum variant based on the presence of a `user_id`.
    ///
    /// - If `user_id` is `Some`, it creates an `Auth::internal` variant, representing a
    ///   fully authenticated user session.
    /// - If `user_id` is `None`, it creates an `Auth::anonymous` variant, representing a
    ///   session for a user who is not logged in.
    ///
    /// This serves as a convenient way to transform session-specific credentials into the
    /// application's general authentication model.
    ///
    /// # Returns
    ///
    /// An [`Auth`] instance, representing either an internal (authenticated) or an
    /// anonymous user.
    ///
    /// # Examples
    ///
    /// ## Authenticated User
    ///
    /// When `user_id` is present.
    /// ```
    /// use muon::SessionCredentials;
    /// use serde_json::json;
    ///
    /// // This is the JSON response from the API.
    /// // DO NOT USE THIS IN YOUR CODE.
    /// let creds = json!({
    ///     "UserID": "user-123",
    ///     "UID": "session-uid-456",
    ///     "AccessToken": "access_token_str",
    ///     "RefreshToken": "refresh_token_str",
    ///     "Scopes": ["read"],
    /// });
    ///
    /// # let creds: SessionCredentials = serde_json::from_value(creds).unwrap();
    ///
    /// let auth = creds.as_auth();
    /// assert_eq!(auth.user_id(), Some("user-123"));
    /// ```
    ///
    /// ## Anonymous User
    ///
    /// When `user_id` is `None`.
    /// ```
    /// use muon::SessionCredentials;
    /// use serde_json::json;
    ///
    /// // This is the JSON response from the API.
    /// // DO NOT USE THIS IN YOUR CODE.
    /// let creds = json!({
    ///     "UserID": null,
    ///     "UID": "anonymous-session-789",
    ///     "AccessToken": "anon_access_token",
    ///     "RefreshToken": "anon_refresh_token",
    ///     "Scopes": ["read_public"],
    /// });
    ///
    /// # let creds: SessionCredentials = serde_json::from_value(creds).unwrap();
    ///
    /// let auth = creds.as_auth();
    /// assert_eq!(auth.user_id(), None);
    /// ```
    pub fn as_auth(&self) -> Auth {
        if let Some(user_id) = self.user_id().clone() {
            Auth::internal(user_id, self.uid(), self.as_tokens())
        } else {
            Auth::anonymous(self.uid(), self.as_tokens())
        }
    }
}
