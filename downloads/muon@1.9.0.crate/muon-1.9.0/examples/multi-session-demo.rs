//! This example demonstrates multi-session support with different users using String session keys.

use anyhow::{bail, Result};
use muon::client::flow::LoginFlow;
use muon::env::EnvId;
use muon::rest::core;
use muon::{App, GET};
use tracing::*;

#[tokio::main]
async fn main() -> Result<()> {
    let _ = env_logger::try_init();

    const USER1: &str = "plus";
    const PASS1: &str = "plus";
    const USER2: &str = "visionary";
    const PASS2: &str = "a";

    // Create first client with session key
    let app = App::new("android-mail@99.9.40.0-dev")?
        .with_user_agent("ProtonMail/99.9.40.0-dev (Android 15; google sdk_gphone64_arm64)");
    let client = muon::Client::new(app, EnvId::new_atlas().into_store()).await?;
    let session1 = client
        .new_session_without_credentials("user_session_1".to_string())
        .await?;

    let session1 = match session1.auth().login(USER1, PASS1).await {
        LoginFlow::Ok(session, data) => {
            info!("Session 1 authenticated user: {}", data.user_id);
            session
        }
        LoginFlow::TwoFactor(_, _) => bail!("Unexpected 2FA for session 1"),
        LoginFlow::Failed { reason, .. } => bail!("Session 1 login failed: {}", reason),
    };

    let session2 = client
        .new_session_without_credentials("user_session_2".to_string())
        .await?;

    let session2 = match session2.auth().login(USER2, PASS2).await {
        LoginFlow::Ok(session, data) => {
            info!("Session 2 authenticated user: {}", data.user_id);
            session
        }
        LoginFlow::TwoFactor(_, _) => bail!("Unexpected 2FA for session 2"),
        LoginFlow::Failed { reason, .. } => bail!("Session 2 login failed: {}", reason),
    };

    // Test requests with each session
    let req = GET!("/core/v4/users");
    let res = session2.send(req).await?;
    let user2: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    info!("Session 2 request for user: {}", user2.user.name);

    let req = GET!("/core/v4/users");
    let res = session1.send(req).await?;
    let user1: core::v4::users::GetRes = res.ok()?.into_body_json()?;
    info!("Session 1 request for user: {}", user1.user.name);

    // Test session isolation
    session1.logout().await;
    info!("Session 1 logged out");

    // Session 2 should still work
    let req = GET!("/core/v4/users");
    let res = session2.send(req).await?;
    res.ok()?;
    info!("Session 2 still works after session 1 logout");

    // Verify isolation
    assert!(client
        .get_session("user_session_1".to_string())
        .await
        .is_none());
    assert!(session2.is_authenticated().await);
    info!("Session isolation verified");

    Ok(())
}
