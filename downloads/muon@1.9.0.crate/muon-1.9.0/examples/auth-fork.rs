//! This example demonstrates how to fork a session to another session.

use anyhow::{bail, Result};
use muon::client::flow::{ForkFlowResult, LoginFlow, WithSelectorFlow};
use muon::{App, Client, GET};

#[tokio::main]
async fn main() -> Result<()> {
    // Create a new session on device 1.
    let app = App::new("windows-vpn@4.1.0")?;
    let env = muon::env::EnvId::new_atlas();
    // Please check the auth-info-provider.rs example to see how to pass a fingerprint to the muon client.
    // The fingerprint is important in combating fraud.
    let parent = Client::new(app, env.into_store())
        .await?
        .new_session_without_credentials(())
        .await?;

    // Authenticate the session.
    let parent = match parent.auth().login("visionary", "a").await {
        LoginFlow::Ok(session, _) => session,
        LoginFlow::TwoFactor(_, _) => bail!("unexpected 2FA"),
        LoginFlow::Failed { reason, .. } => return Err(reason.into()),
    };

    // Fork the session to a windows-vpn session.
    let ForkFlowResult::Success(_, selector) = parent
        .fork("windows-vpn")
        .payload(b"hello world")
        .send()
        .await
    else {
        bail!("Fail to fork")
    };

    // Create a new windows-vpn session to take ownership of the fork on device 2.
    // Note: The Client should be a singleton, always. Here we are creating a second client to simulate a second device.
    let app = App::new("windows-vpn@4.1.0")?;
    let env = muon::env::EnvId::new_atlas();
    let child = Client::new(app, env.into_store())
        .await?
        .new_session_without_credentials(())
        .await?;

    // Authenticate the child session via the fork on device 2.
    let WithSelectorFlow::Ok(child, payload) =
        child.auth().from_fork().with_selector(selector).await
    else {
        bail!("couldn't log via fork selector")
    };

    // The payload is the data sent by the parent session.
    assert_eq!(payload.as_deref(), Some(b"hello world".as_ref()));

    // The child session is now authenticated on device 2.
    child.send(GET!("/core/v4/users")).await?.ok()?;

    Ok(())
}
